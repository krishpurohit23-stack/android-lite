#!/usr/bin/env python3
"""Fast static checks that run BEFORE xcodebuild (no compiler needed).
Usage: python3 scripts/check.py Sources
Catches the mistakes that wasted the most builds: unbalanced braces, duplicate top-level names,
missing @main / build marker, and a few known-bad SwiftUI patterns."""
import glob, os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else "Sources"
files = sorted(glob.glob(os.path.join(root, "**", "*.swift"), recursive=True))
errors, warnings = [], []
if not files:
    print("ERROR: no .swift files under", root)
    sys.exit(1)

def strip_strings_and_comments(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
        elif text.startswith('"""', i):
            j = text.find('"""', i + 3)
            i = n if j < 0 else j + 3
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)

names = {}
main_count = 0
marker = None
for f in files:
    raw = open(f, encoding="utf-8").read()
    m = re.search(r"ANDROID_LITE_BUILD=(\d+)", raw)
    if m:
        marker = m.group(1)
    clean = strip_strings_and_comments(raw)
    for a, b, label in (("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")):
        if clean.count(a) != clean.count(b):
            errors.append("%s: unbalanced %s (%d open vs %d close)" % (f, label, clean.count(a), clean.count(b)))
    main_count += len(re.findall(r"^@main", raw, re.M))
    for mm in re.finditer(r"^(?:final class|class|struct|enum|protocol|func|let|var)\s+(\w+)", raw, re.M):
        names.setdefault(mm.group(1), []).append(os.path.basename(f))
    # known-bad patterns
    for ln, line in enumerate(raw.split("\n"), 1):
        if re.search(r"\.persistentSystemOverlays|\.defersSystemGestures", line) and "Entry" not in f:
            pass
        if "localStorage" in line and f.endswith(".swift"):
            warnings.append("%s:%d localStorage in Swift?" % (f, ln))

for n, fl in names.items():
    if len(fl) > 1:
        errors.append("duplicate top-level name '%s' in: %s" % (n, ", ".join(fl)))
if main_count != 1:
    errors.append("expected exactly one @main, found %d" % main_count)
if not marker:
    errors.append("missing // ANDROID_LITE_BUILD=N marker (see Version.swift)")

print("checked %d files, build marker %s" % (len(files), marker))
for w in warnings:
    print("WARN:", w)
if errors:
    print("\nCHECK FAILED:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("OK")
