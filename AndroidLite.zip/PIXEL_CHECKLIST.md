# Pixel / Android 16 checklist for Android Lite (build 18)

Legend: DONE = already in the app, NEW = added in build 18, PARTIAL = works but simpler than a real Pixel,
IOS = impossible inside an iOS app (needs hardware / Google services / system access), TODO = not built yet.
Status is written honestly: nothing here was run on a device by the author (no Mac in the chat).

## Home screen / Pixel Launcher
- DONE  Big stacked clock + date ("At a glance") top left
- NEW   Weather in At a glance (Open-Meteo, city set in Settings > Home screen)
- DONE  Search pill with G, mic and lens icons (types to Chrome search)
- DONE  Dock with 4 apps, themed round icons, labels
- DONE  Free icon placement, multiple pages, page dots, add/remove apps per page, edit mode with wobble
- NEW   Notification dot on app icons that have notifications
- NEW   Press animation (icons squish when touched)
- NEW   Long press on empty home = Pixel menu (Edit home screen / Wallpaper & style / Home settings)
- NEW   Long press on an icon = popup (Edit home screen / App info / Remove)
- DONE  Swipe up = app drawer, swipe down = notifications, double tap = lock
- DONE  Widgets: battery, calendar, notes, storage, notifications
- DONE  Icon shapes (circle / squircle / rounded), 4 or 5 columns, hide search bar
- TODO  Folders (drag an icon on another icon)
- TODO  Widget picker with resizable widgets, smartspace cards (events, flights)
- IOS   Real Android widgets, Discover feed page (-1), adaptive icons from other apps

## App drawer
- DONE  A-Z grid with search, Enter opens first match or searches the web
- NEW   "Suggested" row = your 4 most used apps
- NEW   Stretchy overscroll
- TODO  Private space, app categories, "search the web" suggestions list

## Recents / overview
- DONE  Cards with real screenshots, app icon + name above, horizontal scroll, swipe up to dismiss, Clear all
- NEW   Quick switch: swipe left/right along the nav pill to jump to the previous app
- PARTIAL Select / Lens / Screenshot actions under the cards (only Clear all exists)

## Gestures
- DONE  Back: swipe from left/right edge with arrow + app shrinks (predictive back look)
- DONE  Home: swipe up, recents: swipe up and hold, notifications: swipe down, QS: from right half
- NEW   Notification shade follows your finger while you pull it down
- DONE  Double tap to lock
- IOS   Squeeze for Assistant, Quick Tap on the back, power-button gestures, edge-to-edge corner swipes

## Animations / motion
- DONE  App opens from its icon and closes into the icon (10 styles + speed in Settings)
- NEW   Stretch overscroll in Settings, drawer, notifications, alarms (Android 12+ stretch)
- NEW   Press spring on icons and quick-settings tiles
- DONE  Shade slide, lock-screen swipe-up, recents card dismiss, wallpaper cross-fade
- TODO  Shared-element transitions inside apps, Material 3 Expressive shape morphing on tiles
- TODO  Haptic ticks on sliders / toggles (only app launch has haptics)

## Lock screen
- DONE  Big clock, date, notification cards, "Swipe up to open", camera + flashlight shortcuts
- NEW   Weather line, "Charging" text
- IOS   Fingerprint / face unlock, Always-on display, lock-screen clock styles from Android

## Notification shade + Quick settings
- DONE  Pixel layout: 4 pill tiles on top, cards, Clear all, history/settings buttons, split shade (left = notifications, right = QS)
- NEW   Swipe a notification left/right to dismiss
- NEW   Inline Reply on message notifications
- NEW   Heads-up banner can be swiped up to dismiss
- DONE  10 QS tiles + brightness bar, Night Light, Keep screen on, Lock
- TODO  Media player card, device controls, tile editor, user switcher, notification expand/collapse, snooze
- IOS   Real Wi-Fi / Bluetooth / airplane / mobile data toggles (visual only), Quick Share

## Status bar
- DONE  Clock, notification icons, Wi-Fi, signal, battery icon
- NEW   Battery percentage
- TODO  DND / alarm / VPN icons

## System UI extras
- NEW   Pixel-style volume panel on the right (replaces the iOS volume HUD)
- NEW   Screenshot thumbnail bottom left (saved to the gallery)
- NEW   Material You: "colors from wallpaper" (last dot in Wallpaper & style)
- DONE  6 more accent colors, 10 wallpapers + your photo, icon shapes
- IOS   Light theme (needs every color to become dynamic, planned), font size scaling, display zoom

## Apps
- DONE  Phone (keypad, call history via CallKit), Messages (local chats), Chrome (tabs of web apps, PiP, background audio),
        Camera (3 lenses, 800x, video, Moon, Night, Real-ESRGAN), Photos (editor, favorites, viewer), Calculator,
        Calendar (events), Notes, Settings (17 pages), Clock
- NEW   Clock: Alarm tab with real notifications (needs notification permission)
- TODO  Contacts, Files, Play Store look-alike, Maps, YouTube Music, Gallery albums
- IOS   Running real APKs / Google apps / Play Services

## Settings
- DONE  Pixel layout: search, colored circle icons, subtitles, sub pages with cards
- NEW   Stretchy scroll
- TODO  Collapsing large title, "Suggestions" cards, per-app notification channels

## My own ideas added in build 18
1. Swipe along the pill = quick switch between apps
2. Reply to messages straight from the notification
3. Screenshot thumbnail with auto-save
4. Pixel volume panel
5. Real alarms (local notifications)
6. At a glance weather line
