import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Shade.swift - Notification shade + quick settings panels. Read CLAUDE.md before editing.

// MARK: - Notification shade + quick settings (Android 16 split panels)
struct BigTile: View {
    let icon: String
    let title: String
    @Binding var on: Bool
    var body: some View {
        Button { on.toggle() } label: {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .medium))
                    .frame(width: 38, height: 38)
                    .background(Circle().fill(on ? T.onAccent.opacity(0.18) : Color.white.opacity(0.08)))
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                    Text(on ? "On" : "Off").font(.system(size: 12)).opacity(0.75)
                }
                Spacer()
            }
            .padding(.horizontal, 12)
            .frame(height: 68)
            .foregroundColor(on ? T.onAccent : .white)
            .background(RoundedRectangle(cornerRadius: 34, style: .continuous).fill(on ? T.accent : T.card))
        }
        .buttonStyle(.plain)
    }
}

struct SmallTile: View {
    let icon: String
    @Binding var on: Bool
    var body: some View {
        Button { on.toggle() } label: {
            Image(systemName: icon)
                .font(.system(size: 20))
                .frame(width: 64, height: 64)
                .foregroundColor(on ? T.onAccent : .white)
                .background(Circle().fill(on ? T.accent : T.card))
        }
        .buttonStyle(.plain)
    }
}

struct BrightBar: View {
    @Binding var v: Double
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(T.card)
                Capsule().fill(T.accent)
                    .frame(width: max(56, g.size.width * CGFloat(v)))
                Image(systemName: "sun.max.fill")
                    .foregroundColor(T.onAccent)
                    .padding(.leading, 20)
            }
            .contentShape(Capsule())
            .gesture(DragGesture(minimumDistance: 0).onChanged { val in
                v = min(1, max(0.05, Double(val.location.x / g.size.width)))
            })
        }
        .frame(height: 56)
    }
}

struct NotifCard: View {
    @EnvironmentObject var os: OS
    let n: Notif
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: iconFor(n.appId))
                .foregroundColor(tintFor(n.appId))
                .frame(width: 36, height: 36)
                .background(Circle().fill(tintFor(n.appId).opacity(0.2)))
            VStack(alignment: .leading, spacing: 2) {
                Text("\(appFor(n.appId)?.name ?? "System") · \(n.date, style: .relative)")
                    .font(.system(size: 12)).opacity(0.65)
                Text(n.title).font(.system(size: 15, weight: .semibold))
                Text(os.hideNotif ? "Content hidden" : n.body).font(.system(size: 14)).opacity(0.85)
            }
            Spacer()
            Button {
                withAnimation { os.notifs.removeAll { $0.id == n.id } }
            } label: {
                Image(systemName: "xmark").font(.system(size: 13)).opacity(0.6).padding(6)
            }
        }
        .foregroundColor(.white)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(T.card))
        .onTapGesture {
            if let a = appFor(n.appId) { os.launch(a) }
        }
    }
}

struct NotifPanel: View {
    @EnvironmentObject var os: OS
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Date(), style: .time).font(.system(size: 38, weight: .light))
                    Text(fmtDate("EEEE, MMM d")).font(.system(size: 15)).opacity(0.85)
                }
                Spacer()
                Button {
                    withAnimation { os.panel = .qs }
                } label: {
                    Image(systemName: "slider.horizontal.3")
                        .foregroundColor(T.onAccent)
                        .frame(width: 48, height: 48)
                        .background(Circle().fill(T.accent))
                }
            }
            if os.notifs.isEmpty {
                Text("No notifications")
                    .opacity(0.6)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
            } else {
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(os.notifs) { n in NotifCard(n: n) }
                    }
                }
                .frame(maxHeight: 440)
                Button {
                    withAnimation { os.notifs = [] }
                } label: {
                    Text("Clear all")
                        .foregroundColor(T.onAccent)
                        .padding(.horizontal, 22).padding(.vertical, 10)
                        .background(Capsule().fill(T.accent))
                }
                .frame(maxWidth: .infinity)
            }
        }
    }
}

struct QSPanel: View {
    @EnvironmentObject var os: OS
    let cols = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(Date(), style: .time).font(.system(size: 38, weight: .light))
                    Text(fmtDate("EEEE, MMM d")).font(.system(size: 15)).opacity(0.85)
                }
                Spacer()
                Button {
                    withAnimation { os.panel = .notif }
                } label: {
                    Image(systemName: os.notifs.isEmpty ? "bell" : "bell.badge.fill")
                        .foregroundColor(T.onAccent)
                        .frame(width: 48, height: 48)
                        .background(Circle().fill(T.accent))
                }
            }
            LazyVGrid(columns: cols, spacing: 10) {
                BigTile(icon: "wifi", title: "Internet", on: $os.wifi)
                BigTile(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", on: $os.bt)
                BigTile(icon: "flashlight.on.fill", title: "Flashlight", on: $os.flash)
                BigTile(icon: "moon.fill", title: "Do Not Disturb", on: $os.dnd)
                BigTile(icon: "moon.stars", title: "Night Light", on: $os.nightLight)
                BigTile(icon: "display", title: "Keep screen on", on: $os.keepAwake)
            }
            HStack(spacing: 0) {
                SmallTile(icon: "airplane", on: $os.airplane)
                Spacer()
                SmallTile(icon: "battery.25", on: $os.saver)
                Spacer()
                Button {
                    os.home()
                    withAnimation(.easeOut(duration: 0.25)) { os.locked = true }
                } label: {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 20))
                        .frame(width: 64, height: 64)
                        .foregroundColor(.white)
                        .background(Circle().fill(T.card))
                }
                Spacer()
                Button {
                    os.post("settings", "Test notification", "Notifications work!")
                } label: {
                    Image(systemName: "bell.fill")
                        .font(.system(size: 20))
                        .frame(width: 64, height: 64)
                        .foregroundColor(.white)
                        .background(Circle().fill(T.card))
                }
            }
            BrightBar(v: $os.brightness)
        }
    }
}

struct Shade: View {
    @EnvironmentObject var os: OS
    var body: some View {
        ZStack(alignment: .top) {
            Color.black.opacity(0.55).ignoresSafeArea().onTapGesture { os.closePanel() }
            VStack(spacing: 14) {
                if os.panel == .notif { NotifPanel() } else { QSPanel() }
            }
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.top, os.padTop - 12)
            .padding(.bottom, 20)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 36, style: .continuous)
                    .fill(T.bg)
                    .ignoresSafeArea(edges: .top)
            )
        }
    }
}
