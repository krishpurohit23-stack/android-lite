import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Shade.swift - Pixel-style notification shade + quick settings (also the colors used by the lock screen). Read CLAUDE.md before editing.

// MARK: - Pixel palette (os.lightShade = true -> light frosted Pixel look, false -> dark)
enum PX {
    static func text(_ l: Bool) -> Color { l ? rgb(0.09, 0.11, 0.15) : Color.white }
    static func sub(_ l: Bool) -> Color { l ? rgb(0.26, 0.29, 0.35) : Color.white.opacity(0.7) }
    static func card(_ l: Bool) -> Color { l ? Color.white.opacity(0.66) : T.card }
    static func lockCard(_ l: Bool) -> Color { l ? Color.white.opacity(0.88) : T.card.opacity(0.94) }
    static func tileOn(_ l: Bool) -> Color { l ? rgb(0.30, 0.33, 0.41) : T.accent }
    static func onTileOn(_ l: Bool) -> Color { l ? Color.white : T.onAccent }
    static func tileOff(_ l: Bool) -> Color { l ? Color.white.opacity(0.6) : T.card }
    static func chipFill(_ l: Bool) -> Color { l ? Color.black.opacity(0.07) : Color.white.opacity(0.1) }
    static func iconColor(_ l: Bool, _ on: Bool) -> Color {
        if l { return Color.white }
        return on ? T.onAccent : Color.white
    }
    static func dotFill(_ l: Bool, _ on: Bool) -> Color {
        if l { return on ? Color.white.opacity(0.2) : rgb(0.30, 0.33, 0.41) }
        return on ? T.onAccent.opacity(0.18) : Color.white.opacity(0.08)
    }
    static func shadeBG(_ l: Bool) -> LinearGradient {
        if l {
            return LinearGradient(colors: [rgb(0.79, 0.83, 0.92), rgb(0.88, 0.90, 0.94)], startPoint: .top, endPoint: .bottom)
        }
        return LinearGradient(colors: [T.bg, T.bg], startPoint: .top, endPoint: .bottom)
    }
}

func agoText(_ d: Date) -> String {
    let s = Int(Date().timeIntervalSince(d))
    if s < 60 { return "Now" }
    if s < 3600 { return "\(s / 60)m" }
    if s < 86400 { return "\(s / 3600)h" }
    return "\(s / 86400)d"
}

func isSilentNotif(_ n: Notif) -> Bool {
    n.appId == "settings" || n.appId == "web"
}

// MARK: - Tiles
struct BigTile: View {
    @EnvironmentObject var os: OS
    let icon: String
    let title: String
    var sub: String = ""
    @Binding var on: Bool

    var body: some View {
        let l = os.lightShade
        Button { on.toggle() } label: {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundColor(PX.iconColor(l, on))
                    .frame(width: 38, height: 38)
                    .background(Circle().fill(PX.dotFill(l, on)))
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                    if !sub.isEmpty {
                        Text(sub).font(.system(size: 12)).opacity(0.75).lineLimit(1).minimumScaleFactor(0.8)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 12)
            .frame(height: 62)
            .foregroundColor(on ? PX.onTileOn(l) : PX.text(l))
            .background(RoundedRectangle(cornerRadius: 31, style: .continuous).fill(on ? PX.tileOn(l) : PX.tileOff(l)))
        }
        .buttonStyle(.plain)
    }
}

struct SmallTile: View {
    @EnvironmentObject var os: OS
    let icon: String
    @Binding var on: Bool
    var body: some View {
        let l = os.lightShade
        Button { on.toggle() } label: {
            Image(systemName: icon)
                .font(.system(size: 20))
                .frame(width: 62, height: 62)
                .foregroundColor(on ? PX.onTileOn(l) : PX.text(l))
                .background(Circle().fill(on ? PX.tileOn(l) : PX.tileOff(l)))
        }
        .buttonStyle(.plain)
    }
}

struct RoundAction: View {
    @EnvironmentObject var os: OS
    let icon: String
    let action: () -> Void
    var body: some View {
        let l = os.lightShade
        Button { action() } label: {
            Image(systemName: icon)
                .font(.system(size: 20))
                .frame(width: 62, height: 62)
                .foregroundColor(PX.text(l))
                .background(Circle().fill(PX.tileOff(l)))
        }
        .buttonStyle(.plain)
    }
}

// Settings uses this one (dark card style), keep the name.
struct BrightBar: View {
    @Binding var v: Double
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(T.card)
                Capsule().fill(T.accent)
                    .frame(width: max(56, g.size.width * CGFloat(v)))
                Image(systemName: "sun.max.fill")
                    .foregroundColor(T.onAccent)
                    .padding(.leading, 20)
            }
            .contentShape(Capsule())
            .gesture(DragGesture(minimumDistance: 0).onChanged { val in
                v = min(1, max(0.05, Double(val.location.x / g.size.width)))
            })
        }
        .frame(height: 56)
    }
}

struct ShadeBright: View {
    @EnvironmentObject var os: OS
    @Binding var v: Double
    var body: some View {
        let l = os.lightShade
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(PX.tileOff(l))
                Capsule().fill(PX.tileOn(l))
                    .frame(width: max(56, g.size.width * CGFloat(v)))
                Image(systemName: "sun.max.fill")
                    .foregroundColor(PX.onTileOn(l))
                    .padding(.leading, 20)
            }
            .contentShape(Capsule())
            .gesture(DragGesture(minimumDistance: 0).onChanged { val in
                v = min(1, max(0.05, Double(val.location.x / g.size.width)))
            })
        }
        .frame(height: 56)
    }
}

// MARK: - Status row on top of the shade
struct ShadeStatus: View {
    @EnvironmentObject var os: OS
    var body: some View {
        let l = os.lightShade
        HStack(spacing: 6) {
            Text(Date(), style: .time).font(.system(size: 15, weight: .semibold))
            Spacer()
            if os.dnd { Image(systemName: "moon.fill") }
            if os.airplane {
                Image(systemName: "airplane")
            } else {
                Image(systemName: os.wifi ? "wifi" : "wifi.slash")
                Image(systemName: "antenna.radiowaves.left.and.right")
            }
            Image(systemName: os.saver ? "battery.25" : "battery.100")
        }
        .font(.system(size: 13))
        .foregroundColor(PX.text(l))
        .padding(.horizontal, 12)
        .frame(height: 30)
    }
}

// MARK: - Notifications
struct NotifCard: View {
    @EnvironmentObject var os: OS
    let n: Notif
    var body: some View {
        let l = os.lightShade
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: iconFor(n.appId))
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(PX.text(l))
                .frame(width: 40, height: 40)
                .background(Circle().fill(tintFor(n.appId).opacity(l ? 0.55 : 0.25)))
            VStack(alignment: .leading, spacing: 2) {
                Text("\(appFor(n.appId)?.name ?? "System") · \(agoText(n.date))")
                    .font(.system(size: 12))
                    .foregroundColor(PX.sub(l))
                Text(n.title).font(.system(size: 15, weight: .semibold))
                Text(os.hideNotif ? "Content hidden" : n.body)
                    .font(.system(size: 14))
                    .foregroundColor(PX.sub(l))
            }
            Spacer(minLength: 0)
            Button {
                withAnimation { os.notifs.removeAll { $0.id == n.id } }
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(PX.sub(l))
                    .frame(width: 30, height: 30)
                    .background(Circle().fill(PX.chipFill(l)))
            }
        }
        .foregroundColor(PX.text(l))
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(PX.card(l)))
        .onTapGesture {
            if let a = appFor(n.appId) { os.launch(a) }
        }
    }
}

struct SilentGroup: Identifiable {
    let id: String
    let items: [Notif]
}

struct SilentBundle: View {
    @EnvironmentObject var os: OS
    let g: SilentGroup
    @State var open = false

    var body: some View {
        let l = os.lightShade
        VStack(spacing: 8) {
            Button {
                withAnimation(.easeOut(duration: 0.2)) { open.toggle() }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: iconFor(g.id))
                        .font(.system(size: 15, weight: .semibold))
                        .frame(width: 34, height: 34)
                        .background(Circle().fill(tintFor(g.id).opacity(l ? 0.55 : 0.25)))
                    Text(os.appName(g.id)).font(.system(size: 15, weight: .medium))
                    Spacer()
                    HStack(spacing: 4) {
                        Text("\(g.items.count)").font(.system(size: 12, weight: .semibold))
                        Image(systemName: open ? "chevron.up" : "chevron.down").font(.system(size: 10, weight: .bold))
                    }
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Capsule().fill(PX.chipFill(l)))
                }
                .padding(.horizontal, 14)
                .frame(height: 54)
                .background(RoundedRectangle(cornerRadius: 27, style: .continuous).fill(PX.card(l)))
            }
            .buttonStyle(.plain)
            if open {
                ForEach(g.items) { n in NotifCard(n: n) }
            }
        }
        .foregroundColor(PX.text(l))
    }
}

struct NotifPanel: View {
    @EnvironmentObject var os: OS
    let cols = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var alerts: [Notif] { os.notifs.filter { !isSilentNotif($0) } }

    var silentGroups: [SilentGroup] {
        var order: [String] = []
        for n in os.notifs where isSilentNotif(n) {
            if !order.contains(n.appId) { order.append(n.appId) }
        }
        return order.map { id in SilentGroup(id: id, items: os.notifs.filter { $0.appId == id }) }
    }

    func clearSilent() {
        withAnimation { os.notifs.removeAll { isSilentNotif($0) } }
    }

    func openNotifSettings() {
        os.settingsPage = "notifs"
        if let a = appFor("settings") { os.launch(a) }
    }

    var silentHeader: some View {
        HStack {
            Text("Silent").font(.system(size: 14, weight: .semibold))
            Spacer()
            Button { clearSilent() } label: {
                Image(systemName: "xmark").font(.system(size: 12, weight: .semibold)).padding(6)
            }
        }
        .foregroundColor(PX.text(os.lightShade))
        .padding(.horizontal, 6)
        .padding(.top, 6)
    }

    var bottomRow: some View {
        let l = os.lightShade
        return HStack(spacing: 8) {
            Button {
                withAnimation { os.notifs = [] }
            } label: {
                Text("Clear all")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(PX.text(l))
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(Capsule().fill(PX.card(l)))
            }
            .buttonStyle(.plain)
            Button { openNotifSettings() } label: {
                Image(systemName: "gearshape")
                    .font(.system(size: 18))
                    .foregroundColor(PX.text(l))
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(PX.card(l)))
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 8)
    }

    var body: some View {
        VStack(spacing: 10) {
            ShadeStatus()
            LazyVGrid(columns: cols, spacing: 8) {
                BigTile(icon: "wifi", title: "Internet", sub: os.wifi ? "Wi-Fi" : "Off", on: $os.wifi)
                BigTile(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", sub: os.bt ? "On" : "Off", on: $os.bt)
                BigTile(icon: "minus.circle.fill", title: "Modes", sub: os.dnd ? "Do Not Disturb" : "Off", on: $os.dnd)
                BigTile(icon: "flashlight.on.fill", title: "Flashlight", sub: os.flash ? "On" : "Off", on: $os.flash)
            }
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 8) {
                    if os.notifs.isEmpty {
                        Text("No notifications")
                            .foregroundColor(PX.sub(os.lightShade))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 36)
                    }
                    ForEach(alerts) { n in NotifCard(n: n) }
                    if !silentGroups.isEmpty { silentHeader }
                    ForEach(silentGroups) { g in SilentBundle(g: g) }
                    if !os.notifs.isEmpty { bottomRow }
                }
                .padding(.top, 4)
            }
            .frame(maxHeight: .infinity)
        }
    }
}

// MARK: - Quick settings (second pull down)
struct QSPanel: View {
    @EnvironmentObject var os: OS
    let cols = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    func lockNow() {
        os.home()
        withAnimation(.easeOut(duration: 0.25)) { os.locked = true }
    }

    var body: some View {
        let l = os.lightShade
        VStack(alignment: .leading, spacing: 14) {
            ShadeStatus()
            HStack {
                Text(fmtDate("EEEE, MMM d")).font(.system(size: 17, weight: .medium))
                Spacer()
                Button {
                    withAnimation { os.panel = .notif }
                } label: {
                    Image(systemName: os.notifs.isEmpty ? "bell" : "bell.badge.fill")
                        .foregroundColor(PX.onTileOn(l))
                        .frame(width: 46, height: 46)
                        .background(Circle().fill(PX.tileOn(l)))
                }
            }
            .padding(.horizontal, 6)
            LazyVGrid(columns: cols, spacing: 8) {
                BigTile(icon: "wifi", title: "Internet", sub: os.wifi ? "Wi-Fi" : "Off", on: $os.wifi)
                BigTile(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", sub: os.bt ? "On" : "Off", on: $os.bt)
                BigTile(icon: "flashlight.on.fill", title: "Flashlight", sub: os.flash ? "On" : "Off", on: $os.flash)
                BigTile(icon: "minus.circle.fill", title: "Modes", sub: os.dnd ? "Do Not Disturb" : "Off", on: $os.dnd)
                BigTile(icon: "moon.stars", title: "Night Light", sub: os.nightLight ? "On" : "Off", on: $os.nightLight)
                BigTile(icon: "display", title: "Keep screen on", sub: os.keepAwake ? "On" : "Off", on: $os.keepAwake)
            }
            HStack(spacing: 0) {
                SmallTile(icon: "airplane", on: $os.airplane)
                Spacer()
                SmallTile(icon: "battery.25", on: $os.saver)
                Spacer()
                RoundAction(icon: "lock.fill") { lockNow() }
                Spacer()
                RoundAction(icon: "bell.fill") { os.post("settings", "Test notification", "Notifications work!") }
            }
            ShadeBright(v: $os.brightness)
            Spacer(minLength: 0)
        }
    }
}

struct Shade: View {
    @EnvironmentObject var os: OS

    var handle: some View {
        Capsule()
            .fill(PX.text(os.lightShade).opacity(0.4))
            .frame(width: 120, height: 5)
            .frame(maxWidth: .infinity, minHeight: 44)
            .contentShape(Rectangle())
            .onTapGesture { os.closePanel() }
            .gesture(DragGesture(minimumDistance: 6).onEnded { v in
                if v.translation.height < -20 { os.closePanel() }
            })
    }

    var body: some View {
        let l = os.lightShade
        ZStack(alignment: .top) {
            PX.shadeBG(l)
                .ignoresSafeArea()
                .onTapGesture { }
            VStack(spacing: 0) {
                if os.panel == .notif { NotifPanel() } else { QSPanel() }
                handle
            }
            .foregroundColor(PX.text(l))
            .padding(.horizontal, 14)
            .padding(.top, max(os.top, 28) + 2)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 20, coordinateSpace: .global).onEnded { v in
                os.freeSwipe(startY: v.startLocation.y, dx: v.translation.width, dy: v.translation.height)
            }
        )
    }
}
