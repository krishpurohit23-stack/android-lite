import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Shade.swift - Notification shade + quick settings panels. Read CLAUDE.md before editing.

// MARK: - Notification shade + quick settings (Pixel / Android 16 look)
let pSlate = rgb(0.34, 0.38, 0.45)
let pCard = rgb(0.93, 0.94, 0.97)
let pInk = rgb(0.11, 0.13, 0.17)

struct PixelTile: View {
    let icon: String
    let title: String
    let sub: String
    let on: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .medium))
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(on ? Color.white.opacity(0.18) : Color.black.opacity(0.06)))
                VStack(alignment: .leading, spacing: 1) {
                    Text(title).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                    if !sub.isEmpty {
                        Text(sub).font(.system(size: 11)).opacity(0.75).lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 12)
            .frame(height: 70)
            .foregroundColor(on ? Color.white : pInk)
            .background(RoundedRectangle(cornerRadius: 35, style: .continuous).fill(on ? pSlate : pCard))
        }
        .buttonStyle(.plain)
    }
}

struct BrightBar: View {
    @Binding var v: Double
    var light = false
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(light ? rgb(0.86, 0.88, 0.92) : T.card)
                Capsule().fill(light ? pSlate : T.accent)
                    .frame(width: max(56, g.size.width * CGFloat(v)))
                Image(systemName: "sun.max.fill")
                    .foregroundColor(light ? Color.white : T.onAccent)
                    .padding(.leading, 20)
            }
            .contentShape(Capsule())
            .gesture(DragGesture(minimumDistance: 0).onChanged { val in
                v = min(1, max(0.05, Double(val.location.x / g.size.width)))
            })
        }
        .frame(height: 56)
    }
}

struct ShadeStatus: View {
    @EnvironmentObject var os: OS
    var body: some View {
        HStack(spacing: 6) {
            Text(Date(), style: .time).font(.system(size: 14, weight: .semibold))
            Spacer()
            Image(systemName: os.wifi ? "wifi" : "wifi.slash")
            Image(systemName: "antenna.radiowaves.left.and.right")
            Image(systemName: os.saver ? "battery.25" : "battery.100")
        }
        .font(.system(size: 13))
        .foregroundColor(pInk)
        .padding(.horizontal, 6)
    }
}

struct PixelNotif: View {
    @EnvironmentObject var os: OS
    let n: Notif

    func ago() -> String {
        let s = Date().timeIntervalSince(n.date)
        return s < 120 ? "Now" : "\(Int(s / 60))m"
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: iconFor(n.appId))
                .foregroundColor(tintFor(n.appId))
                .frame(width: 40, height: 40)
                .background(Circle().fill(tintFor(n.appId).opacity(0.25)))
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 4) {
                    Text(appFor(n.appId)?.name ?? "System").font(.system(size: 12, weight: .medium)).opacity(0.7)
                    Text("· " + ago()).font(.system(size: 12)).opacity(0.6)
                }
                Text(n.title).font(.system(size: 15, weight: .semibold))
                Text(os.hideNotif ? "Content hidden" : n.body)
                    .font(.system(size: 14))
                    .opacity(0.8)
                    .lineLimit(2)
            }
            Spacer(minLength: 0)
            Button {
                withAnimation { os.notifs.removeAll { $0.id == n.id } }
            } label: {
                Image(systemName: "xmark").font(.system(size: 12)).opacity(0.5).padding(6)
            }
        }
        .foregroundColor(pInk)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(pCard))
        .onTapGesture {
            if let a = appFor(n.appId) { os.launch(a) }
        }
    }
}

struct SilentRow: View {
    @EnvironmentObject var os: OS
    let appId: String
    let count: Int
    var body: some View {
        Button {
            if let a = appFor(appId) { os.launch(a) }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: iconFor(appId)).foregroundColor(pInk.opacity(0.7)).frame(width: 30)
                Text(appFor(appId)?.name ?? "System").font(.system(size: 14, weight: .medium))
                Spacer()
                Text("\(count)")
                    .font(.system(size: 12))
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(Capsule().fill(Color.black.opacity(0.07)))
                Image(systemName: "chevron.down").font(.system(size: 11))
            }
            .foregroundColor(pInk)
            .padding(.horizontal, 16)
            .frame(height: 48)
            .background(Capsule().fill(pCard))
        }
        .buttonStyle(.plain)
    }
}

struct NotifPanel: View {
    @EnvironmentObject var os: OS
    let cols = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]

    var convos: [Notif] { os.notifs.filter { $0.appId == "msg" } }

    var silentIds: [String] {
        var seen: [String] = []
        for n in os.notifs where n.appId != "msg" {
            if !seen.contains(n.appId) { seen.append(n.appId) }
        }
        return seen
    }

    var body: some View {
        VStack(spacing: 12) {
            ShadeStatus()
            LazyVGrid(columns: cols, spacing: 10) {
                PixelTile(icon: "wifi", title: "Internet", sub: os.wifi ? "Connected" : "Off", on: os.wifi) { os.wifi.toggle() }
                PixelTile(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", sub: os.bt ? "On" : "Off", on: os.bt) { os.bt.toggle() }
                PixelTile(icon: "moon.fill", title: "Modes", sub: os.dnd ? "Do Not Disturb" : "Off", on: os.dnd) { os.dnd.toggle() }
                PixelTile(icon: "flashlight.on.fill", title: "Flashlight", sub: os.flash ? "On" : "Off", on: os.flash) { os.flash.toggle() }
            }
            if os.notifs.isEmpty {
                Text("No notifications")
                    .foregroundColor(pInk.opacity(0.6))
                    .padding(.vertical, 50)
            } else {
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(os.notifs) { n in PixelNotif(n: n) }
                    }
                }
                .frame(maxHeight: 420)
            }
            HStack(spacing: 10) {
                Button {
                    withAnimation(.easeOut(duration: 0.25)) { os.panel = .qs }
                } label: {
                    Image(systemName: "slider.horizontal.3")
                        .foregroundColor(pInk)
                        .frame(width: 56, height: 50)
                        .background(Capsule().fill(pCard))
                }
                Button {
                    withAnimation { os.notifs = [] }
                } label: {
                    Text("Clear all")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(pInk)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Capsule().fill(pCard))
                }
                Button {
                    os.settingsPage = "notifs"
                    if let a = appFor("settings") { os.launch(a) }
                } label: {
                    Image(systemName: "gearshape")
                        .foregroundColor(pInk)
                        .frame(width: 56, height: 50)
                        .background(Capsule().fill(pCard))
                }
            }
        }
    }
}

struct QSPanel: View {
    @EnvironmentObject var os: OS
    let cols = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]

    var body: some View {
        VStack(spacing: 12) {
            ShadeStatus()
            LazyVGrid(columns: cols, spacing: 10) {
                PixelTile(icon: "wifi", title: "Internet", sub: os.wifi ? "Connected" : "Off", on: os.wifi) { os.wifi.toggle() }
                PixelTile(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", sub: os.bt ? "On" : "Off", on: os.bt) { os.bt.toggle() }
                PixelTile(icon: "moon.fill", title: "Modes", sub: os.dnd ? "Do Not Disturb" : "Off", on: os.dnd) { os.dnd.toggle() }
                PixelTile(icon: "flashlight.on.fill", title: "Flashlight", sub: os.flash ? "On" : "Off", on: os.flash) { os.flash.toggle() }
                PixelTile(icon: "moon.stars", title: "Night Light", sub: os.nightLight ? "On" : "Off", on: os.nightLight) { os.nightLight.toggle() }
                PixelTile(icon: "display", title: "Screen on", sub: os.keepAwake ? "On" : "Off", on: os.keepAwake) { os.keepAwake.toggle() }
                PixelTile(icon: "airplane", title: "Airplane", sub: os.airplane ? "On" : "Off", on: os.airplane) { os.airplane.toggle() }
                PixelTile(icon: "battery.25", title: "Battery Saver", sub: os.saver ? "On" : "Off", on: os.saver) { os.saver.toggle() }
                PixelTile(icon: "lock.fill", title: "Lock", sub: "", on: false) {
                    os.home()
                    withAnimation(.easeOut(duration: 0.25)) { os.locked = true }
                }
                PixelTile(icon: "bell.fill", title: "Notifications", sub: "\(os.notifs.count)", on: false) {
                    withAnimation(.easeOut(duration: 0.25)) { os.panel = .notif }
                }
            }
            BrightBar(v: $os.brightness, light: true)
        }
    }
}

struct Shade: View {
    @EnvironmentObject var os: OS
    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [rgb(0.74, 0.80, 0.89), rgb(0.88, 0.90, 0.95)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                if os.panel == .notif { NotifPanel() } else { QSPanel() }
                Spacer(minLength: 0)
                Capsule()
                    .fill(pInk.opacity(0.35))
                    .frame(width: 120, height: 5)
                    .padding(.bottom, 12)
                    .onTapGesture { os.closePanel() }
            }
            .padding(.horizontal, 14)
            .padding(.top, max(os.top, 24) - 10)
        }
        .simultaneousGesture(
            DragGesture().onEnded { v in
                if v.translation.height < -50 {
                    os.closePanel()
                } else if v.translation.height > 60 && os.panel == .notif && v.startLocation.y < 200 {
                    withAnimation(.easeOut(duration: 0.25)) { os.panel = .qs }
                }
            }
        )
    }
}

