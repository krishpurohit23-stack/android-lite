import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreML
import Vision
import CoreImage

// Upscaler.swift - Real-ESRGAN 4x (Core ML) tile upscaler used by the Camera "EN" button. Read CLAUDE.md before editing.
// The model file RealESRGAN.mlmodelc is created and added to the app by the GitHub workflow.
// If it is missing, `available` is false and the camera falls back to the Core Image enhancer.

final class ESRGAN {
    static let shared = ESRGAN()
    private var model: VNCoreMLModel?
    private let ctx = CIContext()
    private let tile = 128
    private let pad = 8

    var available: Bool { model != nil }

    init() {
        guard let url = Bundle.main.url(forResource: "RealESRGAN", withExtension: "mlmodelc") else { return }
        let cfg = MLModelConfiguration()
        cfg.computeUnits = .all
        if let ml = try? MLModel(contentsOf: url, configuration: cfg),
           let vm = try? VNCoreMLModel(for: ml) {
            model = vm
        }
    }

    static func resize(_ cg: CGImage, _ w: Int, _ h: Int) -> CGImage? {
        guard let c = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        c.interpolationQuality = .high
        c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        return c.makeImage()
    }

    /// 4x upscale. Keep the input small (about 640 px or less); the work is done in 128x128 tiles.
    func upscale4x(_ img: CGImage) -> CGImage? {
        guard let vm = model else { return nil }
        let W = img.width
        let H = img.height
        let outW = W * 4
        let outH = H * 4
        guard let canvas = CGContext(data: nil, width: outW, height: outH, bitsPerComponent: 8, bytesPerRow: 0,
                                     space: CGColorSpaceCreateDeviceRGB(),
                                     bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        let clamped = CIImage(cgImage: img).clampedToExtent()
        let step = tile - 2 * pad
        let cols = (W + step - 1) / step
        let rows = (H + step - 1) / step
        for r in 0..<rows {
            for c in 0..<cols {
                let x0 = c * step
                let y0 = r * step
                let x1 = min(x0 + step, W)
                let y1 = min(y0 + step, H)
                let sx = x0 - pad
                let sy = y0 - pad
                let rect = CGRect(x: sx, y: H - (sy + tile), width: tile, height: tile)
                guard let tcg = ctx.createCGImage(clamped.cropped(to: rect), from: rect) else { continue }
                let req = VNCoreMLRequest(model: vm)
                req.imageCropAndScaleOption = .scaleFill
                let handler = VNImageRequestHandler(cgImage: tcg, options: [:])
                do { try handler.perform([req]) } catch { continue }
                guard let obs = req.results?.first as? VNPixelBufferObservation else { continue }
                let oci = CIImage(cvPixelBuffer: obs.pixelBuffer)
                guard let ocg = ctx.createCGImage(oci, from: oci.extent) else { continue }
                let crop = CGRect(x: pad * 4, y: pad * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4)
                guard let inner = ocg.cropping(to: crop) else { continue }
                canvas.draw(inner, in: CGRect(x: x0 * 4, y: outH - y1 * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4))
            }
        }
        return canvas.makeImage()
    }
}

// MARK: - Steady shot: burst frames -> keep the sharpest -> align (Vision) -> average
// Used by the Camera for zoomed and telephoto photos. Every step falls back to the single sharpest frame.
enum Steady {
    static let ctx = CIContext()

    static func sizeOf(_ d: Data) -> CGSize {
        guard let src = CGImageSourceCreateWithData(d as CFData, nil),
              let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return .zero }
        let w = (p[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 0
        let h = (p[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue ?? 0
        return CGSize(width: w, height: h)
    }

    static func maxSide(_ d: Data) -> CGFloat {
        let s = sizeOf(d)
        return max(s.width, s.height)
    }

    static func orientation(_ d: Data) -> UIImage.Orientation {
        guard let src = CGImageSourceCreateWithData(d as CFData, nil),
              let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let o = (p[kCGImagePropertyOrientation] as? NSNumber)?.intValue else { return .up }
        switch o {
        case 2: return .upMirrored
        case 3: return .down
        case 4: return .downMirrored
        case 5: return .leftMirrored
        case 6: return .right
        case 7: return .rightMirrored
        case 8: return .left
        default: return .up
        }
    }

    /// Downsampled decode (no EXIF rotation, so it matches the raw pixel layout).
    static func thumb(_ d: Data, _ maxPx: Int) -> CGImage? {
        guard let src = CGImageSourceCreateWithData(d as CFData, nil) else { return nil }
        let o: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: false,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: max(16, maxPx)
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, o as CFDictionary)
    }

    static func centerCrop(_ cg: CGImage, _ ex: CGFloat) -> CGImage {
        if ex <= 1.01 { return cg }
        let w = CGFloat(cg.width) / ex
        let h = CGFloat(cg.height) / ex
        let r = CGRect(x: (CGFloat(cg.width) - w) / 2, y: (CGFloat(cg.height) - h) / 2, width: w, height: h).integral
        return cg.cropping(to: r) ?? cg
    }

    /// Mean squared gradient on a <=320 px gray copy. Higher = sharper (same scene, so frames are comparable).
    static func energy(_ cg: CGImage) -> Double {
        let m = CGFloat(max(cg.width, cg.height))
        var src = cg
        if m > 320 {
            let k = 320 / m
            if let r = ESRGAN.resize(cg, max(8, Int(CGFloat(cg.width) * k)), max(8, Int(CGFloat(cg.height) * k))) { src = r }
        }
        let w = src.width
        let h = src.height
        if w < 5 || h < 5 { return 0 }
        var buf = [UInt8](repeating: 0, count: w * h)
        let ok: Bool = buf.withUnsafeMutableBytes { p in
            guard let c = CGContext(data: p.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w,
                                    space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            c.draw(src, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        if !ok { return 0 }
        var sum = 0.0
        for y in 1..<(h - 1) {
            for x in 1..<(w - 1) {
                let i = y * w + x
                let gx = Int(buf[i + 1]) - Int(buf[i - 1])
                let gy = Int(buf[i + w]) - Int(buf[i - w])
                sum += Double(gx * gx + gy * gy)
            }
        }
        return sum / Double(w * h)
    }

    /// Sharpness of the part of the frame that ends up in the photo (center crop when digitally zoomed).
    static func sharpness(_ d: Data, ex: CGFloat) -> Double {
        let side = maxSide(d)
        if side <= 0 { return 0 }
        let e = max(ex, 1)
        let px = Int(min(side, 320 * e))
        guard let cg = thumb(d, px) else { return 0 }
        return energy(centerCrop(cg, e))
    }

    static func translation(_ floating: CGImage, _ ref: CGImage) -> CGAffineTransform? {
        let req = VNTranslationalImageRegistrationRequest(targetedCGImage: floating, options: [:])
        let h = VNImageRequestHandler(cgImage: ref, options: [:])
        do { try h.perform([req]) } catch { return nil }
        guard let obs = req.results?.first as? VNImageTranslationAlignmentObservation else { return nil }
        return obs.alignmentTransform
    }

    /// frames = (jpeg/heic data, sharpness). Returns the merged, already center-cropped photo (nil only if nothing could be decoded).
    static func fuse(_ frames: [(Data, Double)], ex: CGFloat, zoom: CGFloat, sensor: CGFloat) -> UIImage? {
        if frames.isEmpty { return nil }
        var best = 0
        for i in 0..<frames.count where frames[i].1 > frames[best].1 { best = i }
        let e = max(ex, 1)
        let sens = sensor > 0 ? sensor : maxSide(frames[best].0)
        let trueSide = sens / max(zoom, 1)
        let croppedSide = sens / e
        let work = min(croppedSide, max(768, trueSide * 1.6))
        let px = Int(min(sens, work * e))
        let orient = orientation(frames[best].0)
        guard let refRaw = thumb(frames[best].0, px) else { return nil }
        let ref = centerCrop(refRaw, e)
        let single = UIImage(cgImage: ref, scale: 1, orientation: orient)

        var others: [Int] = []
        for i in 0..<frames.count where i != best && frames[i].1 >= frames[best].1 * 0.55 { others.append(i) }
        if others.isEmpty { return single }

        let W = ref.width
        let H = ref.height
        let longSide = CGFloat(max(W, H))
        let sm: CGFloat = longSide > 640 ? 640 / longSide : 1
        let sw = max(16, Int(CGFloat(W) * sm))
        let sh = max(16, Int(CGFloat(H) * sm))
        guard let smallRef = ESRGAN.resize(ref, sw, sh) else { return single }
        let kx = CGFloat(W) / CGFloat(sw)
        let ky = CGFloat(H) / CGFloat(sh)
        let fullRect = CGRect(x: 0, y: 0, width: W, height: H)

        var acc: CGImage = ref
        var n = 1
        var maxShift: CGFloat = 0
        for i in others {
            guard let raw = thumb(frames[i].0, px) else { continue }
            var cur = centerCrop(raw, e)
            if cur.width != W || cur.height != H {
                guard let r = ESRGAN.resize(cur, W, H) else { continue }
                cur = r
            }
            guard let smallCur = ESRGAN.resize(cur, sw, sh), let t = translation(smallCur, smallRef) else { continue }
            let tx = t.tx * kx
            let ty = t.ty * ky
            if abs(tx) > CGFloat(W) * 0.06 || abs(ty) > CGFloat(H) * 0.06 { continue }
            let moved = CIImage(cgImage: cur).transformed(by: CGAffineTransform(translationX: tx, y: ty))
            guard let f = CIFilter(name: "CIDissolveTransition") else { continue }
            f.setValue(CIImage(cgImage: acc), forKey: kCIInputImageKey)
            f.setValue(moved, forKey: kCIInputTargetImageKey)
            f.setValue(1.0 / Double(n + 1), forKey: kCIInputTimeKey)
            guard let o = f.outputImage, let r = ctx.createCGImage(o, from: fullRect) else { continue }
            acc = r
            n += 1
            maxShift = max(maxShift, max(abs(tx), abs(ty)))
        }
        if n == 1 { return single }

        // the shifted frames leave a thin empty border: cut it away
        let m = Int(ceil(maxShift)) + 2
        let crop = CGRect(x: m, y: m, width: W - 2 * m, height: H - 2 * m)
        guard crop.width > 16, crop.height > 16, let out = acc.cropping(to: crop), let refCrop = ref.cropping(to: crop) else { return single }
        // safety net: if alignment went wrong the merge is softer than the best single frame -> use the single frame
        if energy(out) < energy(refCrop) * 0.85 {
            return UIImage(cgImage: refCrop, scale: 1, orientation: orient)
        }
        return UIImage(cgImage: out, scale: 1, orientation: orient)
    }
}
