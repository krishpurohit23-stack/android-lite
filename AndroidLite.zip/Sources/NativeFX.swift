import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// NativeFX.swift - Core Animation overlay for the app open/close zoom + the anchor view that finds our window. Read CLAUDE.md before editing.

// MARK: - Native app open/close animation (Core Animation, independent of SwiftUI redraws)
enum NativeFX {
    /// A tiny UIView living inside our SwiftUI tree. Its window/superview chain is always OUR screen,
    /// so overlays never end up in the wrong window.
    static weak var anchor: UIView?

    static func keyWindow() -> UIWindow? {
        let wins = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
        return wins.first(where: { $0.isKeyWindow }) ?? wins.first
    }

    static func container() -> UIView? {
        if let a = anchor {
            if let w = a.window { return w }
            var v: UIView = a
            while let s = v.superview { v = s }
            return v
        }
        return keyWindow()
    }

    static func iconRect(_ r: CGRect?, in b: CGRect) -> CGRect {
        if let r = r, r.width > 1 { return r }
        return CGRect(x: b.midX - 29, y: b.maxY - 130, width: 58, height: 58)
    }

    static func snapshotImage() -> UIImage? {
        guard let v = container() else { return nil }
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        let r = UIGraphicsImageRenderer(size: v.bounds.size, format: fmt)
        return r.image { _ in v.drawHierarchy(in: v.bounds, afterScreenUpdates: false) }
    }

    /// Returns false when no container exists (caller then uses the SwiftUI fallback).
    @discardableResult
    static func open(symbol: String, tint: UIColor, from r: CGRect?, radius: CGFloat, duration: Double, done: @escaping () -> Void) -> Bool {
        guard let w = container() else { return false }
        let full = w.bounds
        let start = iconRect(r, in: full)

        let dim = UIView(frame: full)
        dim.backgroundColor = UIColor.black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        w.addSubview(dim)

        let card = UIView(frame: start)
        card.backgroundColor = UIColor(red: 0.08, green: 0.09, blue: 0.11, alpha: 1)
        card.clipsToBounds = true
        card.layer.cornerCurve = .continuous
        card.layer.cornerRadius = radius
        card.isUserInteractionEnabled = false

        let wash = UIView(frame: card.bounds)
        wash.backgroundColor = tint.withAlphaComponent(0.35)
        wash.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        card.addSubview(wash)

        let cfg = UIImage.SymbolConfiguration(pointSize: 30, weight: .medium)
        let iv = UIImageView(image: UIImage(systemName: symbol, withConfiguration: cfg))
        iv.tintColor = tint
        iv.contentMode = .center
        iv.frame = CGRect(x: 0, y: 0, width: start.width, height: start.height)
        iv.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
        card.addSubview(iv)
        w.addSubview(card)

        let corner = CABasicAnimation(keyPath: "cornerRadius")
        corner.fromValue = radius
        corner.toValue = 0
        corner.duration = duration
        corner.timingFunction = CAMediaTimingFunction(name: .easeOut)
        card.layer.add(corner, forKey: "corner")
        card.layer.cornerRadius = 0

        UIView.animate(withDuration: duration * 0.35, animations: { iv.alpha = 0 })
        UIView.animate(withDuration: duration * 0.7, delay: duration * 0.2, options: [], animations: { wash.alpha = 0 }, completion: nil)
        UIView.animate(withDuration: duration, animations: { dim.alpha = 0.35 })
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 0.3,
                       options: [.curveEaseOut], animations: {
            card.frame = full
        }, completion: { _ in
            done()
            UIView.animate(withDuration: 0.2, animations: {
                card.alpha = 0
                dim.alpha = 0
            }, completion: { _ in
                card.removeFromSuperview()
                dim.removeFromSuperview()
            })
        })
        return true
    }

    static func close(to r: CGRect?, radius: CGFloat, duration: Double, ready: () -> Void) {
        guard let w = container(), let snap = w.snapshotView(afterScreenUpdates: false) else {
            ready()
            return
        }
        let full = w.bounds
        snap.frame = full
        snap.clipsToBounds = true
        snap.layer.cornerCurve = .continuous
        snap.layer.cornerRadius = 40
        snap.isUserInteractionEnabled = false
        w.addSubview(snap)
        ready()
        let end = iconRect(r, in: full)
        let corner = CABasicAnimation(keyPath: "cornerRadius")
        corner.fromValue = 40
        corner.toValue = radius
        corner.duration = duration
        corner.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        snap.layer.add(corner, forKey: "corner")
        snap.layer.cornerRadius = radius
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 0.95, initialSpringVelocity: 0,
                       options: [.curveEaseInOut], animations: {
            snap.frame = end
        }, completion: nil)
        UIView.animate(withDuration: duration * 0.4, delay: duration * 0.6, options: [], animations: {
            snap.alpha = 0
        }, completion: { _ in snap.removeFromSuperview() })
    }
}

final class AnchorView: UIView {}

struct WindowAnchor: UIViewRepresentable {
    func makeUIView(context: Context) -> AnchorView {
        let v = AnchorView()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        NativeFX.anchor = v
        return v
    }
    func updateUIView(_ v: AnchorView, context: Context) { NativeFX.anchor = v }
}
