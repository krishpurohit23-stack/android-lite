import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Browser.swift - Chrome-like browser on WKWebView (PiP, background play, add as web app). Read CLAUDE.md before editing.

// MARK: - Chrome (real browser on WKWebView)
final class WebModel: ObservableObject {
    let web: WKWebView
    @Published var url = ""
    @Published var progress = 0.0
    @Published var canBack = false
    @Published var canFwd = false
    @Published var loading = false
    private var obs: [NSKeyValueObservation] = []
    static let home = "https://www.google.com"

    init(start: String = WebModel.home) {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.allowsPictureInPictureMediaPlayback = true
        cfg.allowsAirPlayForMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        web = WKWebView(frame: UIScreen.main.bounds, configuration: cfg)
        web.allowsBackForwardNavigationGestures = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 28, right: 0)
        obs = [
            web.observe(\.estimatedProgress) { [weak self] w, _ in
                DispatchQueue.main.async { self?.progress = w.estimatedProgress }
            },
            web.observe(\.url) { [weak self] w, _ in
                DispatchQueue.main.async { self?.url = w.url?.absoluteString ?? "" }
            },
            web.observe(\.canGoBack) { [weak self] w, _ in
                DispatchQueue.main.async { self?.canBack = w.canGoBack }
            },
            web.observe(\.canGoForward) { [weak self] w, _ in
                DispatchQueue.main.async { self?.canFwd = w.canGoForward }
            },
            web.observe(\.isLoading) { [weak self] w, _ in
                DispatchQueue.main.async { self?.loading = w.isLoading }
            }
        ]
        go(start)
    }

    /// Starts Picture in Picture for the first video on the page (needs the audio background mode, set by the workflow).
    func pip() {
        let js = "(function(){var v=document.querySelector('video');if(!v){return 'none';}if(v.webkitSetPresentationMode){v.webkitSetPresentationMode('picture-in-picture');return 'ok';}if(v.requestPictureInPicture){v.requestPictureInPicture();return 'ok';}return 'unsupported';})()"
        web.evaluateJavaScript(js, completionHandler: nil)
    }

    func go(_ text: String) {
        var t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return }
        var target: URL?
        if t.contains(" ") || !t.contains(".") {
            let q = t.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? t
            target = URL(string: "https://www.google.com/search?q=" + q)
        } else {
            if !t.hasPrefix("http://") && !t.hasPrefix("https://") { t = "https://" + t }
            target = URL(string: t)
        }
        if let u = target { web.load(URLRequest(url: u)) }
    }
}

struct WebHost: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ v: WKWebView, context: Context) {}
}

struct BrowserApp: View {
    @EnvironmentObject var os: OS
    var body: some View {
        BrowserBody(m: os.browser).onAppear {
            let m = os.browser
            os.backHandlers["web"] = {
                if m.canBack { m.web.goBack(); return true }
                return false
            }
        }
    }
}

struct BrowserBody: View {
    @EnvironmentObject var os: OS
    @ObservedObject var m: WebModel
    @State var text = ""
    @FocusState var focused: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: m.url.hasPrefix("https") ? "lock.fill" : "globe")
                    .font(.system(size: 11))
                    .foregroundColor(.white.opacity(0.7))
                TextField("Search or type URL", text: $text)
                    .focused($focused)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .keyboardType(.webSearch)
                    .submitLabel(.go)
                    .font(.system(size: 13))
                    .foregroundColor(.white)
                    .onSubmit { m.go(text); focused = false }
                Button {
                    if m.loading { m.web.stopLoading() } else { m.web.reload() }
                } label: {
                    Image(systemName: m.loading ? "xmark" : "arrow.clockwise")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                }
                Menu {
                    Button { os.installWebApp(url: m.url, wholeSite: false) } label: {
                        Label("Add this page as web app", systemImage: "plus.app")
                    }
                    Button { os.installWebApp(url: m.url, wholeSite: true) } label: {
                        Label("Add whole site as web app", systemImage: "globe")
                    }
                    Button { m.pip() } label: {
                        Label("Picture in Picture", systemImage: "pip.enter")
                    }
                    Button { os.bgPlay.toggle() } label: {
                        Label(os.bgPlay ? "Background play: On" : "Background play: Off", systemImage: "speaker.wave.2")
                    }
                    Button { m.go(WebModel.home) } label: {
                        Label("Home", systemImage: "house")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.8))
                        .frame(width: 20, height: 30)
                }
            }
            .padding(.horizontal, 12)
            .frame(width: UIScreen.main.bounds.width * 0.7, height: 30)
            .background(Capsule().fill(T.card))
            .frame(maxWidth: .infinity)
            .padding(.top, max(os.top, 28) - 6)
            .padding(.bottom, 4)

            ZStack(alignment: .top) {
                WebHost(web: m.web)
                if m.loading {
                    GeometryReader { g in
                        Rectangle().fill(T.accent)
                            .frame(width: g.size.width * CGFloat(m.progress), height: 3)
                    }
                    .frame(height: 3)
                }
            }
        }
        .onReceive(m.$url) { u in if !focused { text = u } }
        .onAppear { text = m.url }
    }
}
