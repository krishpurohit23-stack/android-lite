import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Models.swift - Plain data: AppInfo, app lists, wallpapers, settings categories, notification/message models. Read CLAUDE.md before editing.

// MARK: - Models
struct AppInfo: Identifiable {
    let id: String
    let name: String
    let icon: String
    let tint: Color
    var letter: String? = nil
    var url: String? = nil
}

struct CallRec: Codable, Identifiable {
    var id: String
    var kind: String      // "out", "in" or "missed"
    var number: String
    var date: Double
    var duration: Double
}

struct WebAppRec: Codable, Identifiable {
    var id: String
    var name: String
    var url: String
}

let allApps: [AppInfo] = [
    AppInfo(id: "phone", name: "Phone", icon: "phone.fill", tint: Color(red: 0.55, green: 0.9, blue: 0.6)),
    AppInfo(id: "msg", name: "Messages", icon: "message.fill", tint: Color(red: 0.55, green: 0.75, blue: 1.0)),
    AppInfo(id: "web", name: "Chrome", icon: "globe", tint: Color(red: 1.0, green: 0.75, blue: 0.4)),
    AppInfo(id: "cam", name: "Camera", icon: "camera.fill", tint: Color(red: 0.95, green: 0.6, blue: 0.85)),
    AppInfo(id: "calc", name: "Calculator", icon: "plus.forwardslash.minus", tint: Color(red: 1.0, green: 0.85, blue: 0.45)),
    AppInfo(id: "cal", name: "Calendar", icon: "calendar", tint: Color(red: 0.6, green: 0.8, blue: 1.0)),
    AppInfo(id: "clock", name: "Clock", icon: "clock.fill", tint: Color(red: 0.75, green: 0.7, blue: 1.0)),
    AppInfo(id: "photos", name: "Photos", icon: "photo.fill", tint: Color(red: 1.0, green: 0.65, blue: 0.6)),
    AppInfo(id: "notes", name: "Keep Notes", icon: "note.text", tint: Color(red: 1.0, green: 0.9, blue: 0.5)),
    AppInfo(id: "settings", name: "Settings", icon: "gearshape.fill", tint: Color(red: 0.7, green: 0.8, blue: 0.85))
]

func appFor(_ id: String) -> AppInfo? { allApps.first(where: { $0.id == id }) }
func iconFor(_ id: String) -> String { appFor(id)?.icon ?? "bell.fill" }
func tintFor(_ id: String) -> Color { appFor(id)?.tint ?? T.accent }

func siteName(_ urlStr: String) -> String {
    guard let u = URL(string: urlStr), let host = u.host else { return "Web app" }
    var parts = host.split(separator: ".").map { String($0) }
    if parts.first == "www" { parts.removeFirst() }
    var name = parts.first ?? host
    if parts.count >= 2 {
        let tld = parts[parts.count - 1]
        let sld = parts[parts.count - 2]
        if parts.count >= 3 && tld.count == 2 && ["co", "com", "org", "net", "gov", "ac"].contains(sld) {
            name = parts[parts.count - 3]
        } else {
            name = sld
        }
    }
    if name.isEmpty { return "Web app" }
    return name.prefix(1).uppercased() + String(name.dropFirst())
}

func siteOrigin(_ urlStr: String) -> String {
    guard let u = URL(string: urlStr), let h = u.host, let sch = u.scheme else { return urlStr }
    return sch + "://" + h + "/"
}

func faviconURL(_ u: String?) -> URL? {
    guard let u = u, let host = URL(string: u)?.host else { return nil }
    return URL(string: "https://www.google.com/s2/favicons?domain=" + host + "&sz=128")
}

let webTints: [Color] = [
    Color(red: 0.55, green: 0.9, blue: 0.6),
    Color(red: 0.55, green: 0.75, blue: 1.0),
    Color(red: 1.0, green: 0.75, blue: 0.4),
    Color(red: 0.95, green: 0.6, blue: 0.85),
    Color(red: 0.75, green: 0.7, blue: 1.0),
    Color(red: 1.0, green: 0.65, blue: 0.6)
]

func webTint(_ id: String) -> Color {
    let n = id.unicodeScalars.reduce(0) { $0 + Int($1.value) }
    return webTints[n % webTints.count]
}

let sortedApps: [AppInfo] = allApps.sorted { $0.name < $1.name }
let dockApps: [AppInfo] = ["phone", "msg", "web", "cam"].compactMap { appFor($0) }
let homeApps: [AppInfo] = ["calc", "cal", "clock", "photos", "notes", "settings"].compactMap { appFor($0) }

struct Notif: Identifiable {
    let id = UUID()
    let appId: String
    let title: String
    let body: String
    let date: Date
}

struct Contact: Identifiable {
    let id: String
    let name: String
    let color: Color
}

struct Msg: Identifiable {
    let id = UUID()
    let text: String
    let mine: Bool
}

let contacts: [Contact] = [
    Contact(id: "team", name: "Pixel Team", color: Color(red: 0.5, green: 0.85, blue: 0.6)),
    Contact(id: "mom", name: "Mom", color: Color(red: 1.0, green: 0.6, blue: 0.7)),
    Contact(id: "alex", name: "Alex", color: Color(red: 0.55, green: 0.7, blue: 1.0))
]
let canned: [String] = ["Haha okay!", "Sounds good 👍", "Call you later", "On my way", "Nice!", "Let's do it"]

enum Panel { case none, notif, qs }

struct WP {
    let name: String
    let a: Color
    let b: Color
    let c: Color
    let d: Color
}

let wallpapers: [WP] = [
    WP(name: "Dusk", a: rgb(0.05, 0.08, 0.20), b: rgb(0.16, 0.10, 0.30), c: rgb(0.30, 0.50, 0.90), d: rgb(0.85, 0.40, 0.70)),
    WP(name: "Aurora", a: rgb(0.02, 0.12, 0.15), b: rgb(0.05, 0.20, 0.30), c: rgb(0.20, 0.90, 0.60), d: rgb(0.40, 0.50, 1.00)),
    WP(name: "Sunset", a: rgb(0.20, 0.06, 0.15), b: rgb(0.40, 0.12, 0.10), c: rgb(1.00, 0.50, 0.20), d: rgb(1.00, 0.30, 0.50)),
    WP(name: "Ocean", a: rgb(0.00, 0.08, 0.18), b: rgb(0.00, 0.20, 0.35), c: rgb(0.10, 0.60, 0.90), d: rgb(0.00, 0.80, 0.80)),
    WP(name: "Forest", a: rgb(0.03, 0.10, 0.05), b: rgb(0.06, 0.18, 0.10), c: rgb(0.40, 0.80, 0.30), d: rgb(0.80, 0.90, 0.40)),
    WP(name: "Berry", a: rgb(0.15, 0.03, 0.12), b: rgb(0.28, 0.05, 0.22), c: rgb(0.90, 0.30, 0.70), d: rgb(0.60, 0.30, 1.00)),
    WP(name: "Desert", a: rgb(0.22, 0.14, 0.08), b: rgb(0.35, 0.20, 0.10), c: rgb(1.00, 0.70, 0.35), d: rgb(0.90, 0.45, 0.30)),
    WP(name: "Midnight", a: rgb(0.02, 0.02, 0.06), b: rgb(0.05, 0.05, 0.12), c: rgb(0.30, 0.30, 0.70), d: rgb(0.50, 0.30, 0.80)),
    WP(name: "Neon", a: rgb(0.04, 0.00, 0.10), b: rgb(0.10, 0.00, 0.20), c: rgb(0.00, 1.00, 0.90), d: rgb(1.00, 0.20, 0.80)),
    WP(name: "Peach", a: rgb(0.25, 0.12, 0.14), b: rgb(0.40, 0.20, 0.20), c: rgb(1.00, 0.70, 0.60), d: rgb(1.00, 0.85, 0.60))
]

let animNames: [String] = [
    "iPhone zoom (native)", "Window zoom", "Classic zoom", "Slide up", "Fade",
    "Slide from right", "Pop", "Flip", "Drop down", "Circle reveal"
]

struct SCat: Identifiable {
    let id: String
    let title: String
    let sub: String
    let icon: String
    let tint: Color
}

let settingsCats: [SCat] = [
    SCat(id: "network", title: "Network & internet", sub: "Wi-Fi, airplane mode", icon: "wifi", tint: rgb(0.55, 0.75, 1.0)),
    SCat(id: "devices", title: "Connected devices", sub: "Bluetooth, pairing", icon: "dot.radiowaves.left.and.right", tint: rgb(0.75, 0.70, 1.0)),
    SCat(id: "apps", title: "Apps", sub: "Installed apps and web apps", icon: "square.grid.2x2.fill", tint: rgb(1.0, 0.75, 0.40)),
    SCat(id: "notifs", title: "Notifications", sub: "Banners, Do Not Disturb", icon: "bell.fill", tint: rgb(1.0, 0.65, 0.60)),
    SCat(id: "battery", title: "Battery", sub: "Level and Battery Saver", icon: "battery.100", tint: rgb(0.55, 0.90, 0.60)),
    SCat(id: "storage", title: "Storage", sub: "Space used and free", icon: "internaldrive.fill", tint: rgb(0.70, 0.80, 0.85)),
    SCat(id: "sound", title: "Sound & vibration", sub: "Touch haptics", icon: "speaker.wave.2.fill", tint: rgb(0.95, 0.60, 0.85)),
    SCat(id: "display", title: "Display", sub: "Brightness, screen on, motion", icon: "sun.max.fill", tint: rgb(1.0, 0.85, 0.45)),
    SCat(id: "wallpaper", title: "Wallpaper & style", sub: "Wallpapers, colors, icon shape", icon: "paintpalette.fill", tint: rgb(0.95, 0.60, 0.85)),
    SCat(id: "home", title: "Home screen", sub: "Widgets, clock, grid", icon: "house.fill", tint: rgb(0.60, 0.80, 1.0)),
    SCat(id: "anim", title: "App animations", sub: "10 styles and speed", icon: "sparkles", tint: rgb(0.75, 0.70, 1.0)),
    SCat(id: "access", title: "Accessibility", sub: "Reduce motion, developer", icon: "figure.stand", tint: rgb(0.55, 0.90, 0.60)),
    SCat(id: "security", title: "Security & privacy", sub: "Lock screen, hide content", icon: "lock.fill", tint: rgb(1.0, 0.65, 0.60)),
    SCat(id: "location", title: "Location", sub: "Permissions on iOS", icon: "location.fill", tint: rgb(0.55, 0.75, 1.0)),
    SCat(id: "wellbeing", title: "Digital Wellbeing", sub: "App usage", icon: "hourglass", tint: rgb(0.55, 0.90, 0.60)),
    SCat(id: "system", title: "System", sub: "Reset and gestures", icon: "gearshape.2.fill", tint: rgb(0.70, 0.80, 0.85)),
    SCat(id: "about", title: "About phone", sub: "Device and build", icon: "info.circle.fill", tint: rgb(0.75, 0.70, 1.0))
]

func gb(_ bytes: Int64) -> String { String(format: "%.1f GB", Double(bytes) / 1_000_000_000) }

func storageInfo() -> (free: Int64, total: Int64) {
    let url = URL(fileURLWithPath: NSHomeDirectory())
    let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeTotalCapacityKey])
    let free: Int64 = v?.volumeAvailableCapacityForImportantUsage ?? 0
    let total: Int64 = Int64(v?.volumeTotalCapacity ?? 0)
    return (free, total)
}

func durText(_ s: Double) -> String {
    let m = Int(s) / 60
    return m < 1 ? "\(Int(s)) sec" : "\(m) min"
}
