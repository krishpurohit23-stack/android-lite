import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Theme.swift - Colors (accent palettes), UserDefaults helpers, small global helpers. Read CLAUDE.md before editing.

// MARK: - Theme (Material 3 Expressive / Pixel look)
enum T {
    static var palette = 0
    static let accents: [Color] = [
        Color(red: 0.66, green: 0.78, blue: 1.0),
        Color(red: 0.62, green: 0.90, blue: 0.66),
        Color(red: 1.0, green: 0.72, blue: 0.82),
        Color(red: 1.0, green: 0.78, blue: 0.50),
        Color(red: 0.80, green: 0.72, blue: 1.0),
        Color(red: 0.55, green: 0.90, blue: 0.90)
    ]
    static let onAccents: [Color] = [
        Color(red: 0.0, green: 0.18, blue: 0.38),
        Color(red: 0.0, green: 0.25, blue: 0.10),
        Color(red: 0.35, green: 0.0, blue: 0.15),
        Color(red: 0.30, green: 0.15, blue: 0.0),
        Color(red: 0.20, green: 0.05, blue: 0.40),
        Color(red: 0.0, green: 0.25, blue: 0.25)
    ]
    static let bg = Color(red: 0.08, green: 0.09, blue: 0.11)
    static let card = Color(red: 0.16, green: 0.18, blue: 0.22)
    static var accent: Color { accents[min(max(palette, 0), 5)] }
    static var onAccent: Color { onAccents[min(max(palette, 0), 5)] }
}

enum UD {
    static func b(_ k: String, _ d: Bool) -> Bool {
        UserDefaults.standard.object(forKey: k) == nil ? d : UserDefaults.standard.bool(forKey: k)
    }
    static func i(_ k: String, _ d: Int) -> Int {
        UserDefaults.standard.object(forKey: k) == nil ? d : UserDefaults.standard.integer(forKey: k)
    }
}

func rgb(_ r: Double, _ g: Double, _ b: Double) -> Color { Color(red: r, green: g, blue: b) }

func fmtDate(_ f: String) -> String {
    let d = DateFormatter()
    d.dateFormat = f
    return d.string(from: Date())
}
