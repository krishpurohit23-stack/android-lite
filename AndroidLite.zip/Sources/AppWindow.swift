import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// AppWindow.swift - AppWindow router (which app view to show), AppHost (animation styles), web app view. Read CLAUDE.md before editing.

// MARK: - App window (full screen)
struct AppWindow: View {
    @EnvironmentObject var os: OS
    let app: AppInfo

    var body: some View {
        content
            .padding(.top, (app.id == "cam" || app.id == "web" || app.id.hasPrefix("web:")) ? 0 : os.padTop - 8)
            .padding(.bottom, (app.id == "cam" || app.id == "web" || app.id.hasPrefix("web:")) ? 0 : 34)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(T.bg.ignoresSafeArea())
    }

    @ViewBuilder var content: some View {
        switch app.id {
        case "calc": CalcView()
        case "clock": ClockApp()
        case "cal": CalendarApp()
        case "notes": NotesApp()
        case "settings": SettingsApp()
        case "phone": DialerApp()
        case "web": BrowserApp()
        case "msg": MessagesApp()
        case "cam": CameraApp()
        case "photos": PhotosApp()
        default:
            if app.id.hasPrefix("web:") { WebAppView(app: app) } else { EmptyView() }
        }
    }
}

struct Fx {
    var sc: CGFloat = 1
    var ox: CGFloat = 0
    var oy: CGFloat = 0
    var flip: Double = 0
    var op: Double = 1
    var r: CGFloat = 0
    var anchor: UnitPoint = .center
}

struct AppHost: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    let anchor: UnitPoint

    func fx(_ p: CGFloat) -> Fx {
        let sz = UIScreen.main.bounds.size
        var f = Fx()
        switch os.animStyle {
        case 0:
            if NativeFX.container() == nil {
                f.sc = 0.12 + 0.88 * p
                f.op = min(1, Double(p) * 5)
                f.r = 220 * pow(1 - p, 3)
                f.anchor = anchor
            } else {
                f.op = Double(p)
            }
        case 1:
            f.op = min(1, Double(p) * 6)
        case 2:
            f.sc = 0.12 + 0.88 * p
            f.op = min(1, Double(p) * 5)
            f.r = 220 * pow(1 - p, 3)
            f.anchor = anchor
        case 3:
            f.sc = 0.96 + 0.04 * p
            f.oy = (1 - p) * sz.height * 0.55
            f.op = min(1, Double(p) * 4)
            f.r = 40 * (1 - p)
        case 4:
            f.sc = 0.88 + 0.12 * p
            f.op = Double(p)
            f.r = 36 * (1 - p)
        case 5:
            f.ox = (1 - p) * sz.width
            f.op = min(1, Double(p) * 4)
        case 6:
            let o = p + 0.12 * sin(p * CGFloat.pi)
            f.sc = 0.5 + 0.5 * o
            f.op = min(1, Double(p) * 4)
            f.r = 50 * (1 - p)
        case 7:
            f.flip = Double(1 - p) * -90
            f.op = min(1, Double(p) * 3)
        case 8:
            f.oy = -(1 - p) * sz.height * 0.5
            f.sc = 0.94 + 0.06 * p
            f.op = min(1, Double(p) * 4)
        default:
            break
        }
        return f
    }

    func morphView(_ p: CGFloat, _ sz: CGSize, _ op: Double) -> some View {
        let ir = os.originRect ?? CGRect(x: sz.width / 2 - 29, y: sz.height - 130, width: 58, height: 58)
        let mw = ir.width + (sz.width - ir.width) * p
        let mh = ir.height + (sz.height - ir.height) * p
        let cx = ir.midX + (sz.width / 2 - ir.midX) * p
        let cy = ir.midY + (sz.height / 2 - ir.midY) * p
        let rr = os.iconRadius * (1 - p)
        return AppWindow(app: app)
            .frame(width: sz.width, height: sz.height)
            .scaleEffect(max(mw / sz.width, 0.01))
            .frame(width: mw, height: mh)
            .clipShape(RoundedRectangle(cornerRadius: rr, style: .continuous))
            .position(x: cx, y: cy)
            .opacity(op)
    }

    func circleView(_ p: CGFloat, _ sz: CGSize) -> some View {
        let c = os.origin ?? CGPoint(x: sz.width / 2, y: sz.height - 100)
        let maxR = hypot(max(c.x, sz.width - c.x), max(c.y, sz.height - c.y))
        let r = 29 + (maxR - 29) * p
        return AppWindow(app: app)
            .mask(
                Circle()
                    .frame(width: r * 2, height: r * 2)
                    .position(x: c.x, y: c.y)
            )
            .opacity(min(1, Double(p) * 8))
    }

    var body: some View {
        let p = os.prog
        let f = fx(p)
        let bp = min(1, os.backDrag / 200)
        let sz = UIScreen.main.bounds.size
        if os.animStyle == 1 {
            morphView(p, sz, f.op)
        } else if os.animStyle == 9 {
            circleView(p, sz)
        } else {
            AppWindow(app: app)
                .clipShape(RoundedRectangle(cornerRadius: max(f.r, 38 * bp), style: .continuous))
                .scaleEffect(f.sc * (1 - bp * 0.08), anchor: f.anchor)
                .rotation3DEffect(.degrees(f.flip), axis: (x: 0, y: 1, z: 0), perspective: 0.6)
                .offset(x: f.ox, y: f.oy)
                .opacity(f.op)
        }
    }
}

struct WebProgress: View {
    @ObservedObject var m: WebModel
    var body: some View {
        if m.loading {
            GeometryReader { g in
                Rectangle().fill(T.accent)
                    .frame(width: g.size.width * CGFloat(m.progress), height: 3)
            }
            .frame(height: 3)
        }
    }
}

struct WebAppView: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    var body: some View {
        let m = os.webModel(for: app)
        VStack(spacing: 0) {
            Color.clear.frame(height: max(os.top, 28))
            ZStack(alignment: .top) {
                WebHost(web: m.web)
                WebProgress(m: m)
            }
        }
        .onAppear {
            os.backHandlers[app.id] = {
                if m.canBack { m.web.goBack(); return true }
                return false
            }
        }
    }
}

struct Title: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(size: 30, weight: .regular))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 22)
            .padding(.vertical, 10)
    }
}
