import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// AppsComms.swift - Phone dialer and Messages. Read CLAUDE.md before editing.

// MARK: - Phone (real calls through iOS)
struct DialerApp: View {
    @State var num = ""
    let keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"]
    let cols = Array(repeating: GridItem(.flexible()), count: 3)

    func call() {
        let digits = num.filter { "0123456789+".contains($0) }
        if digits.isEmpty { return }
        if let u = URL(string: "tel://" + digits) { UIApplication.shared.open(u) }
    }

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Text(num.isEmpty ? " " : num)
                .font(.system(size: 36, weight: .light))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
            LazyVGrid(columns: cols, spacing: 14) {
                ForEach(keys, id: \.self) { k in
                    Button { num += k } label: {
                        Text(k)
                            .font(.system(size: 28))
                            .foregroundColor(.white)
                            .frame(width: 72, height: 72)
                            .background(Circle().fill(T.card))
                    }
                }
            }
            .padding(.horizontal, 30)
            HStack(spacing: 40) {
                Button { call() } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .frame(width: 72, height: 72)
                        .background(Circle().fill(Color.green))
                }
                Button { if !num.isEmpty { num.removeLast() } } label: {
                    Image(systemName: "delete.left.fill")
                        .foregroundColor(.white.opacity(0.8))
                        .frame(width: 72, height: 72)
                }
            }
            Spacer().frame(height: 10)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Messages (local chats, replies arrive as notifications)
struct MessagesApp: View {
    @EnvironmentObject var os: OS
    @State var chat: Contact? = nil

    var body: some View {
        inner.onAppear {
            os.backHandlers["msg"] = {
                if chat != nil { chat = nil; return true }
                return false
            }
        }
    }

    @ViewBuilder var inner: some View {
        if let c = chat {
            ChatView(contact: c) { chat = nil }
        } else {
            VStack(spacing: 0) {
                Title(text: "Messages")
                ScrollView {
                    ForEach(contacts) { c in
                        Button { chat = c } label: {
                            HStack(spacing: 14) {
                                Text(String(c.name.prefix(1)))
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundColor(T.bg)
                                    .frame(width: 48, height: 48)
                                    .background(Circle().fill(c.color))
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(c.name).font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                                    Text(os.threads[c.id]?.last?.text ?? "")
                                        .font(.system(size: 14)).foregroundColor(.white.opacity(0.65)).lineLimit(1)
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct ChatView: View {
    @EnvironmentObject var os: OS
    let contact: Contact
    let back: () -> Void
    @State var text = ""

    var msgs: [Msg] { os.threads[contact.id] ?? [] }

    func send() {
        let t = text.trimmingCharacters(in: .whitespaces)
        if t.isEmpty { return }
        os.threads[contact.id, default: []].append(Msg(text: t, mine: true))
        text = ""
        let cid = contact.id
        let name = contact.name
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            let r = canned.randomElement() ?? "ok"
            os.threads[cid, default: []].append(Msg(text: r, mine: false))
            let watching = os.open?.id == "msg" && os.viewingChat == cid
            if !watching { os.post("msg", name, r) }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { back() } label: {
                    Image(systemName: "chevron.left").foregroundColor(.white).frame(width: 40, height: 40)
                }
                Text(String(contact.name.prefix(1)))
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(T.bg)
                    .frame(width: 36, height: 36)
                    .background(Circle().fill(contact.color))
                Text(contact.name).font(.system(size: 20)).foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal, 12)
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 6) {
                        ForEach(msgs) { m in
                            HStack {
                                if m.mine { Spacer(minLength: 60) }
                                Text(m.text)
                                    .padding(.horizontal, 14).padding(.vertical, 10)
                                    .foregroundColor(m.mine ? T.onAccent : .white)
                                    .background(RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .fill(m.mine ? T.accent : T.card))
                                if !m.mine { Spacer(minLength: 60) }
                            }
                            .id(m.id)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.top, 10)
                }
                .onChange(of: msgs.count) { _ in
                    if let last = msgs.last { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
            HStack(spacing: 10) {
                TextField("Message", text: $text)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .frame(height: 48)
                    .background(Capsule().fill(T.card))
                    .submitLabel(.send)
                    .onSubmit { send() }
                Button { send() } label: {
                    Image(systemName: "arrow.up")
                        .foregroundColor(T.onAccent)
                        .frame(width: 48, height: 48)
                        .background(Circle().fill(T.accent))
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .onAppear { os.viewingChat = contact.id }
        .onDisappear { os.viewingChat = nil }
    }
}
