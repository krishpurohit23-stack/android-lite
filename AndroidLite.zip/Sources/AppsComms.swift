import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CallKit

// AppsComms.swift - Phone dialer and Messages. Read CLAUDE.md before editing.

// MARK: - Phone (real calls through iOS)
final class CallWatcher: NSObject, CXCallObserverDelegate {
    let observer = CXCallObserver()
    weak var os: OS?
    var started: [UUID: Date] = [:]
    var connected: [UUID: Date] = [:]

    init(os: OS) {
        self.os = os
        super.init()
        observer.setDelegate(self, queue: .main)
    }

    func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
        if started[call.uuid] == nil { started[call.uuid] = Date() }
        if call.hasConnected && connected[call.uuid] == nil { connected[call.uuid] = Date() }
        if call.hasEnded {
            let t0 = started[call.uuid] ?? Date()
            let dur: Double = connected[call.uuid].map { Date().timeIntervalSince($0) } ?? 0
            var kind = "missed"
            if call.isOutgoing {
                kind = "out"
            } else if connected[call.uuid] != nil {
                kind = "in"
            }
            let number = call.isOutgoing ? (os?.pendingDial ?? "") : ""
            os?.addCall(kind: kind, number: number, date: t0, duration: dur)
            started[call.uuid] = nil
            connected[call.uuid] = nil
        }
    }
}

struct DialerApp: View {
    @EnvironmentObject var os: OS
    @State var tab = 0
    @State var num = ""
    @State var showGA = false
    let keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"]
    let cols = Array(repeating: GridItem(.flexible()), count: 3)

    func call(_ number: String) {
        let digits = number.filter { "0123456789+".contains($0) }
        if digits.isEmpty { return }
        os.pendingDial = digits
        if UIAccessibility.isGuidedAccessEnabled { showGA = true }
        if let u = URL(string: "tel://" + digits) { UIApplication.shared.open(u) }
    }

    func label(_ c: CallRec) -> String {
        let f = DateFormatter()
        f.dateFormat = "MMM d, h:mm a"
        let kind = c.kind == "out" ? "Outgoing" : (c.kind == "in" ? "Incoming" : "Missed")
        var t = kind + " · " + f.string(from: Date(timeIntervalSince1970: c.date))
        if c.duration > 0 { t += " · " + durText(c.duration) }
        return t
    }

    var keypad: some View {
        VStack(spacing: 18) {
            Spacer()
            Text(num.isEmpty ? " " : num)
                .font(.system(size: 36, weight: .light))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
            LazyVGrid(columns: cols, spacing: 14) {
                ForEach(keys, id: \.self) { k in
                    Button { num += k } label: {
                        Text(k)
                            .font(.system(size: 28))
                            .foregroundColor(.white)
                            .frame(width: 72, height: 72)
                            .background(Circle().fill(T.card))
                    }
                }
            }
            .padding(.horizontal, 30)
            HStack(spacing: 40) {
                Button { call(num) } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .frame(width: 72, height: 72)
                        .background(Circle().fill(Color.green))
                }
                Button { if !num.isEmpty { num.removeLast() } } label: {
                    Image(systemName: "delete.left.fill")
                        .foregroundColor(.white.opacity(0.8))
                        .frame(width: 72, height: 72)
                }
            }
            Spacer().frame(height: 10)
        }
        .frame(maxWidth: .infinity)
    }

    func row(_ c: CallRec) -> some View {
        HStack(spacing: 14) {
            Image(systemName: c.kind == "out" ? "phone.arrow.up.right" : (c.kind == "in" ? "phone.arrow.down.left" : "phone.down"))
                .foregroundColor(c.kind == "missed" ? Color.red : T.accent)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(c.number.isEmpty ? "Unknown number" : c.number).foregroundColor(.white)
                Text(label(c)).font(.system(size: 12)).foregroundColor(.white.opacity(0.6))
            }
            Spacer()
            if !c.number.isEmpty {
                Button { call(c.number) } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .frame(width: 40, height: 40)
                        .background(Circle().fill(Color.green))
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            if !c.number.isEmpty {
                num = c.number
                tab = 0
            }
        }
    }

    var recents: some View {
        VStack(spacing: 0) {
            if os.calls.isEmpty {
                Spacer()
                Text("No calls yet. Calls you make or get while Android Lite is open show up here.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white.opacity(0.6))
                    .padding(30)
                Spacer()
            } else {
                ScrollView {
                    VStack(spacing: 2) {
                        ForEach(os.calls) { c in row(c) }
                    }
                }
                Button { os.calls = [] } label: {
                    Text("Clear history")
                        .foregroundColor(.white)
                        .padding(.horizontal, 22).padding(.vertical, 10)
                        .background(Capsule().fill(T.card))
                }
                .padding(.vertical, 10)
            }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            Title(text: "Phone")
            ChipRow(items: ["Keypad", "Recents"], selected: tab) { tab = $0 }
            if tab == 0 { keypad } else { recents }
        }
        .alert("Guided Access is on", isPresented: $showGA) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("iOS blocks starting calls while Guided Access is on. To call: triple-click the side button, enter your passcode and tap End, place the call, then start Guided Access again. Incoming calls still ring normally.")
        }
    }
}

// MARK: - Messages (local chats, replies arrive as notifications)
struct MessagesApp: View {
    @EnvironmentObject var os: OS
    @State var chat: Contact? = nil

    var body: some View {
        inner.onAppear {
            os.backHandlers["msg"] = {
                if chat != nil { chat = nil; return true }
                return false
            }
        }
    }

    @ViewBuilder var inner: some View {
        if let c = chat {
            ChatView(contact: c) { chat = nil }
        } else {
            VStack(spacing: 0) {
                Title(text: "Messages")
                ScrollView {
                    ForEach(contacts) { c in
                        Button { chat = c } label: {
                            HStack(spacing: 14) {
                                Text(String(c.name.prefix(1)))
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundColor(T.bg)
                                    .frame(width: 48, height: 48)
                                    .background(Circle().fill(c.color))
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(c.name).font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                                    Text(os.threads[c.id]?.last?.text ?? "")
                                        .font(.system(size: 14)).foregroundColor(.white.opacity(0.65)).lineLimit(1)
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct ChatView: View {
    @EnvironmentObject var os: OS
    let contact: Contact
    let back: () -> Void
    @State var text = ""

    var msgs: [Msg] { os.threads[contact.id] ?? [] }

    func send() {
        let t = text.trimmingCharacters(in: .whitespaces)
        if t.isEmpty { return }
        os.threads[contact.id, default: []].append(Msg(text: t, mine: true))
        text = ""
        let cid = contact.id
        let name = contact.name
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            let r = canned.randomElement() ?? "ok"
            os.threads[cid, default: []].append(Msg(text: r, mine: false))
            let watching = os.open?.id == "msg" && os.viewingChat == cid
            if !watching { os.post("msg", name, r) }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { back() } label: {
                    Image(systemName: "chevron.left").foregroundColor(.white).frame(width: 40, height: 40)
                }
                Text(String(contact.name.prefix(1)))
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(T.bg)
                    .frame(width: 36, height: 36)
                    .background(Circle().fill(contact.color))
                Text(contact.name).font(.system(size: 20)).foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal, 12)
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 6) {
                        ForEach(msgs) { m in
                            HStack {
                                if m.mine { Spacer(minLength: 60) }
                                Text(m.text)
                                    .padding(.horizontal, 14).padding(.vertical, 10)
                                    .foregroundColor(m.mine ? T.onAccent : .white)
                                    .background(RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .fill(m.mine ? T.accent : T.card))
                                if !m.mine { Spacer(minLength: 60) }
                            }
                            .id(m.id)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.top, 10)
                }
                .onChange(of: msgs.count) { _ in
                    if let last = msgs.last { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
            HStack(spacing: 10) {
                TextField("Message", text: $text)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .frame(height: 48)
                    .background(Capsule().fill(T.card))
                    .submitLabel(.send)
                    .onSubmit { send() }
                Button { send() } label: {
                    Image(systemName: "arrow.up")
                        .foregroundColor(T.onAccent)
                        .frame(width: 48, height: 48)
                        .background(Circle().fill(T.accent))
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .onAppear { os.viewingChat = contact.id }
        .onDisappear { os.viewingChat = nil }
    }
}
