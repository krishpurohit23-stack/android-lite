import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Launcher.swift - Home screen (free icon placement, widgets, lock screen), app drawer, Pixel-style recents. Read CLAUDE.md before editing.

// MARK: - Home
struct FramePref: PreferenceKey {
    static var defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { value = nextValue() }
}

struct IconGlyph: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: os.iconRadius,
                             style: os.iconShape == 0 ? RoundedCornerStyle.circular : RoundedCornerStyle.continuous)
                .fill(app.tint.opacity(0.22))
            if let l = app.letter {
                if let fu = faviconURL(app.url) {
                    AsyncImage(url: fu) { phase in
                        if let img = phase.image {
                            img.resizable().scaledToFit().frame(width: 32, height: 32)
                        } else {
                            Text(l).font(.system(size: 24, weight: .bold)).foregroundColor(app.tint)
                        }
                    }
                } else {
                    Text(l).font(.system(size: 24, weight: .bold)).foregroundColor(app.tint)
                }
            } else {
                Image(systemName: app.icon)
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(app.tint)
            }
        }
        .frame(width: 58, height: 58)
    }
}

struct Icon: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    var label = true
    var inHome = false
    @State var frame: CGRect = .zero

    var body: some View {
        Button {
            if os.editHome && inHome { return }
            os.launch(app, from: frame == .zero ? nil : frame)
        } label: {
            VStack(spacing: 6) {
                IconGlyph(app: app)
                    .background(GeometryReader { gp in
                        Color.clear.preference(key: FramePref.self, value: gp.frame(in: .global))
                    })
                if label {
                    Text(app.name)
                        .font(.system(size: 11))
                        .foregroundColor(.white)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity)
            .onPreferenceChange(FramePref.self) { frame = $0 }
        }
        .buttonStyle(.plain)
        .contextMenu {
            if !inHome {
                if os.homeIds.contains(app.id) {
                    Button { os.homeIds.removeAll { $0 == app.id } } label: {
                        Label("Remove from home screen", systemImage: "minus.circle")
                    }
                } else {
                    Button { os.homeIds.append(app.id) } label: {
                        Label("Add to home screen", systemImage: "plus.circle")
                    }
                }
                if app.id.hasPrefix("web:") {
                    Button(role: .destructive) {
                        os.removeWebApp(String(app.id.dropFirst(4)))
                    } label: {
                        Label("Remove web app", systemImage: "trash")
                    }
                }
            }
        }
    }
}

// MARK: - Free icon placement (long press the home screen, then drag icons anywhere)
struct HomeIcon: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    let base: CGPoint
    let area: CGSize
    @State var drag: CGSize = .zero
    @State var wiggle = false

    var body: some View {
        let cellW = area.width / CGFloat(max(os.gridCols, 1))
        Icon(app: app, inHome: true)
            .frame(width: cellW)
            .overlay(alignment: .topLeading) {
                if os.editHome {
                    Button { os.homeIds.removeAll { $0 == app.id } } label: {
                        Image(systemName: "minus.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.red)
                            .background(Circle().fill(Color.white))
                    }
                    .offset(x: (cellW - 58) / 2 - 8, y: 0)
                }
            }
            .rotationEffect(.degrees(os.editHome ? (wiggle ? 1.8 : -1.8) : 0))
            .position(x: base.x + drag.width, y: base.y + drag.height)
            .simultaneousGesture(
                DragGesture(minimumDistance: 6)
                    .onChanged { v in
                        if os.editHome { drag = v.translation }
                    }
                    .onEnded { v in
                        if os.editHome {
                            let nx = min(max(base.x + v.translation.width, 30), area.width - 30)
                            let ny = min(max(base.y + v.translation.height, 40), area.height - 40)
                            os.iconPos[app.id] = [Double(nx / area.width), Double(ny / area.height)]
                        }
                        drag = .zero
                    }
            )
            .onChange(of: os.editHome) { on in
                if on {
                    withAnimation(.easeInOut(duration: 0.13).repeatForever(autoreverses: true)) { wiggle = true }
                } else {
                    withAnimation(.default) { wiggle = false }
                }
            }
    }
}

struct FreeArea: View {
    @EnvironmentObject var os: OS

    func pos(_ i: Int, _ a: AppInfo, _ sz: CGSize) -> CGPoint {
        if let p = os.iconPos[a.id], p.count == 2 {
            return CGPoint(x: CGFloat(p[0]) * sz.width, y: CGFloat(p[1]) * sz.height)
        }
        let cols = max(os.gridCols, 1)
        let col = i % cols
        let row = i / cols
        return CGPoint(x: (CGFloat(col) + 0.5) * sz.width / CGFloat(cols), y: CGFloat(row) * 96 + 52)
    }

    var body: some View {
        GeometryReader { g in
            ZStack {
                ForEach(Array(os.homeAppList.enumerated()), id: \.element.id) { pair in
                    HomeIcon(app: pair.element, base: pos(pair.offset, pair.element, g.size), area: g.size)
                }
            }
            .frame(width: g.size.width, height: g.size.height)
        }
        .frame(maxHeight: .infinity)
    }
}

struct StackClock: View {
    func s(_ f: String) -> String { fmtDate(f) }
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            VStack(alignment: .leading, spacing: -12) {
                Text(s("hh")).foregroundColor(.white)
                Text(s("mm")).foregroundColor(T.accent)
            }
            .font(.system(size: 78, weight: .bold, design: .rounded))
        }
    }
}

struct DigitalClock: View {
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            Text(fmtDate("h:mm"))
                .font(.system(size: 66, weight: .light, design: .rounded))
                .foregroundColor(.white)
        }
    }
}

struct WidgetCard: View {
    @EnvironmentObject var os: OS
    let kind: String

    func title() -> String {
        switch kind {
        case "battery": return "Battery"
        case "calendar": return "Calendar"
        case "notes": return "Keep Notes"
        case "storage": return "Storage"
        default: return "Notifications"
        }
    }

    func big() -> String {
        switch kind {
        case "battery":
            let l = UIDevice.current.batteryLevel
            return l < 0 ? "--" : "\(Int(l * 100))%"
        case "calendar":
            return fmtDate("d MMM")
        case "notes":
            return "Note"
        case "storage":
            return gb(storageInfo().free)
        default:
            return "\(os.notifs.count)"
        }
    }

    func small() -> String {
        switch kind {
        case "battery":
            return os.saver ? "Battery Saver on" : "Looking good"
        case "calendar":
            let ev = os.events[fmtDate("yyyy-MM-dd")] ?? []
            return ev.first ?? "No events today"
        case "notes":
            let n = UserDefaults.standard.string(forKey: "androidlite_note") ?? ""
            return n.isEmpty ? "Tap to write a note" : n
        case "storage":
            return "free"
        default:
            return os.notifs.first?.title ?? "All caught up"
        }
    }

    func go() {
        switch kind {
        case "calendar":
            if let a = appFor("cal") { os.launch(a) }
        case "notes":
            if let a = appFor("notes") { os.launch(a) }
        case "notifs":
            withAnimation(.easeOut(duration: 0.25)) { os.panel = .notif }
        default:
            if let a = appFor("settings") { os.launch(a) }
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title()).font(.system(size: 12)).opacity(0.7)
            Text(big()).font(.system(size: 26, weight: .semibold))
            Text(small()).font(.system(size: 12)).opacity(0.75).lineLimit(2)
            if kind == "battery" {
                ProgressView(value: Double(max(0, UIDevice.current.batteryLevel))).tint(T.accent)
            }
        }
        .foregroundColor(.white)
        .frame(maxWidth: .infinity, minHeight: 96, alignment: .topLeading)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(T.card.opacity(0.92)))
        .onTapGesture { go() }
    }
}

struct LockScreen: View {
    @EnvironmentObject var os: OS
    @State var dy: CGFloat = 0

    var body: some View {
        ZStack {
            Wallpaper()
            Color.black.opacity(0.25)
            VStack(spacing: 10) {
                Spacer().frame(height: 100)
                StackClock()
                Text(fmtDate("EEEE, MMM d")).font(.system(size: 18, weight: .medium))
                if !os.notifs.isEmpty {
                    Text("\(os.notifs.count) notifications")
                        .font(.system(size: 13))
                        .padding(.horizontal, 14).padding(.vertical, 7)
                        .background(Capsule().fill(Color.white.opacity(0.15)))
                }
                Spacer()
                Image(systemName: "chevron.up")
                Text("Swipe up to unlock").font(.system(size: 13)).opacity(0.7)
                Spacer().frame(height: 50)
            }
            .foregroundColor(.white)
        }
        .ignoresSafeArea()
        .offset(y: dy)
        .gesture(
            DragGesture()
                .onChanged { v in dy = min(0, v.translation.height) }
                .onEnded { v in
                    if v.translation.height < -100 {
                        withAnimation(.easeIn(duration: 0.22)) { dy = -UIScreen.main.bounds.height }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
                            os.locked = false
                            dy = 0
                        }
                    } else {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { dy = 0 }
                    }
                }
        )
    }
}

struct Home: View {
    @EnvironmentObject var os: OS
    @State var q = ""
    @FocusState var focus: Bool

    var cols: [GridItem] { Array(repeating: GridItem(.flexible(), spacing: 8), count: os.gridCols) }

    func openDrawer() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { os.drawer = true }
    }

    func search() {
        let t = q.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return }
        os.browser.go(t)
        q = ""
        focus = false
        if let w = appFor("web") { os.launch(w) }
    }

    var body: some View {
        VStack(spacing: 0) {
            if os.showClock {
                VStack(alignment: .leading, spacing: 4) {
                    if os.clockStyle == 0 { StackClock() } else { DigitalClock() }
                    Text(fmtDate("EEEE, MMM d"))
                        .font(.system(size: 17, weight: .medium))
                        .foregroundColor(.white)
                    if os.showBuild {
                        Text("build \(Build.number)" + (os.debug.isEmpty ? "" : " · " + os.debug))
                            .font(.system(size: 11))
                            .foregroundColor(.white.opacity(0.35))
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 28)
            }
            if !os.widgets.isEmpty {
                HStack(spacing: 10) {
                    ForEach(Array(os.widgets.prefix(2)), id: \.self) { k in WidgetCard(kind: k) }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
            }
            FreeArea()
            HStack {
                ForEach(dockApps) { a in Icon(app: a, label: false) }
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 14)
            if os.showSearch {
                HStack(spacing: 12) {
                    Text("G").font(.system(size: 20, weight: .bold)).foregroundColor(T.accent)
                    TextField("Search", text: $q)
                        .focused($focus)
                        .foregroundColor(.white)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                        .keyboardType(.webSearch)
                        .submitLabel(.search)
                        .onSubmit { search() }
                    Image(systemName: "mic.fill").foregroundColor(.white.opacity(0.8))
                    Image(systemName: "camera.viewfinder").foregroundColor(.white.opacity(0.8))
                }
                .padding(.horizontal, 20)
                .frame(height: 52)
                .background(Capsule().fill(T.card.opacity(0.95)))
                .padding(.horizontal, 16)
            }
            Spacer().frame(height: 50)
        }
        .padding(.top, os.padTop)
        .contentShape(Rectangle())
        .simultaneousGesture(LongPressGesture(minimumDuration: 0.6).onEnded { _ in
            if !os.editHome { os.editHome = true }
        })
        .simultaneousGesture(TapGesture(count: 2).onEnded {
            if os.doubleTapLock && !os.editHome {
                withAnimation(.easeOut(duration: 0.25)) { os.locked = true }
            }
        })
        .overlay(alignment: .top) {
            if os.editHome {
                HStack(spacing: 10) {
                    Button { os.editHome = false } label: {
                        Text("Done")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(T.onAccent)
                            .padding(.horizontal, 20).padding(.vertical, 9)
                            .background(Capsule().fill(T.accent))
                    }
                    Button { os.iconPos = [:] } label: {
                        Text("Reset layout")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white)
                            .padding(.horizontal, 20).padding(.vertical, 9)
                            .background(Capsule().fill(T.card))
                    }
                }
                .padding(.top, os.padTop - 28)
            }
        }
    }
}

// MARK: - App drawer
struct Drawer: View {
    @EnvironmentObject var os: OS
    @State var q = ""
    let cols = Array(repeating: GridItem(.flexible(), spacing: 8), count: 4)

    var list: [AppInfo] {
        let all = (sortedApps + os.webAppInfos).sorted { $0.name.lowercased() < $1.name.lowercased() }
        if q.isEmpty { return all }
        return all.filter { $0.name.lowercased().contains(q.lowercased()) }
    }

    var body: some View {
        VStack(spacing: 12) {
            Capsule().fill(Color.white.opacity(0.3))
                .frame(width: 40, height: 5)
                .frame(maxWidth: .infinity, minHeight: 28)
                .contentShape(Rectangle())
                .gesture(DragGesture().onEnded { v in
                    if v.translation.height > 40 {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { os.drawer = false }
                    }
                })
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundColor(.white.opacity(0.7))
                TextField("Search apps", text: $q)
                    .foregroundColor(.white)
                    .disableAutocorrection(true)
                    .submitLabel(.search)
                    .onSubmit {
                        let t = q.trimmingCharacters(in: .whitespacesAndNewlines)
                        if let f = list.first {
                            os.launch(f)
                        } else if !t.isEmpty {
                            os.browser.go(t)
                            if let w = appFor("web") { os.launch(w) }
                        }
                    }
            }
            .padding(.horizontal, 18)
            .frame(height: 52)
            .background(Capsule().fill(T.card))
            .padding(.horizontal, 16)
            ScrollView {
                LazyVGrid(columns: cols, spacing: 22) {
                    ForEach(list) { a in Icon(app: a) }
                }
                .padding(.horizontal, 12)
                .padding(.top, 12)
            }
        }
        .padding(.top, os.padTop - 24)
        .padding(.bottom, 40)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(T.bg.opacity(0.97).ignoresSafeArea())
    }
}

// MARK: - Recents (Pixel style: real snapshots, icon + name above each card, swipe up to dismiss)
struct RecentCard: View {
    @EnvironmentObject var os: OS
    let app: AppInfo
    @State var dy: CGFloat = 0

    var body: some View {
        let sz = UIScreen.main.bounds.size
        let cw = sz.width * 0.68
        let ch = sz.height * 0.58
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                IconGlyph(app: app).scaleEffect(0.5).frame(width: 30, height: 30)
                Text(app.name).font(.system(size: 14, weight: .medium)).foregroundColor(.white)
                Spacer()
            }
            .frame(width: cw)
            Button { os.launch(app) } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 30, style: .continuous).fill(T.card)
                    if let img = os.snaps[app.id] {
                        Image(uiImage: img).resizable().scaledToFill()
                    } else {
                        Image(systemName: app.icon).font(.system(size: 54)).foregroundColor(app.tint)
                    }
                }
                .frame(width: cw, height: ch)
                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .offset(y: dy)
        .opacity(1 - Double(abs(dy)) / 400)
        .gesture(
            DragGesture()
                .onChanged { v in dy = min(0, v.translation.height) }
                .onEnded { v in
                    if v.translation.height < -90 {
                        withAnimation { os.recents.removeAll { $0.id == app.id } }
                    } else {
                        withAnimation { dy = 0 }
                    }
                }
        )
    }
}

struct Recents: View {
    @EnvironmentObject var os: OS
    var body: some View {
        let sz = UIScreen.main.bounds.size
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea().onTapGesture { os.home() }
            if os.recents.isEmpty {
                Text("No recent apps").foregroundColor(.white.opacity(0.75))
            } else {
                VStack(spacing: 22) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 18) {
                            ForEach(os.recents) { a in RecentCard(app: a) }
                        }
                        .padding(.horizontal, (sz.width - sz.width * 0.68) / 2)
                    }
                    .frame(height: sz.height * 0.58 + 60)
                    Button {
                        withAnimation { os.recents = [] }
                        os.snaps = [:]
                    } label: {
                        Text("Clear all")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(T.onAccent)
                            .padding(.horizontal, 28).padding(.vertical, 12)
                            .background(Capsule().fill(T.accent))
                    }
                }
            }
        }
    }
}
