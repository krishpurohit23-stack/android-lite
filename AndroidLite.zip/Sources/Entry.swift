import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Entry.swift - UIKit entry: AppDelegate/SceneDelegate, HostVC (hidden home bar), UIKit pan gestures, hooks. Read CLAUDE.md before editing.

// MARK: - Entry (UIKit host: hidden home bar, double-swipe exit, all gestures)
extension UIViewController {
    static func hookClass(_ c: AnyClass) {
        let yes: @convention(block) (AnyObject) -> Bool = { _ in true }
        let all: @convention(block) (AnyObject) -> UInt = { _ in UInt(UIRectEdge.all.rawValue) }
        if let m = class_getInstanceMethod(c, #selector(getter: UIViewController.prefersHomeIndicatorAutoHidden)) {
            method_setImplementation(m, imp_implementationWithBlock(yes))
        }
        if let m = class_getInstanceMethod(c, #selector(getter: UIViewController.prefersStatusBarHidden)) {
            method_setImplementation(m, imp_implementationWithBlock(yes))
        }
        if let m = class_getInstanceMethod(c, #selector(getter: UIViewController.preferredScreenEdgesDeferringSystemGestures)) {
            method_setImplementation(m, imp_implementationWithBlock(all))
        }
    }

    static func installFullScreenHooks() {
        hookClass(UIViewController.self)
    }

    static func hookChain(of vc: UIViewController) {
        var cur: AnyClass? = type(of: vc)
        var guardCount = 0
        while let c = cur, guardCount < 12 {
            hookClass(c)
            if ObjectIdentifier(c) == ObjectIdentifier(UIViewController.self) { break }
            cur = class_getSuperclass(c)
            guardCount += 1
        }
    }
}

final class PanHandler: NSObject, UIGestureRecognizerDelegate {
    let os: OS
    var start = CGPoint.zero
    var mode = 0   // 1 left edge, 2 right edge, 3 bottom, 4 top, 5 free

    init(os: OS) { self.os = os }

    func gestureRecognizer(_ g: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith o: UIGestureRecognizer) -> Bool { true }

    @objc func pan(_ g: UIPanGestureRecognizer) {
        guard let v = g.view else { return }
        let w = v.bounds.width
        let h = v.bounds.height
        let t = g.translation(in: v)
        switch g.state {
        case .began:
            let loc = g.location(in: v)
            start = CGPoint(x: loc.x - t.x, y: loc.y - t.y)
            if start.x < 44 { mode = 1 }
            else if start.x > w - 44 { mode = 2 }
            else if start.y > h - 90 { mode = 3 }
            else if start.y < 90 { mode = 4 }
            else { mode = 5 }
        case .changed:
            if mode == 1 {
                os.backLeft = true
                os.backDrag = max(0, t.x)
            } else if mode == 2 {
                os.backLeft = false
                os.backDrag = max(0, -t.x)
            } else if mode == 3 && os.open != nil && os.appShown {
                os.dragApp(t.y)
            }
        case .ended, .cancelled:
            let vel = g.velocity(in: v)
            os.debug = "swipe m\(mode) \(Int(t.x)),\(Int(t.y))"
            if g.state == .ended {
                switch mode {
                case 1: os.backEnded(t.x)
                case 2: os.backEnded(-t.x)
                case 3: os.bottomEnded(t.y, slow: abs(vel.y) < 500)
                case 4:
                    if t.y > 30 {
                        os.topOpen(left: start.x < w / 2)
                    } else if t.y < -30 && os.panel != .none {
                        os.closePanel()
                    }
                default:
                    free(t)
                }
            } else {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                    os.backDrag = 0
                }
                if os.open != nil && os.appShown { os.animateProg(to: 1, duration: 0.2) }
            }
        default:
            break
        }
    }

    func free(_ t: CGPoint) {
        if os.locked { return }
        if os.panel != .none {
            if t.y < -40 && (start.y > 380 || t.y < -140) {
                os.closePanel()
            } else if t.y > 50 && os.panel == .notif && start.y < 260 {
                withAnimation(.easeOut(duration: 0.25)) { os.panel = .qs }
            }
        } else if os.open == nil && !os.drawer && !os.showRecents {
            if abs(t.y) > abs(t.x) {
                if t.y > 60 {
                    withAnimation(.easeOut(duration: 0.25)) { os.panel = .notif }
                } else if t.y < -60 {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { os.drawer = true }
                }
            }
        } else if os.drawer && t.y > 80 && start.y < 170 {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { os.drawer = false }
        }
    }
}

enum GestureInstaller {
    static var installed = false
    static var retained: PanHandler? = nil

    static func install(os: OS, tries: Int = 0) {
        if installed { return }
        guard let w = NativeFX.container() else {
            if tries < 40 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { install(os: os, tries: tries + 1) }
            }
            return
        }
        let h = PanHandler(os: os)
        retained = h
        let p = UIPanGestureRecognizer(target: h, action: #selector(PanHandler.pan(_:)))
        p.maximumNumberOfTouches = 1
        p.cancelsTouchesInView = false
        p.delaysTouchesBegan = false
        p.delaysTouchesEnded = false
        p.delegate = h
        w.addGestureRecognizer(p)
        installed = true
        let root = (w as? UIWindow)?.rootViewController
        root?.setNeedsUpdateOfHomeIndicatorAutoHidden()
        root?.setNeedsUpdateOfScreenEdgesDeferringSystemGestures()
        let rootName = root.map { NSStringFromClass(type(of: $0)) } ?? "view"
        os.debug = "gestures on · " + rootName
        for d in [0.0, 0.3, 1.0, 2.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + d) {
                UIViewController.installFullScreenHooks()
                refreshBars()
            }
        }
    }

    static func refreshBars() {
        for sc in UIApplication.shared.connectedScenes {
            guard let ws = sc as? UIWindowScene else { continue }
            for w in ws.windows {
                var vc = w.rootViewController
                while let v = vc {
                    UIViewController.hookChain(of: v)
                    v.setNeedsUpdateOfHomeIndicatorAutoHidden()
                    v.setNeedsUpdateOfScreenEdgesDeferringSystemGestures()
                    v.setNeedsStatusBarAppearanceUpdate()
                    vc = v.presentedViewController
                }
            }
        }
    }
}

final class HostVC: UIHostingController<AnyView> {
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var prefersStatusBarHidden: Bool { true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .all }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setNeedsUpdateOfHomeIndicatorAutoHidden()
        setNeedsUpdateOfScreenEdgesDeferringSystemGestures()
    }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let ws = scene as? UIWindowScene else { return }
        let os = OS()
        let w = UIWindow(windowScene: ws)
        let vc = HostVC(rootView: AnyView(PhoneView(os: os).preferredColorScheme(.dark).persistentSystemOverlays(.hidden).defersSystemGestures(on: .all)))
        vc.view.backgroundColor = .black
        w.rootViewController = vc
        w.makeKeyAndVisible()
        window = w
    }
}

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UITextView.appearance().backgroundColor = .clear
        UIViewController.installFullScreenHooks()
        return true
    }

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        let c = UISceneConfiguration(name: "Default", sessionRole: connectingSceneSession.role)
        c.delegateClass = SceneDelegate.self
        return c
    }
}
