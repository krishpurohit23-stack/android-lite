import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// OS.swift - The single ObservableObject (class OS) holding ALL app state, persistence and navigation logic. Read CLAUDE.md before editing.

// MARK: - "OS" state
final class OS: ObservableObject {
    @Published var open: AppInfo? = nil
    @Published var recents: [AppInfo] = []
    @Published var panel: Panel = .none
    @Published var showRecents = false
    @Published var drawer = false
    @Published var appShown = false
    @Published var prog: CGFloat = 0
    var animTimer: Timer? = nil
    @Published var debug = ""
    @Published var animStyle = 0 { didSet { UserDefaults.standard.set(animStyle, forKey: "al_animStyle") } }
    @Published var animSpeed: Double = 1.0 { didSet { UserDefaults.standard.set(animSpeed, forKey: "al_animSpeed") } }
    @Published var webApps: [WebAppRec] = [] { didSet { saveWebApps() } }
    var webModels: [String: WebModel] = [:]
    @Published var reduceMotion = false { didSet { UserDefaults.standard.set(reduceMotion, forKey: "al_reduce") } }
    @Published var wallpaper = 0 { didSet { UserDefaults.standard.set(wallpaper, forKey: "al_wp") } }
    @Published var wallpaperImage: UIImage? = nil
    @Published var theme = 0 {
        didSet {
            T.palette = theme
            UserDefaults.standard.set(theme, forKey: "al_theme")
        }
    }
    @Published var iconShape = 0 { didSet { UserDefaults.standard.set(iconShape, forKey: "al_shape") } }
    @Published var gridCols = 4 { didSet { UserDefaults.standard.set(gridCols, forKey: "al_cols") } }
    @Published var showSearch = true { didSet { UserDefaults.standard.set(showSearch, forKey: "al_search") } }
    @Published var showClock = true { didSet { UserDefaults.standard.set(showClock, forKey: "al_clock") } }
    @Published var clockStyle = 0 { didSet { UserDefaults.standard.set(clockStyle, forKey: "al_clockstyle") } }
    @Published var widgets: [String] = ["battery", "calendar"] {
        didSet { UserDefaults.standard.set(widgets.joined(separator: ","), forKey: "al_widgets") }
    }
    @Published var haptics = true { didSet { UserDefaults.standard.set(haptics, forKey: "al_haptics") } }
    @Published var keepAwake = false {
        didSet {
            UIApplication.shared.isIdleTimerDisabled = keepAwake
            UserDefaults.standard.set(keepAwake, forKey: "al_awake")
        }
    }
    @Published var hideNotif = false { didSet { UserDefaults.standard.set(hideNotif, forKey: "al_hidenotif") } }
    @Published var banners = true { didSet { UserDefaults.standard.set(banners, forKey: "al_banners") } }
    @Published var lockOn = false { didSet { UserDefaults.standard.set(lockOn, forKey: "al_lock") } }
    @Published var locked = false
    @Published var showBuild = true { didSet { UserDefaults.standard.set(showBuild, forKey: "al_build") } }
    @Published var settingsPage = ""
    @Published var usage: [String: Double] = [:] { didSet { UserDefaults.standard.set(usage, forKey: "al_usage") } }
    @Published var launches: [String: Int] = [:] { didSet { UserDefaults.standard.set(launches, forKey: "al_launches") } }
    var sessionStart: Date? = nil
    var launching = false
    var pendingDial = ""
    var callWatcher: CallWatcher? = nil
    @Published var calls: [CallRec] = [] {
        didSet {
            if let d = try? JSONEncoder().encode(calls) { UserDefaults.standard.set(d, forKey: "al_calls") }
        }
    }
    @Published var pages = 1 { didSet { UserDefaults.standard.set(pages, forKey: "al_pages") } }
    @Published var page = 0
    @Published var camEnhance = true { didSet { UserDefaults.standard.set(camEnhance, forKey: "al_camen") } }
    @Published var camEnhanceScale = 4 { didSet { UserDefaults.standard.set(camEnhanceScale, forKey: "al_camenscale") } }
    @Published var camEnhanceTele = 4 { didSet { UserDefaults.standard.set(camEnhanceTele, forKey: "al_camentele") } }
    @Published var camSteady = true { didSet { UserDefaults.standard.set(camSteady, forKey: "al_camsteady") } }
    @Published var iconPage: [String: Int] = [:] { didSet { UserDefaults.standard.set(iconPage, forKey: "al_iconpage") } }
    var snaps: [String: UIImage] = [:]
    @Published var homeIds: [String] = ["calc", "cal", "clock", "photos", "notes", "settings"] {
        didSet { UserDefaults.standard.set(homeIds.joined(separator: ","), forKey: "al_homeids") }
    }
    @Published var iconPos: [String: [Double]] = [:] { didSet { UserDefaults.standard.set(iconPos, forKey: "al_iconpos") } }
    @Published var editHome = false
    @Published var bgPlay = true {
        didSet {
            UserDefaults.standard.set(bgPlay, forKey: "al_bgplay")
            applyAudioSession()
        }
    }
    @Published var nightLight = false { didSet { UserDefaults.standard.set(nightLight, forKey: "al_night") } }
    @Published var nightLevel: Double = 0.5 { didSet { UserDefaults.standard.set(nightLevel, forKey: "al_nightlevel") } }
    @Published var doubleTapLock = true { didSet { UserDefaults.standard.set(doubleTapLock, forKey: "al_dtl") } }
    @Published var backDrag: CGFloat = 0
    @Published var backLeft = true
    @Published var dragProg: CGFloat = 0
    @Published var wifi = true
    @Published var bt = true
    @Published var dnd = false
    @Published var airplane = false
    @Published var saver = false
    @Published var rotate = true
    @Published var flash = false { didSet { OS.torch(flash) } }
    @Published var brightness: Double = Double(UIScreen.main.brightness) {
        didSet { UIScreen.main.brightness = CGFloat(brightness) }
    }
    @Published var notifs: [Notif] = []
    @Published var banner: Notif? = nil
    @Published var threads: [String: [Msg]] = [
        "team": [Msg(text: "Welcome to your new Pixel-style phone ✨", mine: false)],
        "mom": [Msg(text: "Did you eat?", mine: false)],
        "alex": [Msg(text: "Are we still on for later?", mine: false)]
    ]
    @Published var viewingChat: String? = nil
    @Published var events: [String: [String]] = [:]
    @Published var top: CGFloat = 47
    @Published var bottom: CGFloat = 34
    lazy var browser = WebModel()
    var originRect: CGRect? = nil
    var origin: CGPoint? {
        guard let r = originRect else { return nil }
        return CGPoint(x: r.midX, y: r.midY)
    }
    var backHandlers: [String: () -> Bool] = [:]

    init() {
        notifs = [Notif(appId: "msg", title: "Pixel Team", body: "Welcome to Android Lite 16 ✨", date: Date())]
        animStyle = UserDefaults.standard.integer(forKey: "al_animStyle")
        let sp = UserDefaults.standard.double(forKey: "al_animSpeed")
        animSpeed = sp < 0.4 ? 1.0 : sp
        reduceMotion = UD.b("al_reduce", false)
        wallpaper = UD.i("al_wp", 0)
        theme = UD.i("al_theme", 0)
        T.palette = theme
        iconShape = UD.i("al_shape", 0)
        gridCols = UD.i("al_cols", 4)
        showSearch = UD.b("al_search", true)
        showClock = UD.b("al_clock", true)
        clockStyle = UD.i("al_clockstyle", 0)
        if let w = UserDefaults.standard.string(forKey: "al_widgets") {
            widgets = w.split(separator: ",").map { String($0) }
        }
        haptics = UD.b("al_haptics", true)
        keepAwake = UD.b("al_awake", false)
        UIApplication.shared.isIdleTimerDisabled = keepAwake
        hideNotif = UD.b("al_hidenotif", false)
        banners = UD.b("al_banners", true)
        lockOn = UD.b("al_lock", false)
        locked = lockOn
        showBuild = UD.b("al_build", true)
        usage = (UserDefaults.standard.dictionary(forKey: "al_usage") as? [String: Double]) ?? [:]
        launches = (UserDefaults.standard.dictionary(forKey: "al_launches") as? [String: Int]) ?? [:]
        UIDevice.current.isBatteryMonitoringEnabled = true
        if let h = UserDefaults.standard.string(forKey: "al_homeids") {
            homeIds = h.split(separator: ",").map { String($0) }
        }
        iconPos = (UserDefaults.standard.dictionary(forKey: "al_iconpos") as? [String: [Double]]) ?? [:]
        bgPlay = UD.b("al_bgplay", true)
        nightLight = UD.b("al_night", false)
        let nl = UserDefaults.standard.double(forKey: "al_nightlevel")
        nightLevel = nl == 0 ? 0.5 : nl
        doubleTapLock = UD.b("al_dtl", true)
        pages = max(1, UD.i("al_pages", 1))
        iconPage = (UserDefaults.standard.dictionary(forKey: "al_iconpage") as? [String: Int]) ?? [:]
        camEnhance = UD.b("al_camen", true)
        camEnhanceScale = min(max(UD.i("al_camenscale", 4), 4), 30)
        camEnhanceTele = min(max(UD.i("al_camentele", 4), 4), 30)
        camSteady = UD.b("al_camsteady", true)
        if let d = UserDefaults.standard.data(forKey: "al_calls"),
           let arr = try? JSONDecoder().decode([CallRec].self, from: d) {
            calls = arr
        }
        applyAudioSession()
        if wallpaper == 99 { wallpaperImage = Gallery.thumb(OS.wallpaperURL, max: 1600) }
        if let d = UserDefaults.standard.data(forKey: "al_webapps"),
           let arr = try? JSONDecoder().decode([WebAppRec].self, from: d) {
            webApps = arr
        }
    }

    static var wallpaperURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("wallpaper.jpg")
    }

    func setWallpaperPhoto(_ img: UIImage) {
        if let data = img.jpegData(compressionQuality: 0.85) {
            try? data.write(to: OS.wallpaperURL)
            wallpaperImage = Gallery.thumb(OS.wallpaperURL, max: 1600)
            wallpaper = 99
        }
    }

    var homeAppList: [AppInfo] {
        homeIds.compactMap { id in
            allApps.first(where: { $0.id == id }) ?? webAppInfos.first(where: { $0.id == id })
        }
    }

    func applyAudioSession() {
        let s = AVAudioSession.sharedInstance()
        do {
            if bgPlay {
                try s.setCategory(.playback, mode: .moviePlayback, options: [])
            } else {
                try s.setCategory(.ambient, mode: .default, options: [])
            }
            try s.setActive(true)
        } catch {}
    }

    func captureSnap() {
        guard let a = open, let img = NativeFX.snapshotImage() else { return }
        snaps[a.id] = img
    }

    var iconRadius: CGFloat { iconShape == 0 ? 29 : (iconShape == 1 ? 22 : 14) }

    func dur(_ base: Double) -> Double { reduceMotion ? 0.12 : base / animSpeed }

    func appName(_ id: String) -> String {
        if let a = allApps.first(where: { $0.id == id }) { return a.name }
        if let w = webAppInfos.first(where: { $0.id == id }) { return w.name }
        return id
    }

    func endSession() {
        if let a = open, let t = sessionStart {
            usage[a.id, default: 0] += Date().timeIntervalSince(t)
        }
        sessionStart = nil
    }

    func resetSettings() {
        animStyle = 0
        animSpeed = 1.0
        reduceMotion = false
        wallpaper = 0
        wallpaperImage = nil
        theme = 0
        iconShape = 0
        gridCols = 4
        showSearch = true
        showClock = true
        clockStyle = 0
        widgets = ["battery", "calendar"]
        haptics = true
        keepAwake = false
        hideNotif = false
        banners = true
        lockOn = false
        showBuild = true
        homeIds = ["calc", "cal", "clock", "photos", "notes", "settings"]
        iconPos = [:]
        bgPlay = true
        nightLight = false
        doubleTapLock = true
        pages = 1
        page = 0
        iconPage = [:]
        camEnhance = true
        camEnhanceScale = 4
        camEnhanceTele = 4
        camSteady = true
    }

    var webAppInfos: [AppInfo] {
        webApps.map { r in
            AppInfo(id: "web:" + r.id, name: r.name, icon: "globe", tint: webTint(r.id),
                    letter: String(r.name.prefix(1)).uppercased(), url: r.url)
        }
    }

    func saveWebApps() {
        if let d = try? JSONEncoder().encode(webApps) {
            UserDefaults.standard.set(d, forKey: "al_webapps")
        }
    }

    func installWebApp(url: String, wholeSite: Bool) {
        let target = wholeSite ? siteOrigin(url) : url
        if !target.hasPrefix("http") { return }
        if webApps.contains(where: { $0.url == target }) {
            post("web", "Already added", siteName(target))
            return
        }
        let rec = WebAppRec(id: UUID().uuidString, name: siteName(target), url: target)
        webApps.append(rec)
        homeIds.append("web:" + rec.id)
        if let info = webAppInfos.first(where: { $0.id == "web:" + rec.id }) { _ = webModel(for: info) }
        post("web", "Web app added", rec.name + " is on your home screen")
    }

    func removeWebApp(_ id: String) {
        let key = "web:" + id
        webApps.removeAll { $0.id == id }
        homeIds.removeAll { $0 == key }
        iconPos[key] = nil
        webModels[key] = nil
        recents.removeAll { $0.id == key }
        if open?.id == key { home() }
    }

    func webModel(for a: AppInfo) -> WebModel {
        if let m = webModels[a.id] { return m }
        let m = WebModel(start: a.url ?? WebModel.home)
        webModels[a.id] = m
        return m
    }

    var padTop: CGFloat { max(top, 24) + 34 }

    static func torch(_ on: Bool) {
        guard let d = AVCaptureDevice.default(for: .video), d.hasTorch else { return }
        try? d.lockForConfiguration()
        d.torchMode = on ? .on : .off
        d.unlockForConfiguration()
    }

    func post(_ appId: String, _ title: String, _ body: String) {
        let n = Notif(appId: appId, title: title, body: body, date: Date())
        notifs.insert(n, at: 0)
        if dnd || !banners { return }
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { banner = n }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [weak self] in
            if self?.banner?.id == n.id {
                withAnimation { self?.banner = nil }
            }
        }
    }

    var lastFire: [String: Date] = [:]

    func allow(_ k: String) -> Bool {
        let now = Date()
        if let t = lastFire[k], now.timeIntervalSince(t) < 0.5 { return false }
        lastFire[k] = now
        return true
    }

    func backEnded(_ dx: CGFloat) {
        if locked { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { backDrag = 0 }
        if dx > 70 && allow("back") { goBack() }
    }

    func dragApp(_ dy: CGFloat) {
        guard open != nil && appShown && (animStyle == 1 || animStyle == 2) else { return }
        animTimer?.invalidate()
        animTimer = nil
        prog = 1 - 0.7 * min(1, max(0, -dy) / 300)
    }

    func bottomEnded(_ dy: CGFloat, slow: Bool) {
        if locked {
            if dy < -80 { withAnimation(.easeIn(duration: 0.25)) { locked = false } }
            return
        }
        let appOpen = open != nil && appShown
        if dy > -30 {
            if appOpen { animateProg(to: 1, duration: 0.25) }
            return
        }
        guard allow("bottom") else { return }
        if dy < -150 && slow {
            if appOpen { captureSnap() }
            withAnimation(.easeOut(duration: 0.25)) { showRecents = true }
            if appOpen { animateProg(to: 1, duration: 0.25) }
        } else if open == nil && !drawer && !showRecents {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { drawer = true }
        } else {
            home()
        }
    }

    func topOpen(left: Bool) {
        if locked { return }
        guard allow("top") else { return }
        if panel == .none {
            withAnimation(.easeOut(duration: 0.25)) { panel = left ? .notif : .qs }
        } else if panel == .notif {
            withAnimation(.easeOut(duration: 0.25)) { panel = .qs }
        }
    }

    /// Create (and start loading) the browser and every web app right after launch, so they open instantly.
    func preloadWeb() {
        _ = self.browser
        for a in webAppInfos.prefix(6) { _ = webModel(for: a) }
    }

    func addCall(kind: String, number: String, date: Date, duration: Double) {
        let rec = CallRec(id: UUID().uuidString, kind: kind, number: number,
                          date: date.timeIntervalSince1970, duration: duration)
        calls.insert(rec, at: 0)
        if calls.count > 100 { calls = Array(calls.prefix(100)) }
        if kind == "missed" { post("phone", "Missed call", number.isEmpty ? "Unknown number" : number) }
    }

    func openDrawer() {
        guard !locked, open == nil, !drawer, !showRecents, panel == .none, !editHome, allow("drawer") else { return }
        withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { drawer = true }
    }

    func openNotif() {
        guard !locked, !drawer, !showRecents, panel == .none, !editHome, allow("notif") else { return }
        withAnimation(.easeOut(duration: 0.25)) { panel = .notif }
    }

    func changePage(_ d: Int) {
        let n = min(max(page + d, 0), pages - 1)
        if n != page { withAnimation(.easeInOut(duration: 0.25)) { page = n } }
    }

    func moveIcon(_ id: String, to p: Int) {
        iconPage[id] = p
        iconPos[id] = nil
    }

    func trimPages() {
        var last = pages - 1
        while last > 0 && !homeAppList.contains(where: { (iconPage[$0.id] ?? 0) == last }) { last -= 1 }
        pages = last + 1
        page = min(page, pages - 1)
    }

    func closePanel() {
        withAnimation(.easeOut(duration: 0.25)) { panel = .none }
    }

    func goBack() {
        if locked { return }
        if panel != .none { closePanel(); return }
        if showRecents { home(); return }
        if drawer {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) { drawer = false }
            return
        }
        if let a = open {
            if let h = backHandlers[a.id], h() { return }
            home()
        }
    }

    func animateProg(to target: CGFloat, duration: Double, done: (() -> Void)? = nil) {
        animTimer?.invalidate()
        animTimer = nil
        let from = prog
        if abs(target - from) < 0.001 {
            prog = target
            done?()
            return
        }
        let t0 = CACurrentMediaTime()
        let closing = target < from
        let timer = Timer(timeInterval: 1.0 / 60.0, repeats: true) { [weak self] tm in
            guard let self = self else { tm.invalidate(); return }
            let raw = min(1.0, (CACurrentMediaTime() - t0) / duration)
            var e = 1.0 - pow(1.0 - raw, 3.0)
            if closing {
                e = raw < 0.5 ? 2.0 * raw * raw : 1.0 - pow(-2.0 * raw + 2.0, 2.0) / 2.0
            }
            self.prog = from + (target - from) * CGFloat(e)
            if raw >= 1.0 {
                tm.invalidate()
                self.animTimer = nil
                done?()
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        animTimer = timer
    }

    func launch(_ a: AppInfo, from r: CGRect? = nil) {
        if locked || launching { return }
        if haptics { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
        originRect = r
        withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) {
            recents.removeAll { $0.id == a.id }
            recents.insert(a, at: 0)
            showRecents = false
            drawer = false
            panel = .none
        }
        animTimer?.invalidate()
        animTimer = nil
        endSession()
        launches[a.id, default: 0] += 1
        if animStyle == 0 && NativeFX.container() != nil {
            launching = true
            let finish: () -> Void = { [weak self] in
                guard let self = self, self.launching else { return }
                self.launching = false
                self.appShown = true
                self.prog = 1
                self.open = a
                self.sessionStart = Date()
            }
            let d = dur(0.55)
            let ok = NativeFX.open(symbol: a.icon, tint: UIColor(a.tint), from: r, radius: iconRadius, duration: d, done: finish)
            if ok {
                DispatchQueue.main.asyncAfter(deadline: .now() + d + 1.0) { finish() }
                return
            }
            launching = false
        }
        appShown = true
        prog = 0
        open = a
        sessionStart = Date()
        animateProg(to: 1, duration: dur(0.45))
    }

    func home() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.88)) {
            showRecents = false
            drawer = false
            panel = .none
        }
        guard open != nil else {
            appShown = false
            prog = 0
            return
        }
        animTimer?.invalidate()
        animTimer = nil
        if appShown && prog > 0.9 { captureSnap() }
        endSession()
        if animStyle == 0 && appShown && prog > 0.5 && NativeFX.container() != nil {
            appShown = false
            NativeFX.close(to: originRect, radius: iconRadius, duration: dur(0.45)) { [weak self] in
                self?.prog = 0
                self?.open = nil
            }
            return
        }
        appShown = false
        animateProg(to: 0, duration: dur(0.4)) { [weak self] in
            guard let self = self else { return }
            if !self.appShown {
                self.open = nil
                self.prog = 0
            }
        }
    }
}
