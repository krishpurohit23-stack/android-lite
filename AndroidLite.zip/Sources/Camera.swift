import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreImage
import CoreMotion

// Camera.swift - Gallery storage, Camera (100x zoom, video, timer, grid) and Photos. Read CLAUDE.md before editing.

// MARK: - Gallery storage (shared by Camera + Photos)
enum Gallery {
    static var dir: URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let u = base.appendingPathComponent("Camera", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    @discardableResult
    static func save(_ data: Data) -> URL? {
        let name = "IMG_\(Int(Date().timeIntervalSince1970 * 1000)).jpg"
        let u = dir.appendingPathComponent(name)
        do {
            try data.write(to: u)
            return u
        } catch {
            return nil
        }
    }

    static func saveMovie(from url: URL) -> URL? {
        let name = "VID_\(Int(Date().timeIntervalSince1970 * 1000)).mov"
        let dest = dir.appendingPathComponent(name)
        do {
            try FileManager.default.copyItem(at: url, to: dest)
            return dest
        } catch {
            return nil
        }
    }

    static func list() -> [URL] {
        let keys: [URLResourceKey] = [.creationDateKey]
        let all = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys)) ?? []
        let media = all.filter { ["jpg", "mov"].contains($0.pathExtension.lowercased()) }
        return media.sorted { a, b in
            let da = (try? a.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            let db = (try? b.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            return da > db
        }
    }

    static func thumb(_ url: URL, max: CGFloat) -> UIImage? {
        if url.pathExtension.lowercased() == "mov" {
            let gen = AVAssetImageGenerator(asset: AVAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: max, height: max)
            if let cg = try? gen.copyCGImage(at: .zero, actualTime: nil) { return UIImage(cgImage: cg) }
            return nil
        }
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: max
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }
}

// MARK: - Camera (real AVFoundation: main lens only, up to 100x zoom, video, timer, grid)
final class CamModel: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate, AVCaptureFileOutputRecordingDelegate {
    let session = AVCaptureSession()
    let output = AVCapturePhotoOutput()
    let movie = AVCaptureMovieFileOutput()
    @Published var authorized = false
    @Published var back = true
    @Published var flashOn = false
    @Published var last: UIImage? = nil
    @Published var zoom: CGFloat = 1
    @Published var extraZoom: CGFloat = 1
    @Published var videoMode = false
    @Published var recording = false
    @Published var recSeconds = 0
    @Published var lens = 1   // 0 = ultra wide, 1 = main
    @Published var pending = 0
    var enhanceOn = true
    private let motion = CMMotionManager()
    private let enhanceQueue = DispatchQueue(label: "androidlite.enhance", qos: .utility)
    static let ciContext = CIContext()
    static let maxZoom: CGFloat = 800
    private var configured = false
    private var device: AVCaptureDevice?
    private var audioInput: AVCaptureDeviceInput?
    private var recTimer: Timer?

    func start() {
        if motion.isGyroAvailable {
            motion.gyroUpdateInterval = 0.05
            motion.startGyroUpdates()
        }
        AVCaptureDevice.requestAccess(for: .video) { ok in
            DispatchQueue.main.async { self.authorized = ok }
            guard ok else { return }
            DispatchQueue.global(qos: .userInitiated).async {
                self.configure()
                if !self.session.isRunning { self.session.startRunning() }
            }
        }
        if let u = Gallery.list().first {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }

    private func configure() {
        if configured { return }
        session.beginConfiguration()
        session.sessionPreset = .photo
        if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
           let inp = try? AVCaptureDeviceInput(device: dev), session.canAddInput(inp) {
            session.addInput(inp)
            device = dev
        }
        if session.canAddOutput(output) { session.addOutput(output) }
        output.maxPhotoQualityPrioritization = .quality
        session.commitConfiguration()
        configured = true
    }

    func stop() {
        motion.stopGyroUpdates()
        if recording { movie.stopRecording() }
        DispatchQueue.global().async {
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    /// Hardware zoom on the main lens first, then digital zoom (crop) up to 100x.
    func setZoom(_ z: CGFloat) {
        let zz = min(max(z, 1), CamModel.maxZoom)
        zoom = zz
        guard let d = device else {
            extraZoom = zz
            return
        }
        let hw = max(1, min(zz, d.activeFormat.videoMaxZoomFactor))
        do {
            try d.lockForConfiguration()
            d.videoZoomFactor = hw
            d.unlockForConfiguration()
        } catch {}
        extraZoom = zz / hw
    }

    var lensBase: CGFloat { lens == 0 ? 0.5 : 1 }

    /// Switch between the ultra wide (0.5x) and the main lens. Works for photo and video.
    func setLens(_ l: Int) {
        if recording || !back || l == lens { return }
        let type: AVCaptureDevice.DeviceType = l == 0 ? .builtInUltraWideCamera : .builtInWideAngleCamera
        guard AVCaptureDevice.default(type, for: .video, position: .back) != nil else { return }
        lens = l
        zoom = 1
        extraZoom = 1
        DispatchQueue.global().async {
            guard let dev = AVCaptureDevice.default(type, for: .video, position: .back),
                  let inp = try? AVCaptureDeviceInput(device: dev) else { return }
            self.session.beginConfiguration()
            let current = self.session.inputs
            for i in current {
                if let di = i as? AVCaptureDeviceInput, di.device.hasMediaType(.video) {
                    self.session.removeInput(di)
                }
            }
            if self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
        }
    }

    func flip() {
        if recording { return }
        back.toggle()
        let pos: AVCaptureDevice.Position = back ? .back : .front
        zoom = 1
        extraZoom = 1
        lens = 1
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            for i in self.session.inputs { self.session.removeInput(i) }
            self.audioInput = nil
            if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: pos),
               let inp = try? AVCaptureDeviceInput(device: dev), self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
        }
    }

    func setMode(video: Bool) {
        if recording { return }
        videoMode = video
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            if video {
                self.session.sessionPreset = .high
                if !self.session.outputs.contains(self.movie) && self.session.canAddOutput(self.movie) {
                    self.session.addOutput(self.movie)
                }
                if let c = self.movie.connection(with: .video), c.isVideoStabilizationSupported {
                    c.preferredVideoStabilizationMode = .cinematicExtended
                }
            } else {
                if self.session.outputs.contains(self.movie) { self.session.removeOutput(self.movie) }
                self.session.sessionPreset = .photo
            }
            self.session.commitConfiguration()
        }
    }

    func toggleRecord() {
        if recording {
            movie.stopRecording()
            return
        }
        AVCaptureDevice.requestAccess(for: .audio) { ok in
            DispatchQueue.global().async {
                if ok && self.audioInput == nil,
                   let mic = AVCaptureDevice.default(for: .audio),
                   let inp = try? AVCaptureDeviceInput(device: mic) {
                    self.session.beginConfiguration()
                    if self.session.canAddInput(inp) {
                        self.session.addInput(inp)
                        self.audioInput = inp
                    }
                    self.session.commitConfiguration()
                }
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).mov")
                self.movie.startRecording(to: url, recordingDelegate: self)
            }
        }
    }

    /// Capture immediately. Upscaling (EN button) runs later on a background queue and never blocks the shutter.
    func shoot() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        waitSteady(tries: 0) { self.capture() }
    }

    /// Waits up to ~0.25s for the hand to settle (gyro) so zoomed shots are sharper.
    private func waitSteady(tries: Int, then go: @escaping () -> Void) {
        let limit: Double = zoom >= 5 ? 0.12 : 0.4
        if motion.isGyroAvailable, tries < 5, let r = motion.gyroData?.rotationRate {
            let mag = sqrt(r.x * r.x + r.y * r.y + r.z * r.z)
            if mag > limit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { self.waitSteady(tries: tries + 1, then: go) }
                return
            }
        }
        go()
    }

    private func capture() {
        let s = AVCapturePhotoSettings()
        if flashOn && back && output.supportedFlashModes.contains(.on) { s.flashMode = .on }
        s.photoQualityPrioritization = .quality
        output.capturePhoto(with: s, delegate: self)
    }

    /// Real-ESRGAN (4x, or two passes = 16x in Space mode) on zoomed shots; Core Image fallback otherwise.
    static func enhance(_ img: UIImage, scale: CGFloat, zoom: CGFloat, sensor: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        let trueSide = sensor / max(zoom, 1)
        if ESRGAN.shared.available && zoom >= 3 && trueSide <= 1300 {
            if let out = esrganEnhance(cg, trueSide: trueSide, zoom: zoom) {
                return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
            }
        }
        return ciEnhance(img, scale: scale, zoom: zoom)
    }

    static func esrganEnhance(_ cg: CGImage, trueSide: CGFloat, zoom: CGFloat) -> CGImage? {
        let space = zoom >= 100
        let limit: CGFloat = space ? 160 : 640
        let maxSide = CGFloat(max(cg.width, cg.height))
        let target = max(32, min(trueSide, limit))
        var cur = cg
        if target < maxSide - 1 {
            let k = target / maxSide
            let w = max(8, Int(CGFloat(cg.width) * k))
            let h = max(8, Int(CGFloat(cg.height) * k))
            if let r = ESRGAN.resize(cg, w, h) { cur = r }
        }
        guard var out = ESRGAN.shared.upscale4x(cur) else { return nil }
        if space, let second = ESRGAN.shared.upscale4x(out) { out = second }
        return out
    }

    static func ciEnhance(_ img: UIImage, scale: CGFloat, zoom: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        var ci = CIImage(cgImage: cg)
        if let nr = CIFilter(name: "CINoiseReduction") {
            nr.setValue(ci, forKey: kCIInputImageKey)
            nr.setValue(min(0.06, 0.01 + Double(zoom) / 2500.0), forKey: "inputNoiseLevel")
            nr.setValue(0.4, forKey: "inputSharpness")
            if let o = nr.outputImage { ci = o }
        }
        let maxSide = CGFloat(max(cg.width, cg.height))
        var remaining = min(scale, max(6000.0 / maxSide, 1.0))
        while remaining > 1.001 {
            let step = min(remaining, 2.0)
            if let lz = CIFilter(name: "CILanczosScaleTransform") {
                lz.setValue(ci, forKey: kCIInputImageKey)
                lz.setValue(step, forKey: kCIInputScaleKey)
                lz.setValue(1.0, forKey: kCIInputAspectRatioKey)
                if let o = lz.outputImage { ci = o }
            }
            if let us = CIFilter(name: "CIUnsharpMask") {
                us.setValue(ci, forKey: kCIInputImageKey)
                us.setValue(1.6, forKey: kCIInputRadiusKey)
                us.setValue(0.7, forKey: kCIInputIntensityKey)
                if let o = us.outputImage { ci = o }
            }
            remaining /= step
        }
        if let sh = CIFilter(name: "CISharpenLuminance") {
            sh.setValue(ci, forKey: kCIInputImageKey)
            sh.setValue(0.5 + Double(min(zoom, 100)) / 200.0, forKey: kCIInputSharpnessKey)
            if let o = sh.outputImage { ci = o }
        }
        if let out = CamModel.ciContext.createCGImage(ci, from: ci.extent) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard let data = photo.fileDataRepresentation(), var img = UIImage(data: data) else { return }
        let ex = extraZoom
        let z = zoom
        let sensor = CGFloat(max(img.cgImage?.width ?? 0, img.cgImage?.height ?? 0))
        if ex > 1.01, let cg = img.cgImage {
            let w = CGFloat(cg.width) / ex
            let h = CGFloat(cg.height) / ex
            let rect = CGRect(x: (CGFloat(cg.width) - w) / 2, y: (CGFloat(cg.height) - h) / 2, width: w, height: h)
            if let c = cg.cropping(to: rect) {
                img = UIImage(cgImage: c, scale: 1, orientation: img.imageOrientation)
            }
        }
        // 1) the photo is saved right away, so the shutter is never blocked
        let url = Gallery.save(img.jpegData(compressionQuality: 0.95) ?? data)
        let en = enhanceOn
        if !en { UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil) }
        DispatchQueue.main.async {
            self.last = img
            if en { self.pending += 1 }
        }
        // 2) EN on: upscale in the background, then replace the saved file
        if en {
            let original = img
            enhanceQueue.async {
                let out = CamModel.enhance(original, scale: ex > 1.01 ? ex : 1.5, zoom: z, sensor: sensor)
                if let jpg = out.jpegData(compressionQuality: 0.95), let u = url { try? jpg.write(to: u) }
                UIImageWriteToSavedPhotosAlbum(out, nil, nil, nil)
                DispatchQueue.main.async {
                    self.pending = max(0, self.pending - 1)
                    self.last = out
                }
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async {
            self.recording = true
            self.recSeconds = 0
            self.recTimer?.invalidate()
            self.recTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                self.recSeconds += 1
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async {
            self.recording = false
            self.recTimer?.invalidate()
            self.recTimer = nil
        }
        let saved = Gallery.saveMovie(from: outputFileURL)
        UISaveVideoAtPathToSavedPhotosAlbum(outputFileURL.path, nil, nil, nil)
        if let u = saved {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var pl: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

struct CamPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.pl.session = session
        v.pl.videoGravity = .resizeAspectFill
        return v
    }
    func updateUIView(_ v: PreviewView, context: Context) {}
}

struct GridLines: View {
    var body: some View {
        GeometryReader { g in
            Path { p in
                p.move(to: CGPoint(x: g.size.width / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width / 3, y: g.size.height))
                p.move(to: CGPoint(x: g.size.width * 2 / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width * 2 / 3, y: g.size.height))
                p.move(to: CGPoint(x: 0, y: g.size.height / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height / 3))
                p.move(to: CGPoint(x: 0, y: g.size.height * 2 / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height * 2 / 3))
            }
            .stroke(Color.white.opacity(0.35), lineWidth: 1)
        }
        .allowsHitTesting(false)
    }
}

struct CameraApp: View {
    @EnvironmentObject var os: OS
    @StateObject var cam = CamModel()
    @State var timerSec = 0
    @State var count = 0
    @State var grid = false
    @State var baseZoom: CGFloat = 1
    let zoomSteps: [CGFloat] = [1, 2, 5, 10, 30, 100]

    func zoomLabel() -> String {
        let t = zoomText(cam.zoom * cam.lensBase)
        return cam.zoom >= 100 ? "Space " + t : t
    }

    func goSpace() {
        if cam.lens != 1 {
            cam.setLens(1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                cam.setZoom(800)
                baseZoom = 800
            }
        } else {
            cam.setZoom(800)
            baseZoom = 800
        }
    }

    func zoomText(_ z: CGFloat) -> String {
        z < 10 ? String(format: "%.1fx", z) : String(format: "%.0fx", z)
    }

    func countdown(_ n: Int) {
        if n <= 0 {
            count = 0
            cam.shoot()
            return
        }
        count = n
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { countdown(n - 1) }
    }

    func shutter() {
        if cam.videoMode {
            cam.toggleRecord()
        } else if timerSec == 0 {
            cam.shoot()
        } else {
            countdown(timerSec)
        }
    }

    var topRow: some View {
        HStack {
            Button { cam.flashOn.toggle() } label: {
                Image(systemName: cam.flashOn ? "bolt.fill" : "bolt.slash.fill")
                    .foregroundColor(cam.flashOn ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Button {
                os.camEnhance.toggle()
                cam.enhanceOn = os.camEnhance
            } label: {
                Text("EN")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(os.camEnhance ? T.onAccent : .white)
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Capsule().fill(os.camEnhance ? T.accent : Color.white.opacity(0.15)))
            }
            Button { grid.toggle() } label: {
                Image(systemName: "grid")
                    .foregroundColor(grid ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Spacer()
            if cam.recording {
                Text(String(format: "%02d:%02d", cam.recSeconds / 60, cam.recSeconds % 60))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Capsule().fill(Color.red))
            } else {
                Text(zoomLabel())
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .background(Capsule().fill(T.accent))
            }
            Spacer()
            Button { timerSec = timerSec == 0 ? 3 : (timerSec == 3 ? 10 : 0) } label: {
                ZStack {
                    Image(systemName: "timer").foregroundColor(timerSec == 0 ? .white : T.accent)
                    if timerSec > 0 {
                        Text("\(timerSec)")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(T.accent)
                            .offset(x: 12, y: -10)
                    }
                }
                .frame(width: 40, height: 40)
            }
            Color.clear.frame(width: 40, height: 40)
        }
        .padding(.horizontal, 16)
        .padding(.top, os.padTop - 8)
    }

    var preview: some View {
        ZStack {
            Color(white: 0.1)
            if cam.authorized {
                CamPreview(session: cam.session).scaleEffect(cam.extraZoom)
            } else {
                Text("Allow camera access in iOS Settings")
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding()
            }
            if grid { GridLines() }
            if count > 0 {
                Text("\(count)").font(.system(size: 90, weight: .bold)).foregroundColor(.white)
            }
            if cam.pending > 0 {
                VStack {
                    Spacer()
                    Text("Enhancing \(cam.pending)...")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Capsule().fill(Color.black.opacity(0.55)))
                        .padding(.bottom, 10)
                }
                .allowsHitTesting(false)
            }
        }
        .aspectRatio(3.0 / 4.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 10)
        .padding(.top, 8)
        .gesture(
            MagnificationGesture()
                .onChanged { v in cam.setZoom(baseZoom * v) }
                .onEnded { _ in baseZoom = cam.zoom }
        )
    }

    var zoomRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(0..<zoomSteps.count, id: \.self) { i in
                    Button {
                        cam.setZoom(zoomSteps[i])
                        baseZoom = zoomSteps[i]
                    } label: {
                        Text(zoomText(zoomSteps[i] * cam.lensBase))
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(abs(cam.zoom - zoomSteps[i]) < 0.05 ? T.onAccent : .white)
                            .padding(.horizontal, 10).padding(.vertical, 7)
                            .background(Capsule().fill(abs(cam.zoom - zoomSteps[i]) < 0.05 ? T.accent : Color.white.opacity(0.12)))
                    }
                }
                Button { goSpace() } label: {
                    Text("Space 800x")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(cam.zoom >= 799 ? T.onAccent : .white)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(Capsule().fill(cam.zoom >= 799 ? T.accent : Color.purple.opacity(0.55)))
                }
            }
            .padding(.horizontal, 12)
        }
        .padding(.top, 10)
    }

    var modeRow: some View {
        HStack(spacing: 10) {
            Button { cam.setLens(0) } label: {
                Text("0.5x")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.lens == 0 ? T.onAccent : .white)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill(cam.lens == 0 ? T.accent : Color.white.opacity(0.12)))
            }
            Button { cam.setLens(1) } label: {
                Text("1x")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.lens == 1 ? T.onAccent : .white)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill(cam.lens == 1 ? T.accent : Color.white.opacity(0.12)))
            }
            Button { cam.setMode(video: false) } label: {
                Text("Photo")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? .white : T.onAccent)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? Color.white.opacity(0.12) : T.accent))
            }
            Button { cam.setMode(video: true) } label: {
                Text("Video")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? T.onAccent : .white)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? T.accent : Color.white.opacity(0.12)))
            }
        }
        .padding(.bottom, 14)
    }

    var bottomRow: some View {
        HStack {
            Button {
                if let p = appFor("photos") { os.launch(p) }
            } label: {
                if let img = cam.last {
                    Image(uiImage: img).resizable().scaledToFill()
                        .frame(width: 54, height: 54).clipShape(Circle())
                } else {
                    Circle().fill(T.card).frame(width: 54, height: 54)
                }
            }
            Spacer()
            Button { shutter() } label: {
                ZStack {
                    Circle().stroke(Color.white, lineWidth: 4).frame(width: 78, height: 78)
                    if cam.videoMode {
                        RoundedRectangle(cornerRadius: cam.recording ? 10 : 33, style: .continuous)
                            .fill(Color.red)
                            .frame(width: cam.recording ? 34 : 66, height: cam.recording ? 34 : 66)
                    } else {
                        Circle().fill(Color.white).frame(width: 64, height: 64)
                    }
                }
            }
            Spacer()
            Button { cam.flip() } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .foregroundColor(.white)
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(T.card))
            }
        }
        .padding(.horizontal, 36)
        .padding(.bottom, 40)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                topRow
                preview
                zoomRow
                Spacer()
                modeRow
                bottomRow
            }
        }
        .onAppear {
            cam.enhanceOn = os.camEnhance
            cam.start()
            DispatchQueue.global(qos: .utility).async { _ = ESRGAN.shared }
        }
        .onDisappear { cam.stop() }
    }
}

// MARK: - Photos
struct Thumb: View {
    let url: URL
    let maxSize: CGFloat
    var fill = true
    @State var img: UIImage? = nil

    var body: some View {
        Group {
            if let i = img {
                if fill {
                    Image(uiImage: i).resizable().scaledToFill()
                } else {
                    Image(uiImage: i).resizable().scaledToFit()
                }
            } else {
                T.card
            }
        }
        .onAppear {
            DispatchQueue.global().async {
                let t = Gallery.thumb(url, max: maxSize)
                DispatchQueue.main.async { img = t }
            }
        }
    }
}

struct VideoView: View {
    @State var player: AVPlayer
    init(url: URL) { _player = State(initialValue: AVPlayer(url: url)) }
    var body: some View {
        VideoPlayer(player: player)
            .onAppear { player.play() }
            .onDisappear { player.pause() }
    }
}

struct PhotosApp: View {
    @EnvironmentObject var os: OS
    @State var files: [URL] = []
    @State var sel: URL? = nil
    let cols = Array(repeating: GridItem(.flexible(), spacing: 3), count: 3)

    func isVideo(_ u: URL) -> Bool { u.pathExtension.lowercased() == "mov" }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Title(text: "Photos")
                if files.isEmpty {
                    Spacer()
                    Text("No photos yet. Take one with the Camera.")
                        .foregroundColor(.white.opacity(0.6))
                    Spacer()
                } else {
                    ScrollView {
                        LazyVGrid(columns: cols, spacing: 3) {
                            ForEach(files, id: \.self) { u in
                                Button { sel = u } label: {
                                    Color.clear
                                        .aspectRatio(1, contentMode: .fit)
                                        .overlay(Thumb(url: u, maxSize: 300))
                                        .overlay(
                                            Image(systemName: "play.circle.fill")
                                                .font(.system(size: 26))
                                                .foregroundColor(.white)
                                                .opacity(isVideo(u) ? 1 : 0)
                                        )
                                        .clipped()
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            if let s = sel {
                ZStack(alignment: .top) {
                    Color.black.ignoresSafeArea()
                    if isVideo(s) {
                        VideoView(url: s)
                    } else {
                        Thumb(url: s, maxSize: 1600, fill: false)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                    HStack {
                        Button { sel = nil } label: {
                            Image(systemName: "chevron.left").foregroundColor(.white)
                                .frame(width: 44, height: 44)
                        }
                        Spacer()
                        Button {
                            try? FileManager.default.removeItem(at: s)
                            sel = nil
                            files = Gallery.list()
                        } label: {
                            Image(systemName: "trash").foregroundColor(.white)
                                .frame(width: 44, height: 44)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                }
            }
        }
        .onAppear {
            files = Gallery.list()
            os.backHandlers["photos"] = {
                if sel != nil { sel = nil; return true }
                return false
            }
        }
    }
}
