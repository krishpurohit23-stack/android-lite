import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreImage
import CoreMotion

// Camera.swift - Gallery storage, Camera (800x zoom, 3 lenses, video, timer, grid, steady shot) and the Photos (gallery) app. Read CLAUDE.md before editing.

// MARK: - Gallery storage (shared by Camera + Photos)
enum Gallery {
    static let cache = NSCache<NSString, UIImage>()
    static let imageExts = ["jpg", "jpeg", "png", "heic"]
    static let videoExts = ["mov", "mp4", "m4v"]

    static var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static var dir: URL {
        let u = documents.appendingPathComponent("Camera", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static var trashDir: URL {
        let u = documents.appendingPathComponent("Trash", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static func isVideo(_ u: URL) -> Bool { videoExts.contains(u.pathExtension.lowercased()) }

    @discardableResult
    static func save(_ data: Data) -> URL? {
        let name = "IMG_\(Int(Date().timeIntervalSince1970 * 1000)).jpg"
        let u = dir.appendingPathComponent(name)
        do {
            try data.write(to: u)
            return u
        } catch {
            return nil
        }
    }

    static func saveMovie(from url: URL) -> URL? {
        let name = "VID_\(Int(Date().timeIntervalSince1970 * 1000)).mov"
        let dest = dir.appendingPathComponent(name)
        do {
            try FileManager.default.copyItem(at: url, to: dest)
            return dest
        } catch {
            return nil
        }
    }

    /// Newest first. `modified` = sort by modification date (used for the trash = time of deletion).
    static func listDated(in folder: URL, modified: Bool) -> [(URL, Date)] {
        let keys: [URLResourceKey] = [.creationDateKey, .contentModificationDateKey]
        let all = (try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: keys)) ?? []
        let exts = imageExts + videoExts
        var out: [(URL, Date)] = []
        for u in all where exts.contains(u.pathExtension.lowercased()) {
            let v = try? u.resourceValues(forKeys: Set(keys))
            let created = v?.creationDate ?? v?.contentModificationDate ?? Date.distantPast
            let changed = v?.contentModificationDate ?? created
            out.append((u, modified ? changed : created))
        }
        return out.sorted { $0.1 > $1.1 }
    }

    static func list() -> [URL] {
        listDated(in: dir, modified: false).map { $0.0 }
    }

    // Trash (30 days)
    @discardableResult
    static func moveToTrash(_ u: URL) -> Bool {
        let dest = trashDir.appendingPathComponent(u.lastPathComponent)
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: u, to: dest)
            try? FileManager.default.setAttributes([.modificationDate: Date()], ofItemAtPath: dest.path)
            return true
        } catch {
            return false
        }
    }

    @discardableResult
    static func restore(_ u: URL) -> Bool {
        var dest = dir.appendingPathComponent(u.lastPathComponent)
        if FileManager.default.fileExists(atPath: dest.path) {
            let n = "\(Int(Date().timeIntervalSince1970 * 1000))_" + u.lastPathComponent
            dest = dir.appendingPathComponent(n)
        }
        do {
            try FileManager.default.moveItem(at: u, to: dest)
            return true
        } catch {
            return false
        }
    }

    static func purgeTrash() {
        for (u, d) in listDated(in: trashDir, modified: true) where Date().timeIntervalSince(d) > 30 * 86400 {
            try? FileManager.default.removeItem(at: u)
        }
    }

    // Favorites (by file name)
    static var favs: Set<String> {
        get { Set(UserDefaults.standard.stringArray(forKey: "al_galfavs") ?? []) }
        set { UserDefaults.standard.set(Array(newValue), forKey: "al_galfavs") }
    }

    // Thumbnails
    static func pixelSide(_ src: CGImageSource) -> CGFloat {
        guard let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return 0 }
        let w = (p[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 0
        let h = (p[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue ?? 0
        return CGFloat(Swift.max(w, h))
    }

    static func thumb(_ url: URL, max: CGFloat) -> UIImage? {
        if isVideo(url) {
            let gen = AVAssetImageGenerator(asset: AVAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: max, height: max)
            if let cg = try? gen.copyCGImage(at: .zero, actualTime: nil) { return UIImage(cgImage: cg) }
            return nil
        }
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let side = pixelSide(src)
        let m = side > 0 ? Swift.min(max, side) : max
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: m
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }

    static func cached(_ url: URL, max: CGFloat) -> UIImage? {
        cache.object(forKey: "\(url.path)|\(Int(max))" as NSString)
    }

    static func store(_ img: UIImage, _ url: URL, _ max: CGFloat) {
        cache.setObject(img, forKey: "\(url.path)|\(Int(max))" as NSString)
    }

    static func info(_ u: URL) -> [(String, String)] {
        var rows: [(String, String)] = []
        rows.append(("Name", u.lastPathComponent))
        if let d = (try? u.resourceValues(forKeys: [.creationDateKey]))?.creationDate {
            let f = DateFormatter()
            f.dateStyle = .medium
            f.timeStyle = .short
            rows.append(("Date", f.string(from: d)))
        }
        let size = (try? u.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        rows.append(("Size", ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)))
        if isVideo(u) {
            let a = AVAsset(url: u)
            let secs = CMTimeGetSeconds(a.duration)
            if secs.isFinite && secs > 0 {
                rows.append(("Duration", String(format: "%d:%02d", Int(secs) / 60, Int(secs) % 60)))
            }
            if let t = a.tracks(withMediaType: .video).first {
                let sz = t.naturalSize.applying(t.preferredTransform)
                rows.append(("Resolution", "\(Int(abs(sz.width))) x \(Int(abs(sz.height)))"))
            }
        } else if let src = CGImageSourceCreateWithURL(u as CFURL, nil),
                  let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] {
            let w = (p[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 0
            let h = (p[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue ?? 0
            if w > 0 {
                let mp = Double(w * h) / 1_000_000
                rows.append(("Resolution", "\(w) x \(h)  (" + String(format: "%.1f", mp) + " MP)"))
            }
        }
        return rows
    }
}

// MARK: - Camera (real AVFoundation: ultra wide / main / telephoto, up to 800x zoom, video, timer, grid, steady shot)
final class CamModel: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate, AVCaptureFileOutputRecordingDelegate {
    let session = AVCaptureSession()
    let output = AVCapturePhotoOutput()
    let movie = AVCaptureMovieFileOutput()
    @Published var authorized = false
    @Published var back = true
    @Published var flashOn = false
    @Published var last: UIImage? = nil
    @Published var zoom: CGFloat = 1
    @Published var extraZoom: CGFloat = 1
    @Published var videoMode = false
    @Published var recording = false
    @Published var recSeconds = 0
    @Published var lens = 1   // 0 = ultra wide, 1 = main, 2 = telephoto
    @Published var pending = 0
    @Published var stacking = 0
    @Published var burstDone = 0
    @Published var burstTotal = 0
    @Published var notice = ""
    @Published var night = false
    @Published var bias: Double = 0     // brightness (exposure compensation) in EV, -2...2
    weak var previewLayer: AVCaptureVideoPreviewLayer?
    private var focusObs: NSObjectProtocol?
    @Published var hasTele = AVCaptureDevice.default(.builtInTelephotoCamera, for: .video, position: .back) != nil
    var enhanceOn = true
    var enhanceScale = 4
    var enhanceScaleTele = 4
    var steadyOn = true
    private let motion = CMMotionManager()
    private let enhanceQueue = DispatchQueue(label: "androidlite.enhance", qos: .utility)
    static let ciContext = CIContext()
    static let maxZoom: CGFloat = 800
    private var configured = false
    private var device: AVCaptureDevice?
    private var audioInput: AVCaptureDeviceInput?
    private var recTimer: Timer?
    // burst (steady shot) state - touched on the main queue only
    private var burstTarget = 0
    private var burstData: [(Data, Double)] = []
    private var burstFails = 0
    private var burstEx: CGFloat = 1
    private var burstZoom: CGFloat = 1
    private var burstSensor: CGFloat = 0
    private var burstToken = 0
    private var shotLens = 1

    func start() {
        if focusObs == nil {
            focusObs = NotificationCenter.default.addObserver(forName: .AVCaptureDeviceSubjectAreaDidChange, object: nil, queue: .main) { [weak self] _ in
                self?.resetFocus()
            }
        }
        burstTarget = 0
        burstData = []
        burstFails = 0
        burstDone = 0
        burstTotal = 0
        if motion.isGyroAvailable {
            motion.gyroUpdateInterval = 0.05
            motion.startGyroUpdates()
        }
        AVCaptureDevice.requestAccess(for: .video) { ok in
            DispatchQueue.main.async { self.authorized = ok }
            guard ok else { return }
            DispatchQueue.global(qos: .userInitiated).async {
                self.configure()
                if !self.session.isRunning { self.session.startRunning() }
            }
        }
        if let u = Gallery.list().first {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }

    private func configure() {
        if configured { return }
        session.beginConfiguration()
        session.sessionPreset = .photo
        if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
           let inp = try? AVCaptureDeviceInput(device: dev), session.canAddInput(inp) {
            session.addInput(inp)
            device = dev
        }
        if session.canAddOutput(output) { session.addOutput(output) }
        output.maxPhotoQualityPrioritization = .quality
        session.commitConfiguration()
        configured = true
    }

    func stop() {
        if let o = focusObs {
            NotificationCenter.default.removeObserver(o)
            focusObs = nil
        }
        motion.stopGyroUpdates()
        if recording { movie.stopRecording() }
        DispatchQueue.global().async {
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    func flash(_ s: String) {
        DispatchQueue.main.async {
            self.notice = s
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                if self.notice == s { self.notice = "" }
            }
        }
    }

    var lensBase: CGFloat { lens == 0 ? 0.5 : (lens == 2 ? 2 : 1) }

    /// Telephoto starts at 2x, so its factor stops at 400 to keep the displayed zoom at 800x.
    var maxZoomNow: CGFloat { lens == 2 ? CamModel.maxZoom / 2 : CamModel.maxZoom }

    static func lensType(_ l: Int) -> AVCaptureDevice.DeviceType {
        l == 0 ? .builtInUltraWideCamera : (l == 2 ? .builtInTelephotoCamera : .builtInWideAngleCamera)
    }

    /// Steady shot: with a fast shutter cap (less motion blur) - the burst stack removes the extra noise later.
    private func capExposure(_ d: AVCaptureDevice, dz: CGFloat) {
        let fmt = d.activeFormat
        let lo = CMTimeGetSeconds(fmt.minExposureDuration)
        let hi = CMTimeGetSeconds(fmt.maxExposureDuration)
        guard lo > 0, hi > lo else { return }
        if night && back {
            // night: longer shutter (about 1/8 s), the 8-frame stack cleans the noise
            let safe = Swift.min(Swift.max(0.125, lo * 1.05), hi * 0.98)
            d.activeMaxExposureDuration = CMTimeMakeWithSeconds(safe, preferredTimescale: 1_000_000)
        } else if steadyOn && back && dz >= 1.5 {
            let want = 1.0 / (30.0 * Double(dz))
            let safe = Swift.min(Swift.max(want, lo * 1.05), hi * 0.98)
            d.activeMaxExposureDuration = CMTimeMakeWithSeconds(safe, preferredTimescale: 1_000_000)
        } else {
            d.activeMaxExposureDuration = fmt.maxExposureDuration
        }
        // brightness slider (+ a little extra in night mode)
        let total = bias + (night ? 0.7 : 0)
        let t = Swift.min(Swift.max(Float(total), d.minExposureTargetBias), d.maxExposureTargetBias)
        d.setExposureTargetBias(t, completionHandler: nil)
    }

    /// Re-apply shutter cap + brightness on the current device (night toggle, brightness slider).
    func refreshExposure() {
        guard let d = device else { return }
        do {
            try d.lockForConfiguration()
            capExposure(d, dz: zoom * lensBase)
            d.unlockForConfiguration()
        } catch {}
    }

    func setNight(_ on: Bool) {
        if !back && on {
            flash("Night mode works on the back camera")
            return
        }
        night = on
        refreshExposure()
        flash(on ? "Night mode on - hold steady" : "Night mode off")
    }

    func setBias(_ v: Double) {
        bias = Swift.min(Swift.max(v, -2), 2)
        refreshExposure()
    }

    /// Tap to focus: focus + exposure at the tapped point (layer coordinates of the preview).
    func focus(atLayerPoint lp: CGPoint) {
        guard let layer = previewLayer, let d = device else { return }
        let dp = layer.captureDevicePointConverted(fromLayerPoint: lp)
        do {
            try d.lockForConfiguration()
            if d.isFocusPointOfInterestSupported && d.isFocusModeSupported(.autoFocus) {
                d.focusPointOfInterest = dp
                d.focusMode = .autoFocus
            }
            if d.isExposurePointOfInterestSupported && d.isExposureModeSupported(.autoExpose) {
                d.exposurePointOfInterest = dp
                d.exposureMode = .autoExpose
            }
            d.isSubjectAreaChangeMonitoringEnabled = true
            d.unlockForConfiguration()
        } catch {}
    }

    /// Back to continuous focus/exposure in the center when the scene changes.
    func resetFocus() {
        guard let d = device else { return }
        let c = CGPoint(x: 0.5, y: 0.5)
        do {
            try d.lockForConfiguration()
            if d.isFocusModeSupported(.continuousAutoFocus) {
                if d.isFocusPointOfInterestSupported { d.focusPointOfInterest = c }
                d.focusMode = .continuousAutoFocus
            }
            if d.isExposureModeSupported(.continuousAutoExposure) {
                if d.isExposurePointOfInterestSupported { d.exposurePointOfInterest = c }
                d.exposureMode = .continuousAutoExposure
            }
            d.isSubjectAreaChangeMonitoringEnabled = false
            d.unlockForConfiguration()
        } catch {}
    }

    /// Hardware zoom on the current lens first, then digital zoom (crop) up to 800x.
    func setZoom(_ z: CGFloat) {
        let zz = min(max(z, 1), maxZoomNow)
        zoom = zz
        guard let d = device else {
            extraZoom = zz
            return
        }
        let hw = max(1, min(zz, d.activeFormat.videoMaxZoomFactor))
        do {
            try d.lockForConfiguration()
            d.videoZoomFactor = hw
            capExposure(d, dz: zz * lensBase)
            d.unlockForConfiguration()
        } catch {}
        extraZoom = zz / hw
    }

    /// Switch between ultra wide (0.5x), main (1x) and telephoto (2x). Works for photo and video.
    func setLens(_ l: Int) {
        if recording || !back || l == lens { return }
        let type = CamModel.lensType(l)
        guard AVCaptureDevice.default(type, for: .video, position: .back) != nil else {
            if l == 2 { flash("This iPhone has no telephoto lens") }
            return
        }
        lens = l
        zoom = 1
        extraZoom = 1
        DispatchQueue.global().async {
            guard let dev = AVCaptureDevice.default(type, for: .video, position: .back),
                  let inp = try? AVCaptureDeviceInput(device: dev) else { return }
            self.session.beginConfiguration()
            let current = self.session.inputs
            for i in current {
                if let di = i as? AVCaptureDeviceInput, di.device.hasMediaType(.video) {
                    self.session.removeInput(di)
                }
            }
            if self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
            self.applyStabilization()
            do {
                try dev.lockForConfiguration()
                self.capExposure(dev, dz: self.lensBase)
                dev.unlockForConfiguration()
            } catch {}
        }
    }

    /// Video stabilization: the strongest mode this lens/format supports (cinematic extended > cinematic > standard > auto).
    func applyStabilization() {
        guard let d = device else { return }
        let order: [AVCaptureVideoStabilizationMode] = [.cinematicExtended, .cinematic, .standard, .auto]
        if let c = movie.connection(with: .video), c.isVideoStabilizationSupported {
            for m in order where d.activeFormat.isVideoStabilizationModeSupported(m) {
                c.preferredVideoStabilizationMode = m
                break
            }
        }
    }

    func flip() {
        if recording { return }
        back.toggle()
        if !back && night { night = false }
        let pos: AVCaptureDevice.Position = back ? .back : .front
        zoom = 1
        extraZoom = 1
        lens = 1
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            for i in self.session.inputs { self.session.removeInput(i) }
            self.audioInput = nil
            if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: pos),
               let inp = try? AVCaptureDeviceInput(device: dev), self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
            self.applyStabilization()
        }
    }

    func setMode(video: Bool) {
        if recording { return }
        videoMode = video
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            if video {
                self.session.sessionPreset = .high
                if !self.session.outputs.contains(self.movie) && self.session.canAddOutput(self.movie) {
                    self.session.addOutput(self.movie)
                }
            } else {
                if self.session.outputs.contains(self.movie) { self.session.removeOutput(self.movie) }
                self.session.sessionPreset = .photo
            }
            self.session.commitConfiguration()
            if video { self.applyStabilization() }
        }
    }

    func toggleRecord() {
        if recording {
            movie.stopRecording()
            return
        }
        AVCaptureDevice.requestAccess(for: .audio) { ok in
            DispatchQueue.global().async {
                if ok && self.audioInput == nil,
                   let mic = AVCaptureDevice.default(for: .audio),
                   let inp = try? AVCaptureDeviceInput(device: mic) {
                    self.session.beginConfiguration()
                    if self.session.canAddInput(inp) {
                        self.session.addInput(inp)
                        self.audioInput = inp
                    }
                    self.session.commitConfiguration()
                }
                self.applyStabilization()
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).mov")
                self.movie.startRecording(to: url, recordingDelegate: self)
            }
        }
    }

    /// Steady shot applies to zoomed shots and to every telephoto shot (no flash, photo mode).
    var shouldBurst: Bool {
        back && !flashOn && !videoMode && (night || (steadyOn && (zoom * lensBase >= 5 || lens == 2)))
    }

    /// Capture right away. Upscaling (EN button) runs later on a background queue and never blocks the shutter.
    func shoot() {
        if burstTarget > 0 { return }
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        waitSteady(tries: 0) {
            if self.shouldBurst { self.startBurst() } else { self.capture() }
        }
    }

    /// Waits for the hand to settle (gyro). Steady shot waits longer and demands a calmer hand at high zoom.
    private func waitSteady(tries: Int, then go: @escaping () -> Void) {
        let dz = zoom * lensBase
        var limit: Double = zoom >= 5 ? 0.12 : 0.4
        var maxTries = 5
        if night {
            limit = 0.06
            maxTries = 30
        } else if steadyOn {
            if dz >= 30 { limit = 0.05 } else if dz >= 10 { limit = 0.08 } else if dz >= 5 || lens == 2 { limit = 0.12 } else { limit = 0.3 }
            maxTries = 24
        }
        if motion.isGyroAvailable, tries < maxTries, let r = motion.gyroData?.rotationRate {
            let mag = sqrt(r.x * r.x + r.y * r.y + r.z * r.z)
            if mag > limit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { self.waitSteady(tries: tries + 1, then: go) }
                return
            }
        }
        go()
    }

    private func capture() {
        shotLens = lens
        let s = AVCapturePhotoSettings()
        if flashOn && back && output.supportedFlashModes.contains(.on) { s.flashMode = .on }
        s.photoQualityPrioritization = .quality
        output.capturePhoto(with: s, delegate: self)
    }

    // MARK: steady shot burst
    private func startBurst() {
        let dz = zoom * lensBase
        burstTarget = night ? 8 : (dz >= 30 ? 7 : (dz >= 10 ? 6 : (dz >= 5 ? 5 : 4)))
        burstTotal = burstTarget
        burstDone = 0
        burstData = []
        burstFails = 0
        burstSensor = 0
        burstEx = extraZoom
        burstZoom = zoom
        shotLens = lens
        burstToken += 1
        let tok = burstToken
        captureBurstFrame()
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
            if self.burstTarget > 0 && self.burstToken == tok { self.finishBurst() }
        }
    }

    private func captureBurstFrame() {
        let s = AVCapturePhotoSettings()
        s.photoQualityPrioritization = .balanced
        output.capturePhoto(with: s, delegate: self)
    }

    private func addBurstFrame(_ d: Data?, _ sharp: Double) {
        if burstTarget == 0 { return }
        if let d = d {
            if burstSensor == 0 { burstSensor = Steady.maxSide(d) }
            burstData.append((d, sharp))
        } else {
            burstFails += 1
        }
        burstDone = burstData.count
        if burstData.count + burstFails >= burstTarget {
            finishBurst()
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) { self.captureBurstFrame() }
        }
    }

    private func finishBurst() {
        let frames = burstData
        let ex = burstEx
        let z = burstZoom
        let sensor = burstSensor
        let li = shotLens
        burstTarget = 0
        burstData = []
        burstFails = 0
        burstDone = 0
        burstTotal = 0
        if frames.isEmpty { return }
        stacking += 1
        enhanceQueue.async {
            let fused = Steady.fuse(frames, ex: ex, zoom: z, sensor: sensor)
            DispatchQueue.main.async { self.stacking = max(0, self.stacking - 1) }
            if let img = fused { self.deliver(img, zoom: z, sensor: sensor, lensIdx: li) }
        }
    }

    // MARK: enhance
    /// Real-ESRGAN (4x per pass; 8x..30x = more passes + a final resize) on zoomed shots; Core Image fallback otherwise.
    static func enhance(_ img: UIImage, factor: Int, zoom: CGFloat, sensor: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        let f = CGFloat(min(max(factor, 4), 30))
        let trueSide = sensor / max(zoom, 1)
        if ESRGAN.shared.available && zoom >= 3 && trueSide <= 1300 {
            if let out = esrganEnhance(cg, trueSide: trueSide, factor: f) {
                return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
            }
        }
        return ciEnhance(img, scale: f, zoom: zoom)
    }

    /// The input is shrunk to the real detail (and to 3072/factor px) first, so the result is about factor x input, max ~3072 px.
    static func esrganEnhance(_ cg: CGImage, trueSide: CGFloat, factor f: CGFloat) -> CGImage? {
        let outCap: CGFloat = 3072
        let limit = max(32, outCap / f)
        let maxSide = CGFloat(max(cg.width, cg.height))
        let target = max(32, min(trueSide, limit))
        var cur = cg
        if target < maxSide - 1 {
            let k = target / maxSide
            let w = max(8, Int(CGFloat(cg.width) * k))
            let h = max(8, Int(CGFloat(cg.height) * k))
            if let r = ESRGAN.resize(cg, w, h) { cur = r }
        }
        guard var out = ESRGAN.shared.upscale4x(cur) else { return nil }
        var total: CGFloat = 4
        while total * 4 <= f + 0.01 {
            guard let next = ESRGAN.shared.upscale4x(out) else { break }
            out = next
            total *= 4
        }
        let rest = f / total
        if rest > 1.02 {
            let w = Int(CGFloat(out.width) * rest)
            let h = Int(CGFloat(out.height) * rest)
            if let r = ESRGAN.resize(out, w, h) { out = r }
        }
        return out
    }

    static func ciEnhance(_ img: UIImage, scale: CGFloat, zoom: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        var ci = CIImage(cgImage: cg)
        if let nr = CIFilter(name: "CINoiseReduction") {
            nr.setValue(ci, forKey: kCIInputImageKey)
            nr.setValue(min(0.06, 0.01 + Double(zoom) / 2500.0), forKey: "inputNoiseLevel")
            nr.setValue(0.4, forKey: "inputSharpness")
            if let o = nr.outputImage { ci = o }
        }
        let maxSide = CGFloat(max(cg.width, cg.height))
        var remaining = min(scale, max(6000.0 / maxSide, 1.0))
        while remaining > 1.001 {
            let step = min(remaining, 2.0)
            if let lz = CIFilter(name: "CILanczosScaleTransform") {
                lz.setValue(ci, forKey: kCIInputImageKey)
                lz.setValue(step, forKey: kCIInputScaleKey)
                lz.setValue(1.0, forKey: kCIInputAspectRatioKey)
                if let o = lz.outputImage { ci = o }
            }
            if let us = CIFilter(name: "CIUnsharpMask") {
                us.setValue(ci, forKey: kCIInputImageKey)
                us.setValue(1.6, forKey: kCIInputRadiusKey)
                us.setValue(0.7, forKey: kCIInputIntensityKey)
                if let o = us.outputImage { ci = o }
            }
            remaining /= step
        }
        if let sh = CIFilter(name: "CISharpenLuminance") {
            sh.setValue(ci, forKey: kCIInputImageKey)
            sh.setValue(0.5 + Double(min(zoom, 100)) / 200.0, forKey: kCIInputSharpnessKey)
            if let o = sh.outputImage { ci = o }
        }
        if let out = CamModel.ciContext.createCGImage(ci, from: ci.extent) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }

    /// Save the finished shot right away (shutter never waits), then enhance in the background and replace the file.
    func deliver(_ img: UIImage, zoom z: CGFloat, sensor: CGFloat, lensIdx: Int) {
        guard let jpg = img.jpegData(compressionQuality: 0.95) else { return }
        let url = Gallery.save(jpg)
        let en = enhanceOn
        let factor = lensIdx == 2 ? enhanceScaleTele : enhanceScale
        if !en { UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil) }
        DispatchQueue.main.async {
            self.last = img
            if en { self.pending += 1 }
        }
        if en {
            let original = img
            enhanceQueue.async {
                let out = CamModel.enhance(original, factor: factor, zoom: z, sensor: sensor)
                if let j = out.jpegData(compressionQuality: 0.95), let u = url { try? j.write(to: u) }
                UIImageWriteToSavedPhotosAlbum(out, nil, nil, nil)
                DispatchQueue.main.async {
                    self.pending = max(0, self.pending - 1)
                    self.last = out
                }
            }
        }
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let raw = photo.fileDataRepresentation()
        if burstTarget > 0 {
            var sharp = 0.0
            if let d = raw { sharp = Steady.sharpness(d, ex: burstEx) }
            DispatchQueue.main.async { self.addBurstFrame(raw, sharp) }
            return
        }
        guard let data = raw, var img = UIImage(data: data) else { return }
        let ex = extraZoom
        let z = zoom
        let sensor = CGFloat(max(img.cgImage?.width ?? 0, img.cgImage?.height ?? 0))
        if ex > 1.01, let cg = img.cgImage {
            let w = CGFloat(cg.width) / ex
            let h = CGFloat(cg.height) / ex
            let rect = CGRect(x: (CGFloat(cg.width) - w) / 2, y: (CGFloat(cg.height) - h) / 2, width: w, height: h)
            if let c = cg.cropping(to: rect) {
                img = UIImage(cgImage: c, scale: 1, orientation: img.imageOrientation)
            }
        }
        deliver(img, zoom: z, sensor: sensor, lensIdx: shotLens)
    }

    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async {
            self.recording = true
            self.recSeconds = 0
            self.recTimer?.invalidate()
            self.recTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                self.recSeconds += 1
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async {
            self.recording = false
            self.recTimer?.invalidate()
            self.recTimer = nil
        }
        let saved = Gallery.saveMovie(from: outputFileURL)
        UISaveVideoAtPathToSavedPhotosAlbum(outputFileURL.path, nil, nil, nil)
        if let u = saved {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var pl: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }

    /// Steadier live preview (helps most on the telephoto lens).
    func refresh() {
        if let c = pl.connection, c.isVideoStabilizationSupported, c.preferredVideoStabilizationMode != .auto {
            c.preferredVideoStabilizationMode = .auto
        }
    }
}

struct CamPreview: UIViewRepresentable {
    let session: AVCaptureSession
    let cam: CamModel
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.pl.session = session
        v.pl.videoGravity = .resizeAspectFill
        cam.previewLayer = v.pl
        return v
    }
    func updateUIView(_ v: PreviewView, context: Context) { v.refresh() }
}

struct GridLines: View {
    var body: some View {
        GeometryReader { g in
            Path { p in
                p.move(to: CGPoint(x: g.size.width / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width / 3, y: g.size.height))
                p.move(to: CGPoint(x: g.size.width * 2 / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width * 2 / 3, y: g.size.height))
                p.move(to: CGPoint(x: 0, y: g.size.height / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height / 3))
                p.move(to: CGPoint(x: 0, y: g.size.height * 2 / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height * 2 / 3))
            }
            .stroke(Color.white.opacity(0.35), lineWidth: 1)
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Camera settings panel (enhance 4x-30x per lens, steady shot)
struct CamEnhanceRow: View {
    let title: String
    let sub: String
    @Binding var value: Int
    let chips = [4, 8, 12, 16, 20, 30]

    var sliderBinding: Binding<Double> {
        Binding(get: { Double(value) }, set: { value = Int($0.rounded()) })
    }

    var chipRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(0..<chips.count, id: \.self) { i in
                    Button { value = chips[i] } label: {
                        Text("\(chips[i])x")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(value == chips[i] ? T.onAccent : .white)
                            .padding(.horizontal, 12).padding(.vertical, 6)
                            .background(Capsule().fill(value == chips[i] ? T.accent : Color.white.opacity(0.12)))
                    }
                }
            }
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title).font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                Spacer()
                Text("\(value)x").font(.system(size: 15, weight: .bold)).foregroundColor(T.accent)
            }
            Slider(value: sliderBinding, in: 4...30, step: 1).tint(T.accent)
            chipRow
            Text(sub).font(.system(size: 11)).foregroundColor(.white.opacity(0.55))
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(T.card))
    }
}

struct CamSettingsPanel: View {
    @EnvironmentObject var os: OS
    let hasTele: Bool
    let onClose: () -> Void

    var header: some View {
        HStack {
            Text("Camera settings").font(.system(size: 20, weight: .medium)).foregroundColor(.white)
            Spacer()
            Button { onClose() } label: {
                Image(systemName: "xmark")
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
                    .background(Circle().fill(Color.white.opacity(0.12)))
            }
        }
    }

    var steadyCard: some View {
        Toggle(isOn: $os.camSteady) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Steady shot").font(.system(size: 15, weight: .semibold)).foregroundColor(.white)
                Text("Zoomed and telephoto photos: waits for a calm hand, shoots a burst, keeps the sharpest frames, aligns and merges them. Faster shutter cap + strongest video stabilization.")
                    .font(.system(size: 11)).foregroundColor(.white.opacity(0.55))
            }
        }
        .tint(T.accent)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(T.card))
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.55).ignoresSafeArea().onTapGesture { onClose() }
            VStack(spacing: 12) {
                header
                ScrollView {
                    VStack(spacing: 12) {
                        CamEnhanceRow(title: "Enhance - main & ultra wide",
                                      sub: "Used when the EN button is on. Output is limited to about 3000 px so the phone does not run out of memory.",
                                      value: $os.camEnhanceScale)
                        CamEnhanceRow(title: "Enhance - telephoto",
                                      sub: hasTele ? "Used for shots taken with the telephoto lens." : "No telephoto lens on this iPhone, setting is saved for later.",
                                      value: $os.camEnhanceTele)
                        steadyCard
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, max(os.bottom, 12) + 6)
            .frame(maxHeight: 560)
            .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(T.bg))
        }
    }
}

struct CameraApp: View {
    @EnvironmentObject var os: OS
    @StateObject var cam = CamModel()
    @State var timerSec = 0
    @State var count = 0
    @State var grid = false
    @State var baseZoom: CGFloat = 1
    @State var showSet = false
    @State var ring: CGPoint? = nil
    @State var ringTok = 0
    let zoomSteps: [CGFloat] = [1, 2, 5, 10, 30, 100]
    let teleSteps: [CGFloat] = [1, 2.5, 5, 15, 50, 100, 200]

    var steps: [CGFloat] { cam.lens == 2 ? teleSteps : zoomSteps }

    func zoomLabel() -> String {
        let d = cam.zoom * cam.lensBase
        let t = zoomText(d)
        return d >= 100 ? "Space " + t : t
    }

    func syncCam() {
        cam.enhanceOn = os.camEnhance
        cam.enhanceScale = os.camEnhanceScale
        cam.enhanceScaleTele = os.camEnhanceTele
        cam.steadyOn = os.camSteady
    }

    func goSpace() {
        if cam.lens == 0 {
            cam.setLens(1)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                cam.setZoom(CamModel.maxZoom)
                baseZoom = CamModel.maxZoom
            }
        } else {
            cam.setZoom(cam.maxZoomNow)
            baseZoom = cam.maxZoomNow
        }
    }

    func zoomText(_ z: CGFloat) -> String {
        z < 10 ? String(format: "%.1fx", z) : String(format: "%.0fx", z)
    }

    func countdown(_ n: Int) {
        if n <= 0 {
            count = 0
            cam.shoot()
            return
        }
        count = n
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { countdown(n - 1) }
    }

    func shutter() {
        syncCam()
        if cam.videoMode {
            cam.toggleRecord()
        } else if timerSec == 0 {
            cam.shoot()
        } else {
            countdown(timerSec)
        }
    }

    /// Tap to focus. The preview is scaled by the digital zoom around its center, so undo that for the layer point.
    func tapFocus(_ p: CGPoint) {
        ring = p
        ringTok += 1
        let t = ringTok
        if let layer = cam.previewLayer {
            let c = CGPoint(x: layer.bounds.midX, y: layer.bounds.midY)
            let k = max(cam.extraZoom, 1)
            cam.focus(atLayerPoint: CGPoint(x: c.x + (p.x - c.x) / k, y: c.y + (p.y - c.y) / k))
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
            if ringTok == t { ring = nil }
        }
    }

    func tapTele() {
        if cam.hasTele {
            cam.setLens(2)
        } else {
            cam.flash("This iPhone has no telephoto lens")
        }
    }

    var enLabel: String {
        if !os.camEnhance { return "EN" }
        return "EN \(cam.lens == 2 ? os.camEnhanceTele : os.camEnhanceScale)x"
    }

    var statusText: String {
        if cam.burstTotal > 0 { return (cam.night ? "Night: hold steady... " : "Hold steady... ") + "\(cam.burstDone)/\(cam.burstTotal)" }
        if cam.stacking > 0 { return "Merging frames..." }
        if cam.pending > 0 { return "Enhancing \(cam.pending)..." }
        return ""
    }

    var topRow: some View {
        HStack {
            Button { cam.flashOn.toggle() } label: {
                Image(systemName: cam.flashOn ? "bolt.fill" : "bolt.slash.fill")
                    .foregroundColor(cam.flashOn ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Button {
                os.camEnhance.toggle()
                cam.enhanceOn = os.camEnhance
            } label: {
                Text(enLabel)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(os.camEnhance ? T.onAccent : .white)
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Capsule().fill(os.camEnhance ? T.accent : Color.white.opacity(0.15)))
            }
            Button { grid.toggle() } label: {
                Image(systemName: "grid")
                    .foregroundColor(grid ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Spacer()
            if cam.recording {
                Text(String(format: "%02d:%02d", cam.recSeconds / 60, cam.recSeconds % 60))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Capsule().fill(Color.red))
            } else {
                Text(zoomLabel())
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .background(Capsule().fill(T.accent))
            }
            Spacer()
            Button { timerSec = timerSec == 0 ? 3 : (timerSec == 3 ? 10 : 0) } label: {
                ZStack {
                    Image(systemName: "timer").foregroundColor(timerSec == 0 ? .white : T.accent)
                    if timerSec > 0 {
                        Text("\(timerSec)")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(T.accent)
                            .offset(x: 12, y: -10)
                    }
                }
                .frame(width: 40, height: 40)
            }
            Button { cam.setNight(!cam.night) } label: {
                Image(systemName: cam.night ? "moon.stars.fill" : "moon.stars")
                    .foregroundColor(cam.night ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Button { showSet = true } label: {
                Image(systemName: "gearshape.fill")
                    .foregroundColor(.white)
                    .frame(width: 40, height: 40)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, os.padTop - 8)
    }

    var statusPill: some View {
        VStack {
            Spacer()
            if !statusText.isEmpty {
                Text(statusText)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Capsule().fill(Color.black.opacity(0.55)))
                    .padding(.bottom, 10)
            }
        }
        .allowsHitTesting(false)
    }

    var noticePill: some View {
        VStack {
            if !cam.notice.isEmpty {
                Text(cam.notice)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(Capsule().fill(Color.black.opacity(0.65)))
                    .padding(.top, 12)
            }
            Spacer()
        }
        .allowsHitTesting(false)
    }

    var focusRing: some View {
        ZStack {
            if let r = ring {
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .stroke(T.accent, lineWidth: 1.5)
                    .frame(width: 72, height: 72)
                    .position(x: r.x, y: r.y)
            }
        }
        .allowsHitTesting(false)
    }

    var brightnessBar: some View {
        HStack {
            Spacer()
            VStack(spacing: 6) {
                Image(systemName: "sun.max.fill")
                    .font(.system(size: 14))
                    .foregroundColor(.white)
                    .onTapGesture { cam.setBias(0) }
                Slider(value: Binding(get: { cam.bias }, set: { cam.setBias($0) }), in: -2...2)
                    .tint(T.accent)
                    .frame(width: 130)
                    .rotationEffect(.degrees(-90))
                    .frame(width: 30, height: 130)
                Text(String(format: "%+.1f", cam.bias))
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.white)
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 4)
            .background(Capsule().fill(Color.black.opacity(0.35)))
            .padding(.trailing, 8)
        }
    }

    var preview: some View {
        ZStack {
            Color(white: 0.1)
            if cam.authorized {
                CamPreview(session: cam.session, cam: cam).scaleEffect(cam.extraZoom)
            } else {
                Text("Allow camera access in iOS Settings")
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding()
            }
            if grid { GridLines() }
            if count > 0 {
                Text("\(count)").font(.system(size: 90, weight: .bold)).foregroundColor(.white)
            }
            statusPill
            noticePill
            focusRing
            brightnessBar
        }
        .aspectRatio(3.0 / 4.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 10)
        .padding(.top, 8)
        .gesture(
            MagnificationGesture()
                .onChanged { v in cam.setZoom(baseZoom * v) }
                .onEnded { _ in baseZoom = cam.zoom }
        )
        .simultaneousGesture(
            SpatialTapGesture().onEnded { v in tapFocus(v.location) }
        )
    }

    var zoomRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(0..<steps.count, id: \.self) { i in
                    Button {
                        cam.setZoom(steps[i])
                        baseZoom = steps[i]
                    } label: {
                        Text(zoomText(steps[i] * cam.lensBase))
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(abs(cam.zoom - steps[i]) < 0.05 ? T.onAccent : .white)
                            .padding(.horizontal, 10).padding(.vertical, 7)
                            .background(Capsule().fill(abs(cam.zoom - steps[i]) < 0.05 ? T.accent : Color.white.opacity(0.12)))
                    }
                }
                Button { goSpace() } label: {
                    Text("Space 800x")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(cam.zoom >= cam.maxZoomNow - 1 ? T.onAccent : .white)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(Capsule().fill(cam.zoom >= cam.maxZoomNow - 1 ? T.accent : Color.purple.opacity(0.55)))
                }
            }
            .padding(.horizontal, 12)
        }
        .padding(.top, 10)
    }

    var teleButton: some View {
        Button { tapTele() } label: {
            HStack(spacing: 4) {
                Image(systemName: "binoculars.fill").font(.system(size: 12))
                Text("2x").font(.system(size: 14, weight: .medium))
            }
            .foregroundColor(cam.lens == 2 ? T.onAccent : .white)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(Capsule().fill(cam.lens == 2 ? T.accent : Color.white.opacity(0.12)))
            .opacity(cam.hasTele ? 1 : 0.4)
        }
    }

    var modeRow: some View {
        HStack(spacing: 8) {
            Button { cam.setLens(0) } label: {
                Text("0.5x")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.lens == 0 ? T.onAccent : .white)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill(cam.lens == 0 ? T.accent : Color.white.opacity(0.12)))
            }
            Button { cam.setLens(1) } label: {
                Text("1x")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.lens == 1 ? T.onAccent : .white)
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill(cam.lens == 1 ? T.accent : Color.white.opacity(0.12)))
            }
            Button { cam.setMode(video: false) } label: {
                Text("Photo")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? .white : T.onAccent)
                    .padding(.horizontal, 14).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? Color.white.opacity(0.12) : T.accent))
            }
            Button { cam.setMode(video: true) } label: {
                Text("Video")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? T.onAccent : .white)
                    .padding(.horizontal, 14).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? T.accent : Color.white.opacity(0.12)))
            }
            teleButton
        }
        .padding(.bottom, 14)
    }

    var bottomRow: some View {
        HStack {
            Button {
                if let p = appFor("photos") { os.launch(p) }
            } label: {
                if let img = cam.last {
                    Image(uiImage: img).resizable().scaledToFill()
                        .frame(width: 54, height: 54).clipShape(Circle())
                } else {
                    Circle().fill(T.card).frame(width: 54, height: 54)
                }
            }
            Spacer()
            Button { shutter() } label: {
                ZStack {
                    Circle().stroke(Color.white, lineWidth: 4).frame(width: 78, height: 78)
                    if cam.videoMode {
                        RoundedRectangle(cornerRadius: cam.recording ? 10 : 33, style: .continuous)
                            .fill(Color.red)
                            .frame(width: cam.recording ? 34 : 66, height: cam.recording ? 34 : 66)
                    } else {
                        Circle().fill(Color.white).frame(width: 64, height: 64)
                    }
                }
            }
            Spacer()
            Button { cam.flip() } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .foregroundColor(.white)
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(T.card))
            }
        }
        .padding(.horizontal, 36)
        .padding(.bottom, 40)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                topRow
                preview
                zoomRow
                Spacer()
                modeRow
                bottomRow
            }
            if showSet {
                CamSettingsPanel(hasTele: cam.hasTele) { showSet = false }
            }
        }
        .onAppear {
            syncCam()
            cam.start()
            DispatchQueue.global(qos: .utility).async { _ = ESRGAN.shared }
            os.backHandlers["cam"] = {
                if showSet { showSet = false; return true }
                return false
            }
        }
        .onChange(of: cam.lens) { _ in baseZoom = 1 }
        .onChange(of: os.camSteady) { _ in
            syncCam()
            cam.setZoom(cam.zoom)
        }
        .onChange(of: os.camEnhanceScale) { _ in syncCam() }
        .onChange(of: os.camEnhanceTele) { _ in syncCam() }
        .onDisappear { cam.stop() }
    }
}

// MARK: - Photos (gallery app)
struct Thumb: View {
    let url: URL
    let maxSize: CGFloat
    var fill = true
    @State var img: UIImage? = nil

    func load() {
        if let c = Gallery.cached(url, max: maxSize) {
            img = c
            return
        }
        DispatchQueue.global().async {
            let t = Gallery.thumb(url, max: maxSize)
            if let t = t { Gallery.store(t, url, maxSize) }
            DispatchQueue.main.async { img = t }
        }
    }

    var body: some View {
        Group {
            if let i = img {
                if fill {
                    Image(uiImage: i).resizable().scaledToFill()
                } else {
                    Image(uiImage: i).resizable().scaledToFit()
                }
            } else {
                T.card
            }
        }
        .onAppear { load() }
    }
}

struct VideoView: View {
    @State var player: AVPlayer
    init(url: URL) { _player = State(initialValue: AVPlayer(url: url)) }
    var body: some View {
        VideoPlayer(player: player)
            .onAppear { player.play() }
            .onDisappear { player.pause() }
    }
}

struct GalleryGroup: Identifiable {
    let id: String
    let title: String
    let items: [URL]
}

final class GalleryVM: ObservableObject {
    @Published var files: [URL] = []
    @Published var dates: [URL: Date] = [:]
    @Published var trash: [URL] = []
    @Published var tab = 0            // 0 All, 1 Favorites, 2 Videos, 3 Trash
    @Published var viewing = false
    @Published var cur = 0
    @Published var selecting = false
    @Published var selected: Set<URL> = []
    @Published var editing: URL? = nil
    @Published var favs: Set<String> = Gallery.favs { didSet { Gallery.favs = favs } }
    @Published var toast = ""
    @Published var version = 0
    @Published var showImport = false
    @Published var showShare = false
    @Published var shareItems: [URL] = []
    @Published var confirmForever = false
    @Published var showInfo = false
    var pendingForever: [URL] = []

    static let dayFmt: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "EEE, d MMM yyyy"
        return f
    }()

    static func dayKey(_ d: Date) -> String {
        String(Int(Calendar.current.startOfDay(for: d).timeIntervalSince1970))
    }

    static func dayTitle(_ d: Date) -> String {
        if Calendar.current.isDateInToday(d) { return "Today" }
        if Calendar.current.isDateInYesterday(d) { return "Yesterday" }
        return dayFmt.string(from: d)
    }

    var shown: [URL] {
        switch tab {
        case 1: return files.filter { favs.contains($0.lastPathComponent) }
        case 2: return files.filter { Gallery.isVideo($0) }
        case 3: return trash
        default: return files
        }
    }

    var groups: [GalleryGroup] {
        let list = shown
        if tab == 3 { return list.isEmpty ? [] : [GalleryGroup(id: "trash", title: "Recently deleted", items: list)] }
        var out: [GalleryGroup] = []
        var curKey = ""
        var curTitle = ""
        var bucket: [URL] = []
        for u in list {
            let d = dates[u] ?? Date.distantPast
            let key = GalleryVM.dayKey(d)
            if key != curKey {
                if !bucket.isEmpty { out.append(GalleryGroup(id: curKey, title: curTitle, items: bucket)) }
                curKey = key
                curTitle = GalleryVM.dayTitle(d)
                bucket = []
            }
            bucket.append(u)
        }
        if !bucket.isEmpty { out.append(GalleryGroup(id: curKey, title: curTitle, items: bucket)) }
        return out
    }

    func reload() {
        Gallery.purgeTrash()
        let dated = Gallery.listDated(in: Gallery.dir, modified: false)
        files = dated.map { $0.0 }
        var m: [URL: Date] = [:]
        for (u, d) in dated { m[u] = d }
        dates = m
        trash = Gallery.listDated(in: Gallery.trashDir, modified: true).map { $0.0 }
        selected = selected.filter { files.contains($0) || trash.contains($0) }
    }

    func say(_ s: String) {
        toast = s
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            if self.toast == s { self.toast = "" }
        }
    }

    func isFav(_ u: URL) -> Bool { favs.contains(u.lastPathComponent) }

    func toggleFav(_ u: URL) {
        let n = u.lastPathComponent
        if favs.contains(n) { favs.remove(n) } else { favs.insert(n) }
    }

    func favSelected() {
        let all = selected.allSatisfy { isFav($0) }
        for u in selected {
            let n = u.lastPathComponent
            if all { favs.remove(n) } else { favs.insert(n) }
        }
        exitSelect()
    }

    func trashURLs(_ list: [URL]) {
        for u in list { Gallery.moveToTrash(u) }
        Gallery.cache.removeAllObjects()
        exitSelect()
        reload()
        say(list.count == 1 ? "Moved to Trash" : "\(list.count) items moved to Trash")
    }

    func restoreURLs(_ list: [URL]) {
        for u in list { Gallery.restore(u) }
        exitSelect()
        reload()
        say("Restored")
    }

    func deleteForever(_ list: [URL]) {
        for u in list { try? FileManager.default.removeItem(at: u) }
        Gallery.cache.removeAllObjects()
        exitSelect()
        reload()
        say("Deleted")
    }

    func askForever(_ list: [URL]) {
        pendingForever = list
        confirmForever = true
    }

    func beginSelect(_ u: URL) {
        selecting = true
        selected = [u]
    }

    func toggleSel(_ u: URL) {
        if selected.contains(u) { selected.remove(u) } else { selected.insert(u) }
    }

    func exitSelect() {
        selecting = false
        selected = []
    }

    func share(_ list: [URL]) {
        if list.isEmpty { return }
        shareItems = list
        showShare = true
    }

    func open(_ u: URL) {
        if let i = shown.firstIndex(of: u) {
            cur = i
            viewing = true
        }
    }

    func curURL() -> URL? {
        let l = shown
        return (cur >= 0 && cur < l.count) ? l[cur] : nil
    }

    func back() -> Bool {
        if editing != nil { editing = nil; return true }
        if showInfo { showInfo = false; return true }
        if viewing { viewing = false; return true }
        if selecting { exitSelect(); return true }
        if tab != 0 { tab = 0; return true }
        return false
    }
}

struct GalShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct GalleryImporter: UIViewControllerRepresentable {
    let onDone: (Int) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var cfg = PHPickerConfiguration()
        cfg.filter = .any(of: [.images, .videos])
        cfg.selectionLimit = 0
        let vc = PHPickerViewController(configuration: cfg)
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onDone) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onDone: (Int) -> Void
        init(_ f: @escaping (Int) -> Void) { onDone = f }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            if results.isEmpty {
                DispatchQueue.main.async { self.onDone(0) }
                return
            }
            let group = DispatchGroup()
            let lock = NSLock()
            var count = 0
            for r in results {
                let prov = r.itemProvider
                let isMovie = prov.hasItemConformingToTypeIdentifier("public.movie")
                let type = isMovie ? "public.movie" : "public.image"
                if !prov.hasItemConformingToTypeIdentifier(type) { continue }
                group.enter()
                prov.loadFileRepresentation(forTypeIdentifier: type) { url, _ in
                    if let u = url {
                        let ext = u.pathExtension.lowercased()
                        let allowed = Gallery.imageExts + Gallery.videoExts
                        let e = allowed.contains(ext) ? ext : (isMovie ? "mov" : "jpg")
                        let stamp = Int(Date().timeIntervalSince1970 * 1000)
                        let rnd = Int.random(in: 0...99999)
                        let dest = Gallery.dir.appendingPathComponent("IMP_\(stamp)_\(rnd).\(e)")
                        if (try? FileManager.default.copyItem(at: u, to: dest)) != nil {
                            lock.lock()
                            count += 1
                            lock.unlock()
                        }
                    }
                    group.leave()
                }
            }
            group.notify(queue: .main) { self.onDone(count) }
        }
    }
}

// Pinch / double-tap zoom (UIScrollView)
final class GalZoomScroll: UIScrollView, UIScrollViewDelegate {
    let iv = UIImageView()
    var onTap: (() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        delegate = self
        minimumZoomScale = 1
        maximumZoomScale = 8
        bouncesZoom = true
        showsVerticalScrollIndicator = false
        showsHorizontalScrollIndicator = false
        contentInsetAdjustmentBehavior = .never
        iv.contentMode = .scaleAspectFit
        addSubview(iv)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(doubleTap(_:)))
        dbl.numberOfTapsRequired = 2
        addGestureRecognizer(dbl)
        let one = UITapGestureRecognizer(target: self, action: #selector(singleTap))
        one.require(toFail: dbl)
        addGestureRecognizer(one)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? { iv }

    override func layoutSubviews() {
        super.layoutSubviews()
        if zoomScale <= 1.001 { iv.frame = bounds }
    }

    @objc func singleTap() { onTap?() }

    @objc func doubleTap(_ g: UITapGestureRecognizer) {
        if zoomScale > 1.01 {
            setZoomScale(1, animated: true)
            return
        }
        let p = g.location(in: iv)
        let s: CGFloat = 3
        let w = bounds.width / s
        let h = bounds.height / s
        zoom(to: CGRect(x: p.x - w / 2, y: p.y - h / 2, width: w, height: h), animated: true)
    }
}

struct GalZoomImage: UIViewRepresentable {
    let image: UIImage?
    let onTap: () -> Void

    func makeUIView(context: Context) -> GalZoomScroll {
        let v = GalZoomScroll()
        v.backgroundColor = .clear
        return v
    }

    func updateUIView(_ v: GalZoomScroll, context: Context) {
        v.onTap = onTap
        if v.iv.image !== image {
            v.iv.image = image
            v.setZoomScale(1, animated: false)
        }
    }
}

struct GalleryCell: View {
    @ObservedObject var vm: GalleryVM
    let url: URL

    func tap() {
        if vm.selecting { vm.toggleSel(url) } else { vm.open(url) }
    }

    var body: some View {
        let sel = vm.selected.contains(url)
        Color.clear
            .aspectRatio(1, contentMode: .fit)
            .overlay(Thumb(url: url, maxSize: 300))
            .overlay(alignment: .bottomLeading) {
                if Gallery.isVideo(url) {
                    Image(systemName: "video.fill").font(.system(size: 12)).foregroundColor(.white).padding(6)
                }
            }
            .overlay(alignment: .bottomTrailing) {
                if vm.isFav(url) && vm.tab != 3 {
                    Image(systemName: "heart.fill").font(.system(size: 12)).foregroundColor(.white).padding(6)
                }
            }
            .overlay(alignment: .topTrailing) {
                if vm.selecting {
                    Image(systemName: sel ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 20))
                        .foregroundColor(sel ? T.accent : .white)
                        .padding(6)
                }
            }
            .opacity(sel ? 0.7 : 1)
            .clipped()
            .contentShape(Rectangle())
            .onTapGesture { tap() }
            .onLongPressGesture(minimumDuration: 0.35) {
                if !vm.selecting { vm.beginSelect(url) }
            }
    }
}

struct GalleryHeader: View {
    @ObservedObject var vm: GalleryVM

    var body: some View {
        HStack(spacing: 14) {
            if vm.selecting {
                Button { vm.exitSelect() } label: {
                    Image(systemName: "xmark").foregroundColor(.white).frame(width: 36, height: 36)
                }
                Text("\(vm.selected.count) selected")
                    .font(.system(size: 20)).foregroundColor(.white)
                Spacer()
                Button { vm.selected = Set(vm.shown) } label: {
                    Text("All").font(.system(size: 15, weight: .medium)).foregroundColor(T.accent)
                }
            } else {
                Text("Photos").font(.system(size: 30)).foregroundColor(.white)
                Spacer()
                if vm.tab != 3 {
                    Button { vm.showImport = true } label: {
                        Image(systemName: "plus").foregroundColor(.white).frame(width: 36, height: 36)
                    }
                }
                Button { vm.selecting = true } label: {
                    Image(systemName: "checkmark.circle").foregroundColor(.white).frame(width: 36, height: 36)
                }
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 8)
    }
}

struct GalleryTabs: View {
    @ObservedObject var vm: GalleryVM
    let names = ["All", "Favorites", "Videos", "Trash"]
    let icons = ["photo.on.rectangle", "heart", "video", "trash"]

    func label(_ i: Int) -> String {
        if i == 3 && !vm.trash.isEmpty { return "Trash (\(vm.trash.count))" }
        return names[i]
    }

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(0..<names.count, id: \.self) { i in
                    Button {
                        vm.tab = i
                        vm.exitSelect()
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: icons[i]).font(.system(size: 12))
                            Text(label(i)).font(.system(size: 13, weight: .medium))
                        }
                        .foregroundColor(vm.tab == i ? T.onAccent : .white)
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Capsule().fill(vm.tab == i ? T.accent : Color.white.opacity(0.12)))
                    }
                }
            }
            .padding(.horizontal, 18)
        }
        .padding(.bottom, 8)
    }
}

struct GalleryGrid: View {
    @EnvironmentObject var os: OS
    @ObservedObject var vm: GalleryVM
    let cols = Array(repeating: GridItem(.flexible(), spacing: 2), count: 3)

    var emptyText: String {
        switch vm.tab {
        case 1: return "No favorites yet. Open a photo and tap the heart."
        case 2: return "No videos yet."
        case 3: return "Trash is empty."
        default: return "No photos yet. Take one with the Camera or tap + to import."
        }
    }

    var trashBar: some View {
        HStack {
            Text("Items are deleted after 30 days")
                .font(.system(size: 12)).foregroundColor(.white.opacity(0.6))
            Spacer()
            if !vm.trash.isEmpty {
                Button { vm.askForever(vm.trash) } label: {
                    Text("Empty Trash").font(.system(size: 13, weight: .medium)).foregroundColor(T.accent)
                }
            }
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 6)
    }

    func section(_ g: GalleryGroup) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(g.title)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white.opacity(0.8))
                .padding(.horizontal, 16)
                .padding(.top, 10)
            LazyVGrid(columns: cols, spacing: 2) {
                ForEach(g.items, id: \.self) { u in
                    GalleryCell(vm: vm, url: u)
                }
            }
        }
    }

    var bottomBar: some View {
        VStack {
            Spacer()
            HStack(spacing: 0) {
                if vm.tab == 3 {
                    GalBarButton(icon: "arrow.uturn.backward", label: "Restore") { vm.restoreURLs(Array(vm.selected)) }
                    GalBarButton(icon: "trash.slash", label: "Delete forever") { vm.askForever(Array(vm.selected)) }
                } else {
                    GalBarButton(icon: "square.and.arrow.up", label: "Share") { vm.share(Array(vm.selected)) }
                    GalBarButton(icon: "heart", label: "Favorite") { vm.favSelected() }
                    GalBarButton(icon: "trash", label: "Delete") { vm.trashURLs(Array(vm.selected)) }
                }
            }
            .padding(.top, 10)
            .padding(.bottom, max(os.bottom, 12) + 4)
            .background(T.card.ignoresSafeArea())
        }
    }

    var body: some View {
        let gs = vm.groups
        ZStack {
            VStack(spacing: 0) {
                GalleryHeader(vm: vm)
                GalleryTabs(vm: vm)
                if vm.tab == 3 { trashBar }
                if gs.isEmpty {
                    Spacer()
                    Text(emptyText)
                        .foregroundColor(.white.opacity(0.6))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 0) {
                            ForEach(gs) { g in section(g) }
                            Color.clear.frame(height: vm.selecting ? 110 : 40)
                        }
                    }
                }
            }
            if vm.selecting && !vm.selected.isEmpty { bottomBar }
        }
    }
}

struct GalBarButton: View {
    let icon: String
    let label: String
    var tint: Color = .white
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 20))
                Text(label).font(.system(size: 11))
            }
            .foregroundColor(tint)
            .frame(maxWidth: .infinity)
        }
    }
}

struct GalleryPage: View {
    let url: URL
    let current: Bool
    let onTap: () -> Void
    @State var img: UIImage? = nil
    @State var playing = false

    func load() {
        if img != nil { return }
        let isVid = Gallery.isVideo(url)
        DispatchQueue.global(qos: .userInitiated).async {
            let t = Gallery.thumb(url, max: isVid ? 1200 : 3000)
            DispatchQueue.main.async { img = t }
        }
    }

    var photoBody: some View {
        ZStack {
            GalZoomImage(image: img, onTap: onTap)
            if img == nil { ProgressView().tint(.white) }
        }
    }

    var videoBody: some View {
        ZStack {
            if playing {
                VideoView(url: url)
            } else {
                if let i = img {
                    Image(uiImage: i).resizable().scaledToFit()
                }
                Button { playing = true } label: {
                    Image(systemName: "play.circle.fill")
                        .font(.system(size: 64))
                        .foregroundColor(.white.opacity(0.9))
                }
            }
        }
    }

    var body: some View {
        ZStack {
            if Gallery.isVideo(url) { videoBody } else { photoBody }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear { load() }
        .onChange(of: current) { c in
            if !c { playing = false }
        }
    }
}

struct GalleryViewer: View {
    @EnvironmentObject var os: OS
    @ObservedObject var vm: GalleryVM
    @State var chrome = true

    func dateTitle(_ u: URL?) -> String {
        guard let u = u, let d = vm.dates[u] ?? (vm.trash.contains(u) ? Date() : nil) else { return "" }
        let f = DateFormatter()
        f.dateFormat = "d MMM yyyy, h:mm a"
        return f.string(from: d)
    }

    func setWallpaper(_ u: URL) {
        DispatchQueue.global(qos: .userInitiated).async {
            let img = Gallery.thumb(u, max: 2400)
            DispatchQueue.main.async {
                if let i = img {
                    os.setWallpaperPhoto(i)
                    vm.say("Wallpaper set")
                }
            }
        }
    }

    func deleteCurrent() {
        guard let u = vm.curURL() else { return }
        vm.trashURLs([u])
        if vm.shown.isEmpty {
            vm.viewing = false
        } else {
            vm.cur = min(vm.cur, vm.shown.count - 1)
        }
    }

    func restoreCurrent() {
        guard let u = vm.curURL() else { return }
        vm.restoreURLs([u])
        if vm.shown.isEmpty { vm.viewing = false } else { vm.cur = min(vm.cur, vm.shown.count - 1) }
    }

    func topBar(_ u: URL?) -> some View {
        HStack {
            Button { vm.viewing = false; vm.showInfo = false } label: {
                Image(systemName: "chevron.left").foregroundColor(.white).frame(width: 44, height: 44)
            }
            Spacer()
            Text(dateTitle(u)).font(.system(size: 14, weight: .medium)).foregroundColor(.white)
            Spacer()
            Menu {
                if let u = u, !Gallery.isVideo(u), vm.tab != 3 {
                    Button { setWallpaper(u) } label: { Label("Set as wallpaper", systemImage: "photo.on.rectangle") }
                }
                Button { vm.showInfo = true } label: { Label("Details", systemImage: "info.circle") }
                if let u = u { Button { vm.share([u]) } label: { Label("Share", systemImage: "square.and.arrow.up") } }
            } label: {
                Image(systemName: "ellipsis").foregroundColor(.white).frame(width: 44, height: 44)
            }
        }
        .padding(.horizontal, 12)
        .background(LinearGradient(colors: [Color.black.opacity(0.65), Color.clear], startPoint: .top, endPoint: .bottom))
    }

    func bottomBar(_ u: URL?) -> some View {
        HStack(spacing: 0) {
            if vm.tab == 3 {
                GalBarButton(icon: "arrow.uturn.backward", label: "Restore") { restoreCurrent() }
                GalBarButton(icon: "trash.slash", label: "Delete forever") {
                    if let x = u { vm.askForever([x]) }
                }
            } else if let x = u {
                GalBarButton(icon: "square.and.arrow.up", label: "Share") { vm.share([x]) }
                GalBarButton(icon: vm.isFav(x) ? "heart.fill" : "heart", label: "Favorite",
                             tint: vm.isFav(x) ? T.accent : .white) { vm.toggleFav(x) }
                if !Gallery.isVideo(x) {
                    GalBarButton(icon: "slider.horizontal.3", label: "Edit") { vm.editing = x }
                }
                GalBarButton(icon: "info.circle", label: "Info") { vm.showInfo = true }
                GalBarButton(icon: "trash", label: "Delete") { deleteCurrent() }
            }
        }
        .padding(.top, 12)
        .padding(.bottom, max(os.bottom, 12) + 4)
        .background(LinearGradient(colors: [Color.clear, Color.black.opacity(0.7)], startPoint: .top, endPoint: .bottom))
    }

    func infoCard(_ u: URL?) -> some View {
        VStack {
            Spacer()
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("Details").font(.system(size: 18, weight: .medium)).foregroundColor(.white)
                    Spacer()
                    Button { vm.showInfo = false } label: {
                        Image(systemName: "xmark").foregroundColor(.white).frame(width: 32, height: 32)
                    }
                }
                if let x = u {
                    let rows = Gallery.info(x)
                    ForEach(0..<rows.count, id: \.self) { i in
                        HStack(alignment: .top) {
                            Text(rows[i].0).font(.system(size: 13)).foregroundColor(.white.opacity(0.55))
                                .frame(width: 90, alignment: .leading)
                            Text(rows[i].1).font(.system(size: 13)).foregroundColor(.white)
                            Spacer()
                        }
                    }
                }
            }
            .padding(18)
            .padding(.bottom, max(os.bottom, 12))
            .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(T.card))
        }
    }

    var body: some View {
        let list = vm.shown
        let u: URL? = (vm.cur >= 0 && vm.cur < list.count) ? list[vm.cur] : nil
        ZStack {
            Color.black.ignoresSafeArea()
            TabView(selection: $vm.cur) {
                ForEach(Array(list.enumerated()), id: \.element) { pair in
                    GalleryPage(url: pair.element, current: pair.offset == vm.cur, onTap: { chrome.toggle() })
                        .id(pair.element.path + "#\(vm.version)")
                        .tag(pair.offset)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            if chrome {
                VStack(spacing: 0) {
                    topBar(u)
                    Spacer()
                    bottomBar(u)
                }
            }
            if vm.showInfo { infoCard(u) }
        }
    }
}

struct PhotosApp: View {
    @EnvironmentObject var os: OS
    @StateObject var vm = GalleryVM()

    func importDone(_ n: Int) {
        vm.showImport = false
        vm.reload()
        if n > 0 { vm.say("Imported \(n)") }
    }

    @ViewBuilder var toastView: some View {
        if !vm.toast.isEmpty {
            VStack {
                Spacer()
                Text(vm.toast)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 16).padding(.vertical, 9)
                    .background(Capsule().fill(Color.black.opacity(0.75)))
                    .padding(.bottom, max(os.bottom, 12) + 90)
            }
            .allowsHitTesting(false)
        }
    }

    var body: some View {
        ZStack {
            GalleryGrid(vm: vm)
            if vm.viewing { GalleryViewer(vm: vm) }
            if let e = vm.editing { GalleryEditor(vm: vm, url: e).id(e) }
            toastView
        }
        .background(
            Color.clear.sheet(isPresented: $vm.showImport) {
                GalleryImporter { n in importDone(n) }
            }
        )
        .background(
            Color.clear.alert("Delete forever?", isPresented: $vm.confirmForever) {
                Button("Delete", role: .destructive) { vm.deleteForever(vm.pendingForever) }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This cannot be undone.")
            }
        )
        .sheet(isPresented: $vm.showShare) { GalShareSheet(items: vm.shareItems) }
        .onAppear {
            Gallery.cache.removeAllObjects()
            vm.reload()
            os.backHandlers["photos"] = { vm.back() }
        }
    }
}

// MARK: - Photo editor (crop, rotate, flip, adjust, filters)
struct GalEditState: Equatable {
    var rot = 0                 // quarter turns clockwise, 0...3
    var flip = false
    var crop = CGRect(x: 0, y: 0, width: 1, height: 1)   // normalized, origin top-left, on the rotated image
    var bright = 0.0            // -0.5...0.5
    var contrast = 1.0          // 0.5...1.5
    var sat = 1.0               // 0...2
    var warm = 0.0              // -1...1
    var sharp = 0.0             // 0...2
    var vignette = 0.0          // 0...2
    var filter = 0
}

enum GalleryFX {
    static let filters: [(String, String?)] = [
        ("Original", nil), ("Vivid", "CIPhotoEffectChrome"), ("Warm", "CIPhotoEffectInstant"),
        ("Fade", "CIPhotoEffectFade"), ("Mono", "CIPhotoEffectMono"), ("Noir", "CIPhotoEffectNoir"),
        ("Process", "CIPhotoEffectProcess"), ("Tonal", "CIPhotoEffectTonal"),
        ("Transfer", "CIPhotoEffectTransfer"), ("Sepia", "CISepiaTone")
    ]

    static func norm(_ ci: CIImage) -> CIImage {
        let e = ci.extent
        if e.origin.x == 0 && e.origin.y == 0 { return ci }
        return ci.transformed(by: CGAffineTransform(translationX: -e.origin.x, y: -e.origin.y))
    }

    static func oriented(_ ci: CIImage, rot: Int, flip: Bool) -> CIImage {
        var o = ci
        if flip { o = norm(o.oriented(.upMirrored)) }
        switch rot % 4 {
        case 1: o = norm(o.oriented(.right))
        case 2: o = norm(o.oriented(.down))
        case 3: o = norm(o.oriented(.left))
        default: break
        }
        return o
    }

    static func apply(_ name: String, _ img: CIImage) -> CIImage {
        guard let f = CIFilter(name: name) else { return img }
        f.setValue(img, forKey: kCIInputImageKey)
        return f.outputImage ?? img
    }

    static func adjust(_ ci: CIImage, _ s: GalEditState) -> CIImage {
        var o = ci
        if s.filter > 0 && s.filter < filters.count, let name = filters[s.filter].1 {
            o = apply(name, o)
        }
        if let f = CIFilter(name: "CIColorControls") {
            f.setValue(o, forKey: kCIInputImageKey)
            f.setValue(s.bright, forKey: kCIInputBrightnessKey)
            f.setValue(s.contrast, forKey: kCIInputContrastKey)
            f.setValue(s.sat, forKey: kCIInputSaturationKey)
            if let r = f.outputImage { o = r }
        }
        if abs(s.warm) > 0.01, let f = CIFilter(name: "CITemperatureAndTint") {
            f.setValue(o, forKey: kCIInputImageKey)
            f.setValue(CIVector(x: 6500, y: 0), forKey: "inputNeutral")
            f.setValue(CIVector(x: CGFloat(6500 - s.warm * 2500), y: 0), forKey: "inputTargetNeutral")
            if let r = f.outputImage { o = r }
        }
        if s.sharp > 0.01, let f = CIFilter(name: "CISharpenLuminance") {
            f.setValue(o, forKey: kCIInputImageKey)
            f.setValue(s.sharp, forKey: kCIInputSharpnessKey)
            if let r = f.outputImage { o = r }
        }
        if s.vignette > 0.01, let f = CIFilter(name: "CIVignette") {
            f.setValue(o, forKey: kCIInputImageKey)
            f.setValue(s.vignette, forKey: kCIInputIntensityKey)
            f.setValue(2.0, forKey: kCIInputRadiusKey)
            if let r = f.outputImage { o = r }
        }
        return o
    }

    static func cropped(_ ci: CIImage, _ r: CGRect) -> CIImage {
        let e = ci.extent
        let rect = CGRect(x: e.minX + r.minX * e.width,
                          y: e.minY + (1 - r.maxY) * e.height,
                          width: r.width * e.width,
                          height: r.height * e.height).integral
        let c = ci.cropped(to: rect)
        return c.transformed(by: CGAffineTransform(translationX: -rect.minX, y: -rect.minY))
    }

    static func make(_ base: CIImage, _ s: GalEditState, crop: Bool) -> CIImage {
        var o = oriented(base, rot: s.rot, flip: s.flip)
        o = adjust(o, s)
        if crop { o = cropped(o, s.crop) }
        return o
    }

    static func render(_ ci: CIImage) -> UIImage? {
        let e = ci.extent
        if e.isEmpty || e.isInfinite { return nil }
        guard let cg = CamModel.ciContext.createCGImage(ci, from: e) else { return nil }
        return UIImage(cgImage: cg)
    }
}

struct GalAdjRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let neutral: Double

    var body: some View {
        HStack(spacing: 10) {
            Text(title)
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.85))
                .frame(width: 76, alignment: .leading)
            Slider(value: $value, in: range).tint(T.accent)
            Button { value = neutral } label: {
                Image(systemName: "arrow.counterclockwise")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.6))
                    .frame(width: 26, height: 26)
            }
        }
    }
}

struct GalCropOverlay: View {
    @Binding var crop: CGRect
    let imgAspect: CGFloat
    let lock: CGFloat
    @State var start: CGRect? = nil

    func rectFrom(_ fx: CGFloat, _ fy: CGFloat, _ mx: CGFloat, _ my: CGFloat) -> CGRect {
        let sx: CGFloat = mx >= fx ? 1 : -1
        let sy: CGFloat = my >= fy ? 1 : -1
        let availW = sx > 0 ? 1 - fx : fx
        let availH = sy > 0 ? 1 - fy : fy
        var w = min(abs(mx - fx), availW)
        var h = min(abs(my - fy), availH)
        if lock > 0 {
            let k = imgAspect / lock
            w = min(w, availH / k)
            w = max(w, 0.05)
            h = w * k
        }
        w = max(w, 0.05)
        h = max(h, 0.05)
        let x = min(max(sx > 0 ? fx : fx - w, 0), 1 - w)
        let y = min(max(sy > 0 ? fy : fy - h, 0), 1 - h)
        return CGRect(x: x, y: y, width: w, height: h)
    }

    func moveGesture(_ W: CGFloat, _ H: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .named("galcrop"))
            .onChanged { v in
                if start == nil { start = crop }
                guard let s = start else { return }
                let x = min(max(s.minX + v.translation.width / W, 0), 1 - s.width)
                let y = min(max(s.minY + v.translation.height / H, 0), 1 - s.height)
                crop = CGRect(x: x, y: y, width: s.width, height: s.height)
            }
            .onEnded { _ in start = nil }
    }

    /// idx: 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right. The opposite corner stays fixed.
    func cornerGesture(_ idx: Int, _ W: CGFloat, _ H: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .named("galcrop"))
            .onChanged { v in
                if start == nil { start = crop }
                guard let s = start else { return }
                let left = idx % 2 == 0
                let top = idx < 2
                let fx = left ? s.maxX : s.minX
                let fy = top ? s.maxY : s.minY
                let mx0 = left ? s.minX : s.maxX
                let my0 = top ? s.minY : s.maxY
                let mx = min(max(mx0 + v.translation.width / W, 0), 1)
                let my = min(max(my0 + v.translation.height / H, 0), 1)
                crop = rectFrom(fx, fy, mx, my)
            }
            .onEnded { _ in start = nil }
    }

    func handle(_ idx: Int, _ r: CGRect, _ W: CGFloat, _ H: CGFloat) -> some View {
        let px = idx % 2 == 0 ? r.minX : r.maxX
        let py = idx < 2 ? r.minY : r.maxY
        return ZStack {
            Circle().fill(Color.white).frame(width: 20, height: 20)
        }
        .frame(width: 48, height: 48)
        .contentShape(Rectangle())
        .position(x: px, y: py)
        .gesture(cornerGesture(idx, W, H))
    }

    func thirds(_ r: CGRect) -> some View {
        Path { p in
            p.move(to: CGPoint(x: r.minX + r.width / 3, y: r.minY))
            p.addLine(to: CGPoint(x: r.minX + r.width / 3, y: r.maxY))
            p.move(to: CGPoint(x: r.minX + r.width * 2 / 3, y: r.minY))
            p.addLine(to: CGPoint(x: r.minX + r.width * 2 / 3, y: r.maxY))
            p.move(to: CGPoint(x: r.minX, y: r.minY + r.height / 3))
            p.addLine(to: CGPoint(x: r.maxX, y: r.minY + r.height / 3))
            p.move(to: CGPoint(x: r.minX, y: r.minY + r.height * 2 / 3))
            p.addLine(to: CGPoint(x: r.maxX, y: r.minY + r.height * 2 / 3))
        }
        .stroke(Color.white.opacity(0.35), lineWidth: 1)
        .allowsHitTesting(false)
    }

    var body: some View {
        GeometryReader { g in
            let W = g.size.width
            let H = g.size.height
            let r = CGRect(x: crop.minX * W, y: crop.minY * H, width: crop.width * W, height: crop.height * H)
            ZStack {
                Path { p in
                    p.addRect(CGRect(x: 0, y: 0, width: W, height: H))
                    p.addRect(r)
                }
                .fill(Color.black.opacity(0.55), style: FillStyle(eoFill: true))
                .allowsHitTesting(false)
                Rectangle().stroke(Color.white, lineWidth: 1.5)
                    .frame(width: r.width, height: r.height)
                    .position(x: r.midX, y: r.midY)
                    .allowsHitTesting(false)
                thirds(r)
                Color.white.opacity(0.001)
                    .frame(width: r.width, height: r.height)
                    .position(x: r.midX, y: r.midY)
                    .gesture(moveGesture(W, H))
                handle(0, r, W, H)
                handle(1, r, W, H)
                handle(2, r, W, H)
                handle(3, r, W, H)
            }
            .coordinateSpace(name: "galcrop")
        }
    }
}

struct GalleryEditor: View {
    @EnvironmentObject var os: OS
    @ObservedObject var vm: GalleryVM
    let url: URL
    @State var base: CIImage? = nil
    @State var baseSize = CGSize(width: 1, height: 1)
    @State var st = GalEditState()
    @State var preview: UIImage? = nil
    @State var tab = 0           // 0 crop, 1 adjust, 2 filters
    @State var lockIdx = 0
    @State var token = 0
    @State var saving = false
    @State var thumbs: [UIImage] = []
    let aspects: [(String, CGFloat)] = [("Free", 0), ("1:1", 1), ("4:3", 4.0 / 3.0), ("3:4", 3.0 / 4.0), ("16:9", 16.0 / 9.0), ("9:16", 9.0 / 16.0)]
    let full = CGRect(x: 0, y: 0, width: 1, height: 1)

    var orientedAspect: CGFloat {
        let w = st.rot % 2 == 1 ? baseSize.height : baseSize.width
        let h = st.rot % 2 == 1 ? baseSize.width : baseSize.height
        return w / max(h, 1)
    }

    func fitSize(_ s: CGSize, _ c: CGSize) -> CGSize {
        guard s.width > 0, s.height > 0 else { return c }
        let k = min(c.width / s.width, c.height / s.height)
        return CGSize(width: s.width * k, height: s.height * k)
    }

    func loadBase() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let big = Gallery.thumb(url, max: 1400), let cg = big.cgImage else { return }
            let ci = CIImage(cgImage: cg)
            let small = Gallery.thumb(url, max: 130)
            DispatchQueue.main.async {
                base = ci
                baseSize = CGSize(width: cg.width, height: cg.height)
                render()
                if let sm = small?.cgImage { makeThumbs(CIImage(cgImage: sm)) }
            }
        }
    }

    func makeThumbs(_ ci: CIImage) {
        DispatchQueue.global(qos: .utility).async {
            var out: [UIImage] = []
            for i in 0..<GalleryFX.filters.count {
                var s = GalEditState()
                s.filter = i
                if let u = GalleryFX.render(GalleryFX.make(ci, s, crop: false)) { out.append(u) }
            }
            DispatchQueue.main.async { thumbs = out }
        }
    }

    func render() {
        guard let b = base else { return }
        token += 1
        let t = token
        let s = st
        let cropOn = tab != 0
        DispatchQueue.global(qos: .userInitiated).async {
            let ui = GalleryFX.render(GalleryFX.make(b, s, crop: cropOn))
            DispatchQueue.main.async {
                if t == token { preview = ui }
            }
        }
    }

    func setAspect(_ i: Int) {
        lockIdx = i
        let a = aspects[i].1
        if a <= 0 { return }
        let ia = orientedAspect
        var w: CGFloat = 1
        var h: CGFloat = 1
        if ia > a { w = a / ia } else { h = ia / a }
        st.crop = CGRect(x: (1 - w) / 2, y: (1 - h) / 2, width: w, height: h)
    }

    func rotate(_ d: Int) {
        st.rot = (st.rot + d + 4) % 4
        st.crop = full
        lockIdx = 0
    }

    func autoFix() {
        st.bright = 0.03
        st.contrast = 1.12
        st.sat = 1.15
        st.sharp = 0.4
    }

    func save(overwrite: Bool) {
        if saving { return }
        saving = true
        let s = st
        let src = url
        DispatchQueue.global(qos: .userInitiated).async {
            var ok = false
            if let big = Gallery.thumb(src, max: 6000), let cg = big.cgImage {
                let ci = GalleryFX.make(CIImage(cgImage: cg), s, crop: true)
                if let ui = GalleryFX.render(ci), let jpg = ui.jpegData(compressionQuality: 0.93) {
                    let canOverwrite = overwrite && ["jpg", "jpeg"].contains(src.pathExtension.lowercased())
                    if canOverwrite {
                        ok = (try? jpg.write(to: src)) != nil
                    } else {
                        ok = Gallery.save(jpg) != nil
                    }
                }
            }
            Gallery.cache.removeAllObjects()
            DispatchQueue.main.async {
                saving = false
                if ok {
                    vm.version += 1
                    vm.reload()
                    vm.editing = nil
                    vm.say(overwrite ? "Saved" : "Saved as copy")
                } else {
                    vm.say("Could not save")
                }
            }
        }
    }

    var topBar: some View {
        HStack {
            Button { vm.editing = nil } label: {
                Image(systemName: "xmark").foregroundColor(.white).frame(width: 44, height: 44)
            }
            Spacer()
            Button { st = GalEditState(); lockIdx = 0 } label: {
                Text("Reset").font(.system(size: 14, weight: .medium)).foregroundColor(.white.opacity(0.8))
            }
            Spacer()
            Menu {
                Button { save(overwrite: false) } label: { Label("Save as copy", systemImage: "plus.square.on.square") }
                Button { save(overwrite: true) } label: { Label("Save (replace)", systemImage: "square.and.arrow.down") }
            } label: {
                Text("Save")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(Capsule().fill(T.accent))
            }
        }
        .padding(.horizontal, 12)
    }

    var canvas: some View {
        GeometryReader { g in
            ZStack {
                if let p = preview {
                    let fit = fitSize(p.size, g.size)
                    Image(uiImage: p)
                        .resizable()
                        .frame(width: fit.width, height: fit.height)
                        .position(x: g.size.width / 2, y: g.size.height / 2)
                    if tab == 0 {
                        GalCropOverlay(crop: $st.crop, imgAspect: orientedAspect, lock: aspects[lockIdx].1)
                            .frame(width: fit.width, height: fit.height)
                            .position(x: g.size.width / 2, y: g.size.height / 2)
                    }
                } else {
                    ProgressView().tint(.white).position(x: g.size.width / 2, y: g.size.height / 2)
                }
            }
        }
        .padding(10)
    }

    var tabsBar: some View {
        HStack(spacing: 8) {
            ForEach(0..<3, id: \.self) { i in
                Button { tab = i } label: {
                    HStack(spacing: 5) {
                        Image(systemName: ["crop", "slider.horizontal.3", "camera.filters"][i]).font(.system(size: 13))
                        Text(["Crop", "Adjust", "Filters"][i]).font(.system(size: 13, weight: .medium))
                    }
                    .foregroundColor(tab == i ? T.onAccent : .white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(Capsule().fill(tab == i ? T.accent : Color.white.opacity(0.12)))
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }

    func toolButton(_ icon: String, _ label: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 19))
                Text(label).font(.system(size: 11))
            }
            .foregroundColor(.white)
            .frame(width: 64)
        }
    }

    var cropPanel: some View {
        VStack(spacing: 12) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(0..<aspects.count, id: \.self) { i in
                        Button { setAspect(i) } label: {
                            Text(aspects[i].0)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(lockIdx == i ? T.onAccent : .white)
                                .padding(.horizontal, 14).padding(.vertical, 7)
                                .background(Capsule().fill(lockIdx == i ? T.accent : Color.white.opacity(0.12)))
                        }
                    }
                }
                .padding(.horizontal, 16)
            }
            HStack(spacing: 6) {
                toolButton("rotate.left", "Left") { rotate(-1) }
                toolButton("rotate.right", "Right") { rotate(1) }
                toolButton("arrow.left.and.right.righttriangle.left.righttriangle.right", "Flip") {
                    st.flip.toggle()
                    st.crop = full
                }
                toolButton("arrow.counterclockwise", "Reset crop") {
                    st.crop = full
                    lockIdx = 0
                }
            }
        }
        .frame(height: 130)
    }

    var adjustPanel: some View {
        ScrollView {
            VStack(spacing: 6) {
                HStack {
                    Button { autoFix() } label: {
                        Label("Auto enhance", systemImage: "wand.and.stars")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(T.onAccent)
                            .padding(.horizontal, 14).padding(.vertical, 7)
                            .background(Capsule().fill(T.accent))
                    }
                    Spacer()
                }
                GalAdjRow(title: "Brightness", value: $st.bright, range: -0.5...0.5, neutral: 0)
                GalAdjRow(title: "Contrast", value: $st.contrast, range: 0.5...1.5, neutral: 1)
                GalAdjRow(title: "Saturation", value: $st.sat, range: 0...2, neutral: 1)
                GalAdjRow(title: "Warmth", value: $st.warm, range: -1...1, neutral: 0)
                GalAdjRow(title: "Sharpness", value: $st.sharp, range: 0...2, neutral: 0)
                GalAdjRow(title: "Vignette", value: $st.vignette, range: 0...2, neutral: 0)
            }
            .padding(.horizontal, 16)
        }
        .frame(height: 220)
    }

    var filterPanel: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(0..<GalleryFX.filters.count, id: \.self) { i in
                    Button { st.filter = i } label: {
                        VStack(spacing: 5) {
                            if i < thumbs.count {
                                Image(uiImage: thumbs[i]).resizable().scaledToFill()
                                    .frame(width: 72, height: 72)
                                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            } else {
                                RoundedRectangle(cornerRadius: 12, style: .continuous).fill(T.card).frame(width: 72, height: 72)
                            }
                            Text(GalleryFX.filters[i].0)
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(st.filter == i ? T.accent : .white)
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
        }
        .frame(height: 130)
    }

    @ViewBuilder var panel: some View {
        switch tab {
        case 0: cropPanel
        case 1: adjustPanel
        default: filterPanel
        }
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                topBar
                canvas
                tabsBar
                panel
                Color.clear.frame(height: max(os.bottom, 12))
            }
            if saving {
                Color.black.opacity(0.5).ignoresSafeArea()
                ProgressView().tint(.white)
            }
        }
        .onAppear { loadBase() }
        .onChange(of: st) { _ in render() }
        .onChange(of: tab) { _ in render() }
    }
}
