import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreImage

// Camera.swift - Gallery storage, Camera (100x zoom, video, timer, grid) and Photos. Read CLAUDE.md before editing.

// MARK: - Gallery storage (shared by Camera + Photos)
enum Gallery {
    static var dir: URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let u = base.appendingPathComponent("Camera", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    @discardableResult
    static func save(_ data: Data) -> URL? {
        let name = "IMG_\(Int(Date().timeIntervalSince1970 * 1000)).jpg"
        let u = dir.appendingPathComponent(name)
        do {
            try data.write(to: u)
            return u
        } catch {
            return nil
        }
    }

    static func replace(_ url: URL, _ data: Data) {
        try? data.write(to: url, options: .atomic)
    }

    static func saveMovie(from url: URL) -> URL? {
        let name = "VID_\(Int(Date().timeIntervalSince1970 * 1000)).mov"
        let dest = dir.appendingPathComponent(name)
        do {
            try FileManager.default.copyItem(at: url, to: dest)
            return dest
        } catch {
            return nil
        }
    }

    static func list() -> [URL] {
        let keys: [URLResourceKey] = [.creationDateKey]
        let all = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys)) ?? []
        let media = all.filter { ["jpg", "mov"].contains($0.pathExtension.lowercased()) }
        return media.sorted { a, b in
            let da = (try? a.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            let db = (try? b.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            return da > db
        }
    }

    static func thumb(_ url: URL, max: CGFloat) -> UIImage? {
        if url.pathExtension.lowercased() == "mov" {
            let gen = AVAssetImageGenerator(asset: AVAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: max, height: max)
            if let cg = try? gen.copyCGImage(at: .zero, actualTime: nil) { return UIImage(cgImage: cg) }
            return nil
        }
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: max
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }
}

// MARK: - Upscaler (Core Image: denoise -> stepwise Lanczos -> sharpen). Not AI, but much better than a plain crop.
enum Upscaler {
    static let ctx = CIContext(options: nil)
    static let maxSide: CGFloat = 5600

    static func apply(_ name: String, _ img: CIImage, _ params: [String: Any]) -> CIImage {
        guard let f = CIFilter(name: name) else { return img }
        f.setValue(img, forKey: kCIInputImageKey)
        for (k, v) in params { f.setValue(v, forKey: k) }
        return f.outputImage ?? img
    }

    /// Returns the upscaled picture, or nil when nothing could be done (caller keeps the original).
    static func run(_ cg: CGImage, zoom: CGFloat, extra: CGFloat) -> CGImage? {
        let w = CGFloat(cg.width)
        let h = CGFloat(cg.height)
        let longSide = max(w, h)
        var factor = max(extra, 1.5)
        if longSide * factor > maxSide { factor = maxSide / longSide }
        if factor < 1.05 { return nil }
        var ci = CIImage(cgImage: cg)
        let noise = min(0.08, 0.012 + Double(zoom) * 0.0007)
        ci = apply("CINoiseReduction", ci, ["inputNoiseLevel": noise, "inputSharpness": 0.35])
        var done: CGFloat = 1
        var n = 0
        while done < factor - 0.001 && n < 6 {
            let step = min(CGFloat(2), factor / done)
            ci = apply("CILanczosScaleTransform", ci, ["inputScale": Double(step), "inputAspectRatio": 1.0])
            done *= step
            ci = apply("CIUnsharpMask", ci, ["inputRadius": 1.6, "inputIntensity": 0.45])
            n += 1
        }
        ci = apply("CISharpenLuminance", ci, ["inputSharpness": 0.4])
        var rect = ci.extent
        if rect.isInfinite || rect.isNull || rect.width < 1 {
            rect = CGRect(x: 0, y: 0, width: w * done, height: h * done)
        }
        return ctx.createCGImage(ci, from: rect.integral)
    }

    /// Edge energy of the centre of a small preview of the frame. Higher = sharper (less shake blur).
    static func sharpness(of data: Data, extra: CGFloat) -> Double {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil) else { return 0 }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 700
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return 0 }
        let w = cg.width
        let h = cg.height
        let ex = max(extra, 1)
        let cw = max(96, min(w, Int(CGFloat(w) / ex)))
        let ch = max(96, min(h, Int(CGFloat(h) / ex)))
        if cw < 8 || ch < 8 { return 0 }
        let rect = CGRect(x: (w - cw) / 2, y: (h - ch) / 2, width: cw, height: ch)
        guard let c = cg.cropping(to: rect) else { return 0 }
        var buf = [UInt8](repeating: 0, count: cw * ch)
        let ok: Bool = buf.withUnsafeMutableBytes { (p: UnsafeMutableRawBufferPointer) -> Bool in
            guard let g = CGContext(data: p.baseAddress, width: cw, height: ch, bitsPerComponent: 8,
                                    bytesPerRow: cw, space: CGColorSpaceCreateDeviceGray(),
                                    bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            g.draw(c, in: CGRect(x: 0, y: 0, width: cw, height: ch))
            return true
        }
        if !ok { return 0 }
        var sum = 0.0
        for y in 1..<(ch - 1) {
            for x in 1..<(cw - 1) {
                let i = y * cw + x
                let lap = 4 * Int(buf[i]) - Int(buf[i - 1]) - Int(buf[i + 1]) - Int(buf[i - cw]) - Int(buf[i + cw])
                sum += Double(lap * lap)
            }
        }
        return sum / Double((cw - 2) * (ch - 2))
    }
}

// MARK: - Camera (real AVFoundation: main lens only, up to 100x zoom, video, timer, grid)
final class CamModel: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate, AVCaptureFileOutputRecordingDelegate {
    let session = AVCaptureSession()
    let output = AVCapturePhotoOutput()
    let movie = AVCaptureMovieFileOutput()
    @Published var authorized = false
    @Published var back = true
    @Published var flashOn = false
    @Published var last: UIImage? = nil
    @Published var zoom: CGFloat = 1
    @Published var extraZoom: CGFloat = 1
    @Published var videoMode = false
    @Published var recording = false
    @Published var recSeconds = 0
    static let maxZoom: CGFloat = 100
    static let upscaleFrom: CGFloat = 5
    @Published var upscaleOn = UD.b("al_upscale", true) { didSet { UserDefaults.standard.set(upscaleOn, forKey: "al_upscale") } }
    @Published var upscaling = 0
    private var frames: [Data] = []
    private var expected = 0
    private var shotExtra: CGFloat = 1
    private var shotZoom: CGFloat = 1
    private var configured = false
    private var device: AVCaptureDevice?
    private var audioInput: AVCaptureDeviceInput?
    private var recTimer: Timer?

    func start() {
        AVCaptureDevice.requestAccess(for: .video) { ok in
            DispatchQueue.main.async { self.authorized = ok }
            guard ok else { return }
            DispatchQueue.global(qos: .userInitiated).async {
                self.configure()
                if !self.session.isRunning { self.session.startRunning() }
            }
        }
        if let u = Gallery.list().first {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }

    private func configure() {
        if configured { return }
        session.beginConfiguration()
        session.sessionPreset = .photo
        if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
           let inp = try? AVCaptureDeviceInput(device: dev), session.canAddInput(inp) {
            session.addInput(inp)
            device = dev
        }
        if session.canAddOutput(output) { session.addOutput(output) }
        output.maxPhotoQualityPrioritization = .quality
        session.commitConfiguration()
        configured = true
    }

    func stop() {
        if recording { movie.stopRecording() }
        DispatchQueue.global().async {
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    /// Hardware zoom on the main lens first, then digital zoom (crop) up to 100x.
    func setZoom(_ z: CGFloat) {
        let zz = min(max(z, 1), CamModel.maxZoom)
        zoom = zz
        guard let d = device else {
            extraZoom = zz
            return
        }
        let hw = max(1, min(zz, d.activeFormat.videoMaxZoomFactor))
        do {
            try d.lockForConfiguration()
            d.videoZoomFactor = hw
            d.unlockForConfiguration()
        } catch {}
        extraZoom = zz / hw
    }

    func flip() {
        if recording { return }
        back.toggle()
        let pos: AVCaptureDevice.Position = back ? .back : .front
        zoom = 1
        extraZoom = 1
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            for i in self.session.inputs { self.session.removeInput(i) }
            self.audioInput = nil
            if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: pos),
               let inp = try? AVCaptureDeviceInput(device: dev), self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
            if self.videoMode { self.applyStabilization() }
        }
    }

    /// Best video stabilization the current camera format supports (cinematic extended > cinematic > standard).
    func applyStabilization() {
        guard let c = movie.connection(with: .video), c.isVideoStabilizationSupported else { return }
        var best: AVCaptureVideoStabilizationMode = .auto
        if let f = device?.activeFormat {
            if f.isVideoStabilizationModeSupported(.cinematicExtended) {
                best = .cinematicExtended
            } else if f.isVideoStabilizationModeSupported(.cinematic) {
                best = .cinematic
            } else if f.isVideoStabilizationModeSupported(.standard) {
                best = .standard
            }
        }
        c.preferredVideoStabilizationMode = best
    }

    func setMode(video: Bool) {
        if recording { return }
        videoMode = video
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            if video {
                self.session.sessionPreset = .high
                if !self.session.outputs.contains(self.movie) && self.session.canAddOutput(self.movie) {
                    self.session.addOutput(self.movie)
                }
            } else {
                if self.session.outputs.contains(self.movie) { self.session.removeOutput(self.movie) }
                self.session.sessionPreset = .photo
            }
            self.session.commitConfiguration()
            if video { self.applyStabilization() }
        }
    }

    func toggleRecord() {
        if recording {
            movie.stopRecording()
            return
        }
        AVCaptureDevice.requestAccess(for: .audio) { ok in
            DispatchQueue.global().async {
                if ok && self.audioInput == nil,
                   let mic = AVCaptureDevice.default(for: .audio),
                   let inp = try? AVCaptureDeviceInput(device: mic) {
                    self.session.beginConfiguration()
                    if self.session.canAddInput(inp) {
                        self.session.addInput(inp)
                        self.audioInput = inp
                    }
                    self.session.commitConfiguration()
                }
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).mov")
                self.movie.startRecording(to: url, recordingDelegate: self)
            }
        }
    }

    func shoot() {
        if expected > 0 { return }
        let burst = (upscaleOn && back && zoom >= CamModel.upscaleFrom) ? 3 : 1
        frames = []
        expected = burst
        shotExtra = extraZoom
        shotZoom = zoom
        for _ in 0..<burst { takeOne(burst > 1) }
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    private func takeOne(_ fast: Bool) {
        let s = AVCapturePhotoSettings()
        if flashOn && back && !fast && output.supportedFlashModes.contains(.on) { s.flashMode = .on }
        s.photoQualityPrioritization = fast ? .balanced : .quality
        output.capturePhoto(with: s, delegate: self)
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let d: Data? = error == nil ? photo.fileDataRepresentation() : nil
        DispatchQueue.main.async { self.frameArrived(d) }
    }

    private func frameArrived(_ d: Data?) {
        if let d = d { frames.append(d) }
        expected -= 1
        if expected > 0 { return }
        expected = 0
        let fs = frames
        frames = []
        if fs.isEmpty { return }
        finish(fs, extra: shotExtra, zoom: shotZoom)
    }

    /// Picks the sharpest frame of the burst, crops the digital zoom, saves it at once, then upscales in the background.
    private func finish(_ fs: [Data], extra: CGFloat, zoom: CGFloat) {
        let wantUp = upscaleOn && zoom >= CamModel.upscaleFrom
        if wantUp { upscaling += 1 }
        DispatchQueue.global(qos: .userInitiated).async {
            autoreleasepool {
                var best = fs[0]
                if fs.count > 1 {
                    var bs = -1.0
                    for d in fs {
                        let sc = Upscaler.sharpness(of: d, extra: extra)
                        if sc > bs {
                            bs = sc
                            best = d
                        }
                    }
                }
                guard let img0 = UIImage(data: best) else {
                    DispatchQueue.main.async { if wantUp { self.upscaling = max(0, self.upscaling - 1) } }
                    return
                }
                var img = img0
                if extra > 1.01, let cg = img0.cgImage {
                    let w = CGFloat(cg.width) / extra
                    let h = CGFloat(cg.height) / extra
                    let rect = CGRect(x: (CGFloat(cg.width) - w) / 2, y: (CGFloat(cg.height) - h) / 2, width: w, height: h).integral
                    if let c = cg.cropping(to: rect) {
                        img = UIImage(cgImage: c, scale: 1, orientation: img0.imageOrientation)
                    }
                }
                var savedURL: URL? = nil
                if let jpg = img.jpegData(compressionQuality: 0.95) { savedURL = Gallery.save(jpg) }
                if !wantUp { UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil) }
                var thumb: UIImage? = nil
                if let u = savedURL { thumb = Gallery.thumb(u, max: 200) }
                let t1 = thumb
                DispatchQueue.main.async { if let t = t1 { self.last = t } }
                if !wantUp { return }
                var result = img
                if let cg = img.cgImage, let up = Upscaler.run(cg, zoom: zoom, extra: extra) {
                    result = UIImage(cgImage: up, scale: 1, orientation: img.imageOrientation)
                }
                if let u = savedURL, let jpg = result.jpegData(compressionQuality: 0.92) { Gallery.replace(u, jpg) }
                UIImageWriteToSavedPhotosAlbum(result, nil, nil, nil)
                var thumb2: UIImage? = nil
                if let u = savedURL { thumb2 = Gallery.thumb(u, max: 200) }
                let t2 = thumb2
                DispatchQueue.main.async {
                    if let t = t2 { self.last = t }
                    self.upscaling = max(0, self.upscaling - 1)
                }
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async {
            self.recording = true
            self.recSeconds = 0
            self.recTimer?.invalidate()
            self.recTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                self.recSeconds += 1
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async {
            self.recording = false
            self.recTimer?.invalidate()
            self.recTimer = nil
        }
        let saved = Gallery.saveMovie(from: outputFileURL)
        UISaveVideoAtPathToSavedPhotosAlbum(outputFileURL.path, nil, nil, nil)
        if let u = saved {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var pl: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

struct CamPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.pl.session = session
        v.pl.videoGravity = .resizeAspectFill
        return v
    }
    func updateUIView(_ v: PreviewView, context: Context) {}
}

struct GridLines: View {
    var body: some View {
        GeometryReader { g in
            Path { p in
                p.move(to: CGPoint(x: g.size.width / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width / 3, y: g.size.height))
                p.move(to: CGPoint(x: g.size.width * 2 / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width * 2 / 3, y: g.size.height))
                p.move(to: CGPoint(x: 0, y: g.size.height / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height / 3))
                p.move(to: CGPoint(x: 0, y: g.size.height * 2 / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height * 2 / 3))
            }
            .stroke(Color.white.opacity(0.35), lineWidth: 1)
        }
        .allowsHitTesting(false)
    }
}

struct CameraApp: View {
    @EnvironmentObject var os: OS
    @StateObject var cam = CamModel()
    @State var timerSec = 0
    @State var count = 0
    @State var grid = false
    @State var baseZoom: CGFloat = 1
    let zoomSteps: [CGFloat] = [1, 2, 5, 10, 30, 100]

    func zoomText(_ z: CGFloat) -> String {
        z < 10 ? String(format: "%.1fx", z) : String(format: "%.0fx", z)
    }

    func countdown(_ n: Int) {
        if n <= 0 {
            count = 0
            cam.shoot()
            return
        }
        count = n
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { countdown(n - 1) }
    }

    func shutter() {
        if cam.videoMode {
            cam.toggleRecord()
        } else if timerSec == 0 {
            cam.shoot()
        } else {
            countdown(timerSec)
        }
    }

    var topRow: some View {
        HStack {
            Button { cam.flashOn.toggle() } label: {
                Image(systemName: cam.flashOn ? "bolt.fill" : "bolt.slash.fill")
                    .foregroundColor(cam.flashOn ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Button { grid.toggle() } label: {
                Image(systemName: "grid")
                    .foregroundColor(grid ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Spacer()
            if cam.recording {
                Text(String(format: "%02d:%02d", cam.recSeconds / 60, cam.recSeconds % 60))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Capsule().fill(Color.red))
            } else {
                Text(zoomText(cam.zoom))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .background(Capsule().fill(T.accent))
            }
            Spacer()
            Button { timerSec = timerSec == 0 ? 3 : (timerSec == 3 ? 10 : 0) } label: {
                ZStack {
                    Image(systemName: "timer").foregroundColor(timerSec == 0 ? .white : T.accent)
                    if timerSec > 0 {
                        Text("\(timerSec)")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(T.accent)
                            .offset(x: 12, y: -10)
                    }
                }
                .frame(width: 40, height: 40)
            }
            Button { cam.upscaleOn.toggle() } label: {
                Image(systemName: "wand.and.stars")
                    .foregroundColor(cam.upscaleOn ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, os.padTop - 8)
    }

    var upscalePill: some View {
        VStack {
            HStack(spacing: 8) {
                ProgressView().tint(.white)
                Text("Upscaling…").font(.system(size: 13, weight: .medium)).foregroundColor(.white)
            }
            .padding(.horizontal, 14).padding(.vertical, 8)
            .background(Capsule().fill(Color.black.opacity(0.55)))
            .padding(.top, 12)
            Spacer()
        }
        .allowsHitTesting(false)
    }

    var preview: some View {
        ZStack {
            Color(white: 0.1)
            if cam.authorized {
                CamPreview(session: cam.session).scaleEffect(cam.extraZoom)
            } else {
                Text("Allow camera access in iOS Settings")
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding()
            }
            if grid { GridLines() }
            if cam.upscaling > 0 { upscalePill }
            if count > 0 {
                Text("\(count)").font(.system(size: 90, weight: .bold)).foregroundColor(.white)
            }
        }
        .aspectRatio(3.0 / 4.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 10)
        .padding(.top, 8)
        .gesture(
            MagnificationGesture()
                .onChanged { v in cam.setZoom(baseZoom * v) }
                .onEnded { _ in baseZoom = cam.zoom }
        )
    }

    var zoomRow: some View {
        HStack(spacing: 8) {
            ForEach(0..<zoomSteps.count, id: \.self) { i in
                Button {
                    cam.setZoom(zoomSteps[i])
                    baseZoom = zoomSteps[i]
                } label: {
                    Text(zoomText(zoomSteps[i]))
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(abs(cam.zoom - zoomSteps[i]) < 0.05 ? T.onAccent : .white)
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(Capsule().fill(abs(cam.zoom - zoomSteps[i]) < 0.05 ? T.accent : Color.white.opacity(0.12)))
                }
            }
        }
        .padding(.top, 10)
    }

    var modeRow: some View {
        HStack(spacing: 10) {
            Button { cam.setMode(video: false) } label: {
                Text("Photo")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? .white : T.onAccent)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? Color.white.opacity(0.12) : T.accent))
            }
            Button { cam.setMode(video: true) } label: {
                Text("Video")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(cam.videoMode ? T.onAccent : .white)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(Capsule().fill(cam.videoMode ? T.accent : Color.white.opacity(0.12)))
            }
        }
        .padding(.bottom, 14)
    }

    var bottomRow: some View {
        HStack {
            Button {
                if let p = appFor("photos") { os.launch(p) }
            } label: {
                if let img = cam.last {
                    Image(uiImage: img).resizable().scaledToFill()
                        .frame(width: 54, height: 54).clipShape(Circle())
                } else {
                    Circle().fill(T.card).frame(width: 54, height: 54)
                }
            }
            Spacer()
            Button { shutter() } label: {
                ZStack {
                    Circle().stroke(Color.white, lineWidth: 4).frame(width: 78, height: 78)
                    if cam.videoMode {
                        RoundedRectangle(cornerRadius: cam.recording ? 10 : 33, style: .continuous)
                            .fill(Color.red)
                            .frame(width: cam.recording ? 34 : 66, height: cam.recording ? 34 : 66)
                    } else {
                        Circle().fill(Color.white).frame(width: 64, height: 64)
                    }
                }
            }
            Spacer()
            Button { cam.flip() } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .foregroundColor(.white)
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(T.card))
            }
        }
        .padding(.horizontal, 36)
        .padding(.bottom, 40)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                topRow
                preview
                zoomRow
                Spacer()
                modeRow
                bottomRow
            }
        }
        .onAppear { cam.start() }
        .onDisappear { cam.stop() }
    }
}

// MARK: - Photos
struct Thumb: View {
    let url: URL
    let maxSize: CGFloat
    var fill = true
    @State var img: UIImage? = nil

    var body: some View {
        Group {
            if let i = img {
                if fill {
                    Image(uiImage: i).resizable().scaledToFill()
                } else {
                    Image(uiImage: i).resizable().scaledToFit()
                }
            } else {
                T.card
            }
        }
        .onAppear {
            DispatchQueue.global().async {
                let t = Gallery.thumb(url, max: maxSize)
                DispatchQueue.main.async { img = t }
            }
        }
    }
}

struct VideoView: View {
    @State var player: AVPlayer
    init(url: URL) { _player = State(initialValue: AVPlayer(url: url)) }
    var body: some View {
        VideoPlayer(player: player)
            .onAppear { player.play() }
            .onDisappear { player.pause() }
    }
}

struct PhotosApp: View {
    @EnvironmentObject var os: OS
    @State var files: [URL] = []
    @State var sel: URL? = nil
    let cols = Array(repeating: GridItem(.flexible(), spacing: 3), count: 3)

    func isVideo(_ u: URL) -> Bool { u.pathExtension.lowercased() == "mov" }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Title(text: "Photos")
                if files.isEmpty {
                    Spacer()
                    Text("No photos yet. Take one with the Camera.")
                        .foregroundColor(.white.opacity(0.6))
                    Spacer()
                } else {
                    ScrollView {
                        LazyVGrid(columns: cols, spacing: 3) {
                            ForEach(files, id: \.self) { u in
                                Button { sel = u } label: {
                                    Color.clear
                                        .aspectRatio(1, contentMode: .fit)
                                        .overlay(Thumb(url: u, maxSize: 300))
                                        .overlay(
                                            Image(systemName: "play.circle.fill")
                                                .font(.system(size: 26))
                                                .foregroundColor(.white)
                                                .opacity(isVideo(u) ? 1 : 0)
                                        )
                                        .clipped()
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            if let s = sel {
                ZStack(alignment: .top) {
                    Color.black.ignoresSafeArea()
                    if isVideo(s) {
                        VideoView(url: s)
                    } else {
                        Thumb(url: s, maxSize: 1600, fill: false)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                    HStack {
                        Button { sel = nil } label: {
                            Image(systemName: "chevron.left").foregroundColor(.white)
                                .frame(width: 44, height: 44)
                        }
                        Spacer()
                        Button {
                            try? FileManager.default.removeItem(at: s)
                            sel = nil
                            files = Gallery.list()
                        } label: {
                            Image(systemName: "trash").foregroundColor(.white)
                                .frame(width: 44, height: 44)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                }
            }
        }
        .onAppear {
            files = Gallery.list()
            os.backHandlers["photos"] = {
                if sel != nil { sel = nil; return true }
                return false
            }
        }
    }
}
