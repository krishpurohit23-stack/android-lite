# Android Lite - guide for the next Claude agent (READ FIRST)

iPhone app (SwiftUI + a little UIKit) that imitates a Pixel / Android 16 phone. No Mac and no compiler in the chat,
so every change must be written defensively. The owner speaks Hinglish: reply in Hinglish, keep answers short.

## Delivery
- Source of truth: `Sources/*.swift` (15 small files). Build = GitHub Actions workflow `.github/workflows/build.yml` (unsigned IPA).
- The owner uploads `AndroidLite.zip` (contains Sources/, scripts/, CLAUDE.md) and `build.yml`. The workflow unzips it when its
  `ANDROID_LITE_BUILD` number is >= the number already in the repo.
- On every delivery: bump `Build.number` AND the `// ANDROID_LITE_BUILD=N` marker in `Sources/Version.swift`, run
  `python3 scripts/check.py Sources`, then re-zip with `zip -r AndroidLite.zip Sources scripts CLAUDE.md`.
- Camera: EN button (os.camEnhance) = background upscaling after a shot (never block the shutter). Home pages: os.pages/page/iconPage.
- Calls: iOS has no call-history API; OS.calls is our own log fed by CXCallObserver (CallWatcher in AppsComms.swift). Guided Access blocks tel: dialing (iOS limit).
- Web apps and the browser are preloaded at launch (OS.preloadWeb) so they open instantly.
- Real-ESRGAN: scripts/make_model.py converts the official x4plus weights to Core ML in the workflow (optional step, cached); the compiled RealESRGAN.mlmodelc is copied into the .app at packaging. If missing, Camera falls back to CamModel.ciEnhance. Space mode = zoom >= 100 = two 4x passes.
- Camera lens: CamModel.setLens (0 = ultra wide, 1 = main, 2 = telephoto; hasTele false on iPhones without it). Max displayed zoom 800 (hardware first, then digital crop; tele factor max 400 because it starts at 2x).
- Camera settings (gear): os.camEnhanceScale / os.camEnhanceTele (4...30x, CamModel.enhance: Real-ESRGAN 4x passes + resize, result max ~3072 px) and os.camSteady.
- Steady shot (Upscaler.swift `Steady`): zoom >= 5x or telephoto or night -> burst of 4-8 frames -> sharpest kept -> Vision translation align -> average (CIDissolveTransition) -> falls back to the single sharpest frame. Also exposure cap (activeMaxExposureDuration), stronger video stabilization, gyro wait.
- Night mode (moon in camera top row): 8-frame stack, ~1/8 s shutter cap, +0.7 EV. Brightness slider = exposure target bias -2...+2. Tap preview = tap to focus (focus ring, resets on subject area change).
- Photos app (Camera.swift bottom): GalleryVM (grid by day, All/Favorites/Videos/Trash, multi-select, import via PHPicker, share, info), GalleryViewer (swipe + pinch zoom UIScrollView), GalleryEditor (crop/rotate/flip/adjust/filters, save copy or replace). Trash folder Documents/Trash, 30 days.
- If the build fails the log prints "COMPILER ERRORS" - ask the owner for those lines, fix only them.

## File map
Theme (colors, UD helpers) | Models (AppInfo, app lists, wallpapers, settings categories) | OS (ALL state + logic) |
Entry (AppDelegate, HostVC, UIKit pan gestures) | NativeFX (zoom overlay + anchor view) | Shell (PhoneView root, status bar) |
Launcher (home, free icon placement, widgets, lock, drawer, recents) | Shade (notifications + quick settings) |
AppWindow (app router, AppHost animation styles, web apps) | AppsBasic (calculator, clock, calendar, notes) |
Settings | AppsComms (phone, messages) | Camera (gallery, camera, photos) | Upscaler (Real-ESRGAN Core ML tiles) | Browser (WKWebView, PiP, web apps).

## Rules that prevent compile errors
1. ViewBuilder (body, `@ViewBuilder`, closures of VStack/Group...): max 10 sibling views, only `let` and view expressions,
   NO assignments or function calls with side effects; put logic in normal funcs. Use `if/else`, `switch` for views only.
2. New state goes into `class OS` as `@Published var x = default { didSet { UserDefaults.standard.set(x, forKey: "al_x") } }`,
   loaded in `OS.init`, reset in `resetSettings()`. Do not add stored state to Views that must survive a theme rebuild.
3. Top-level names must be unique across ALL files (check.py enforces). Never use `private` for symbols used in other files.
4. Deployment target iOS 16. Use `.onChange(of:) { v in }`, no iOS 17 APIs (`@Observable`, `#Preview`, new onChange).
5. Add an app: AppInfo in `allApps` (Models.swift), `case` in `AppWindow.content`, view in its file. Web apps use id prefix `web:`.
6. Gestures have ONE brain in OS: `backEnded`, `bottomEnded`, `topOpen`, `goBack`, `home`, `launch`. UIKit (PanHandler) and SwiftUI
   fallbacks (EdgeStrip, NavZone, Zone) both call them; `allow(key)` ignores duplicates. Add new gestures there, not inline.
7. Animations: style 0 = Core Animation card (NativeFX) from the tapped icon rect; the app view is inserted only AFTER it lands.
   Closing = snapshot shrinks into `originRect`. Styles 1-9 are SwiftUI per-frame (`os.prog` 0...1 driven by `animateProg`).
   Find windows ONLY through `NativeFX.container()` (anchor view), never `UIApplication.shared.windows`.
8. Info.plist: camera/mic/photos texts in build.yml; background audio mode (PiP, background play) is added with PlistBuddy there.
9. Time/money: never claim a feature works on device unless it was run. Say "not compiled/tested" when true.

## Manual test checklist
Tap icon -> card zooms out of the icon; swipe up -> app shrinks into the icon; edge swipe = back; swipe down = notifications;
long press home -> move icons; camera: pinch to 100x, Video mode; Chrome: menu -> Picture in Picture / Add as web app.
