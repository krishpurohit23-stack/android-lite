// ANDROID_LITE_BUILD=21
import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Version.swift - bump Build.number AND the ANDROID_LITE_BUILD marker above on every delivery.

enum Build { static let number = 21 }
