import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import MediaPlayer
import UserNotifications

// Pixel.swift - Pixel / Android 16 polish: stretchy overscroll, press animation, volume panel, screenshot thumbnail,
// weather helpers, alarm notification delegate. Read CLAUDE.md and PIXEL_CHECKLIST.md before editing.

// MARK: - Stretch overscroll (Android 12+ "stretch" instead of bounce)
struct ScrollOffsets: Equatable {
    var minY: CGFloat = 0
    var maxY: CGFloat = 0
}

struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue = ScrollOffsets()
    static func reduce(value: inout ScrollOffsets, nextValue: () -> ScrollOffsets) { value = nextValue() }
}

struct StretchScroll<Content: View>: View {
    let content: Content
    @State var top: CGFloat = 0
    @State var bottom: CGFloat = 0

    init(@ViewBuilder _ c: () -> Content) { content = c() }

    var body: some View {
        GeometryReader { outer in
            ScrollView {
                content
                    .background(
                        GeometryReader { g in
                            Color.clear.preference(
                                key: ScrollOffsetKey.self,
                                value: ScrollOffsets(minY: g.frame(in: .named("stretchSpace")).minY,
                                                     maxY: g.frame(in: .named("stretchSpace")).maxY)
                            )
                        }
                    )
                    .scaleEffect(x: 1, y: 1 + (max(top, 0) + max(bottom, 0)) / 1400, anchor: top > 0 ? .top : .bottom)
            }
            .coordinateSpace(name: "stretchSpace")
            .onPreferenceChange(ScrollOffsetKey.self) { v in
                top = v.minY
                let h = v.maxY - v.minY
                bottom = h > outer.size.height ? max(0, outer.size.height - v.maxY) : 0
            }
        }
    }
}

// MARK: - Press animation (icons and tiles squish a little when touched)
struct PressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Volume panel (Pixel style). The hidden MPVolumeView also hides the iOS volume HUD.
final class VolumeWatcher: NSObject {
    static let shared = VolumeWatcher()
    private let vv = MPVolumeView(frame: CGRect(x: -200, y: -200, width: 100, height: 40))
    private var obs: NSKeyValueObservation?
    private var started = false
    var onChange: ((Float) -> Void)?

    func start(in container: UIView) {
        if started { return }
        started = true
        vv.alpha = 0.01
        container.addSubview(vv)
        let s = AVAudioSession.sharedInstance()
        try? s.setActive(true)
        obs = s.observe(\.outputVolume, options: [.new]) { [weak self] _, change in
            let v = change.newValue ?? 0
            DispatchQueue.main.async { self?.onChange?(v) }
        }
    }

    func current() -> Float { AVAudioSession.sharedInstance().outputVolume }

    func set(_ v: Float) {
        for sub in vv.subviews {
            if let sl = sub as? UISlider {
                sl.value = v
                sl.sendActions(for: .valueChanged)
            }
        }
    }
}

struct VolumePill: View {
    @EnvironmentObject var os: OS
    var body: some View {
        HStack {
            Spacer()
            VStack(spacing: 8) {
                Image(systemName: os.volume < 0.05 ? "speaker.slash.fill" : "speaker.wave.2.fill")
                    .font(.system(size: 16))
                    .foregroundColor(pInk)
                GeometryReader { g in
                    ZStack(alignment: .bottom) {
                        Capsule().fill(Color.black.opacity(0.12))
                        Capsule().fill(pSlate).frame(height: max(8, g.size.height * CGFloat(os.volume)))
                    }
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 0).onChanged { v in
                            let nv = Float(min(1, max(0, 1 - v.location.y / g.size.height)))
                            VolumeWatcher.shared.set(nv)
                            os.volumeChanged(nv)
                        }
                    )
                }
                .frame(width: 22, height: 180)
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 10)
            .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(pCard).overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.white.opacity(0.045), lineWidth: 1)))
            .padding(.trailing, 10)
        }
    }
}

// MARK: - Screenshot thumbnail (bottom left, like Pixel)
struct ScreenshotToast: View {
    @EnvironmentObject var os: OS
    var body: some View {
        VStack {
            Spacer()
            HStack {
                if let img = os.shot {
                    Button {
                        os.shot = nil
                        if let a = appFor("photos") { os.launch(a) }
                    } label: {
                        VStack(spacing: 6) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 84, height: 150)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            Text("Screenshot saved")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(pInk)
                        }
                        .padding(8)
                        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(pCard))
                    }
                    .buttonStyle(.plain)
                }
                Spacer()
            }
            .padding(.leading, 14)
            .padding(.bottom, 70)
        }
    }
}

// MARK: - Weather helpers (Open-Meteo, no account needed)
func weatherName(_ code: Int) -> String {
    switch code {
    case 0: return "Clear"
    case 1, 2: return "Partly cloudy"
    case 3: return "Cloudy"
    case 45, 48: return "Fog"
    case 51, 53, 55, 56, 57: return "Drizzle"
    case 61, 63, 65, 66, 67: return "Rain"
    case 71, 73, 75, 77: return "Snow"
    case 80, 81, 82: return "Showers"
    case 95, 96, 99: return "Thunderstorm"
    default: return "Weather"
    }
}

// MARK: - Alarms: show the notification even while the app is open
final class NotifDelegate: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}

let notifDelegate = NotifDelegate()
