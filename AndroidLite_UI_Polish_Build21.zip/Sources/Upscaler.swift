import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreML
import Vision
import CoreImage

// Upscaler.swift - Real-ESRGAN Core ML models (general photos = EN, text/line art = TX), the Enhancer that decides
// how to use them, and MoonFX (moon crop + synthetic crater detail). Read CLAUDE.md before editing.
// The .mlmodelc files are created and copied into the app by the GitHub workflow (scripts/make_model.py).
// If a model is missing, `available` is false and everything falls back to Core Image.

final class ESRGAN {
    static let shared = ESRGAN(name: "RealESRGAN")        // EN: general photos (x4plus)
    static let text = ESRGAN(name: "RealESRGANText")      // TX: text / logos / line art (x4plus anime 6B)
    private var model: VNCoreMLModel?
    private let ctx = CIContext()
    private let tile = 128
    private let pad = 8

    var available: Bool { model != nil }

    init(name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mlmodelc") else { return }
        let cfg = MLModelConfiguration()
        cfg.computeUnits = .all
        if let ml = try? MLModel(contentsOf: url, configuration: cfg),
           let vm = try? VNCoreMLModel(for: ml) {
            model = vm
        }
    }

    static func resize(_ cg: CGImage, _ w: Int, _ h: Int) -> CGImage? {
        guard let c = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        c.interpolationQuality = .high
        c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        return c.makeImage()
    }

    /// n x n 8-bit gray copy of an image (used for sharpness / detail / moon detection).
    static func gray(_ cg: CGImage, _ n: Int) -> [UInt8]? {
        var px = [UInt8](repeating: 0, count: n * n)
        let ok: Bool = px.withUnsafeMutableBytes { raw in
            guard let c = CGContext(data: raw.baseAddress, width: n, height: n, bitsPerComponent: 8, bytesPerRow: n,
                                    space: CGColorSpaceCreateDeviceGray(),
                                    bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            c.interpolationQuality = .high
            c.draw(cg, in: CGRect(x: 0, y: 0, width: n, height: n))
            return true
        }
        return ok ? px : nil
    }

    static func grayScale(_ px: [UInt8], from: Int, to: Int) -> [UInt8]? {
        var src = px
        var img: CGImage? = nil
        src.withUnsafeMutableBytes { raw in
            if let c = CGContext(data: raw.baseAddress, width: from, height: from, bitsPerComponent: 8, bytesPerRow: from,
                                 space: CGColorSpaceCreateDeviceGray(),
                                 bitmapInfo: CGImageAlphaInfo.none.rawValue) {
                img = c.makeImage()
            }
        }
        guard let cg = img else { return nil }
        return gray(cg, to)
    }

    /// 4x upscale. Keep the input small (about 640 px or less); the work is done in 128x128 tiles.
    func upscale4x(_ img: CGImage, progress: ((Double) -> Void)? = nil) -> CGImage? {
        guard let vm = model else { return nil }
        let W = img.width
        let H = img.height
        let outW = W * 4
        let outH = H * 4
        guard let canvas = CGContext(data: nil, width: outW, height: outH, bitsPerComponent: 8, bytesPerRow: 0,
                                     space: CGColorSpaceCreateDeviceRGB(),
                                     bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        let clamped = CIImage(cgImage: img).clampedToExtent()
        let step = tile - 2 * pad
        let cols = (W + step - 1) / step
        let rows = (H + step - 1) / step
        var done = 0
        for r in 0..<rows {
            for c in 0..<cols {
                let x0 = c * step
                let y0 = r * step
                let x1 = min(x0 + step, W)
                let y1 = min(y0 + step, H)
                let sx = x0 - pad
                let sy = y0 - pad
                let rect = CGRect(x: sx, y: H - (sy + tile), width: tile, height: tile)
                done += 1
                progress?(Double(done) / Double(rows * cols))
                guard let tcg = ctx.createCGImage(clamped.cropped(to: rect), from: rect) else { continue }
                let req = VNCoreMLRequest(model: vm)
                req.imageCropAndScaleOption = .scaleFill
                let handler = VNImageRequestHandler(cgImage: tcg, options: [:])
                do { try handler.perform([req]) } catch { continue }
                guard let obs = req.results?.first as? VNPixelBufferObservation else { continue }
                let oci = CIImage(cvPixelBuffer: obs.pixelBuffer)
                guard let ocg = ctx.createCGImage(oci, from: oci.extent) else { continue }
                let crop = CGRect(x: pad * 4, y: pad * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4)
                guard let inner = ocg.cropping(to: crop) else { continue }
                canvas.draw(inner, in: CGRect(x: x0 * 4, y: outH - y1 * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4))
            }
        }
        return canvas.makeImage()
    }
}

/// One place that decides how a picture is enhanced.
enum Enhancer {
    /// 1 = the picture is truly sharp, 0.03 = it only holds about 3% of its pixels worth of real detail (heavily zoomed).
    static func detailFraction(_ cg: CGImage) -> CGFloat {
        let n = 384
        guard let base = ESRGAN.gray(cg, n) else { return 1 }
        for k in [32, 16, 8, 4, 2] {
            let m = max(8, n / k)
            guard let small = ESRGAN.grayScale(base, from: n, to: m),
                  let back = ESRGAN.grayScale(small, from: m, to: n) else { continue }
            var err = 0.0
            for i in 0..<(n * n) {
                let d = Double(base[i]) - Double(back[i])
                err += d * d
            }
            err /= Double(n * n)
            if err < 25 { return 1 / CGFloat(k) }
        }
        return 1
    }

    /// factor 4...30. trueSide = real detail (long side in px); nil = measure it. text = use the TX model.
    static func enhance(_ img: UIImage, factor: CGFloat, trueSide: CGFloat?, text: Bool,
                        progress: ((Double) -> Void)? = nil) -> UIImage {
        guard let cg = img.cgImage else { return img }
        let f = min(max(factor, 4), 30)
        var engine: ESRGAN? = nil
        if text && ESRGAN.text.available {
            engine = ESRGAN.text
        } else if ESRGAN.shared.available {
            engine = ESRGAN.shared
        }
        let maxSide = CGFloat(max(cg.width, cg.height))
        let detail = min(trueSide ?? (maxSide * detailFraction(cg)), maxSide)
        guard let eng = engine else {
            return CamModel.ciEnhance(img, scale: f >= 8 ? 3 : 2, zoom: max(1, maxSide / max(detail, 1)))
        }
        let sharp = detail >= 1400
        let passes = (f <= 6 || sharp) ? 1 : 2
        let limit: CGFloat = passes == 1 ? (sharp ? 1024 : min(640, 4000 / f)) : 220
        let target = max(32, min(detail, limit))
        var cur = cg
        if target < maxSide - 1 {
            let k = target / maxSide
            let w = max(8, Int(CGFloat(cg.width) * k))
            let h = max(8, Int(CGFloat(cg.height) * k))
            if let r = ESRGAN.resize(cg, w, h) { cur = r }
        }
        let inW = CGFloat(cur.width)
        let inH = CGFloat(cur.height)
        let p1: ((Double) -> Void)? = passes == 1 ? progress : { p in progress?(p * 0.4) }
        guard var out = eng.upscale4x(cur, progress: p1) else {
            return CamModel.ciEnhance(img, scale: 2, zoom: 1)
        }
        if passes == 2, let second = eng.upscale4x(out, progress: { p in progress?(0.4 + p * 0.6) }) { out = second }
        var want: CGFloat = sharp ? 4 : f
        let longSide = max(inW, inH) * want
        if longSide > 6000 { want = want * 6000 / longSide }
        let have = CGFloat(out.width) / inW
        if abs(have - want) > 0.01 {
            let tw = max(8, Int((inW * want).rounded()))
            let th = max(8, Int((inH * want).rounded()))
            if let r = ESRGAN.resize(out, tw, th) { out = r }
        }
        var result = UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        if text { result = textPost(result) }
        return result
    }

    /// Cleaner, higher contrast edges for text.
    static func textPost(_ img: UIImage) -> UIImage {
        guard let cg = img.cgImage else { return img }
        var ci = CIImage(cgImage: cg)
        if let cc = CIFilter(name: "CIColorControls") {
            cc.setValue(ci, forKey: kCIInputImageKey)
            cc.setValue(1.2, forKey: kCIInputContrastKey)
            if let o = cc.outputImage { ci = o }
        }
        if let us = CIFilter(name: "CIUnsharpMask") {
            us.setValue(ci, forKey: kCIInputImageKey)
            us.setValue(1.0, forKey: kCIInputRadiusKey)
            us.setValue(0.8, forKey: kCIInputIntensityKey)
            if let o = us.outputImage { ci = o }
        }
        if let out = CamModel.ciContext.createCGImage(ci, from: ci.extent) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }
}

/// Moon helper: finds the moon, crops around it and adds synthetic crater / maria texture (fake detail on purpose).
enum MoonFX {
    static func findMoon(_ cg: CGImage) -> CGRect? {
        let n = 256
        guard let px = ESRGAN.gray(cg, n) else { return nil }
        var maxV: UInt8 = 0
        for v in px where v > maxV { maxV = v }
        if maxV < 90 { return nil }
        let thr = UInt8(Double(maxV) * 0.6)
        var sumX = 0.0
        var sumY = 0.0
        var count = 0.0
        for y in 0..<n {
            for x in 0..<n where px[y * n + x] >= thr {
                sumX += Double(x)
                sumY += Double(y)
                count += 1
            }
        }
        if count < 20 { return nil }
        let sx = CGFloat(cg.width) / CGFloat(n)
        let sy = CGFloat(cg.height) / CGFloat(n)
        let cx = CGFloat(sumX / count) * sx
        let cy = CGFloat(sumY / count) * sy
        let radius = CGFloat((count / Double.pi).squareRoot()) * max(sx, sy)
        let side = min(CGFloat(min(cg.width, cg.height)), max(64, radius * 3))
        var x = cx - side / 2
        var y = cy - side / 2
        x = max(0, min(x, CGFloat(cg.width) - side))
        y = max(0, min(y, CGFloat(cg.height) - side))
        return CGRect(x: x, y: y, width: side, height: side)
    }

    static func fakeDetail(_ img: UIImage) -> UIImage {
        guard let cg = img.cgImage else { return img }
        let ci = CIImage(cgImage: cg)
        let ext = ci.extent
        guard let noise = CIFilter(name: "CIRandomGenerator")?.outputImage else { return img }
        let n0 = noise.cropped(to: ext)
        let fine = n0.applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: max(1.0, ext.width / 260)]).cropped(to: ext)
        let coarse = n0.applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: max(2.0, ext.width / 70)]).cropped(to: ext)
        let diff = fine.applyingFilter("CIDifferenceBlendMode", parameters: [kCIInputBackgroundImageKey: coarse])
        let tex = diff.applyingFilter("CIColorControls", parameters: [
            kCIInputSaturationKey: 0.0, kCIInputContrastKey: 8.0, kCIInputBrightnessKey: -0.1
        ])
        let soft = tex.applyingFilter("CISoftLightBlendMode", parameters: [kCIInputBackgroundImageKey: ci])
        let r = min(ext.width, ext.height) / 3
        guard let rg = CIFilter(name: "CIRadialGradient") else { return img }
        rg.setValue(CIVector(x: ext.midX, y: ext.midY), forKey: "inputCenter")
        rg.setValue(r * 0.92, forKey: "inputRadius0")
        rg.setValue(r * 1.0, forKey: "inputRadius1")
        rg.setValue(CIColor(red: 1, green: 1, blue: 1), forKey: "inputColor0")
        rg.setValue(CIColor(red: 0, green: 0, blue: 0), forKey: "inputColor1")
        guard let mask = rg.outputImage?.cropped(to: ext) else { return img }
        let masked = soft.applyingFilter("CIBlendWithMask", parameters: [
            kCIInputBackgroundImageKey: ci, kCIInputMaskImageKey: mask
        ])
        let mixed = ci.applyingFilter("CIDissolveTransition", parameters: [
            kCIInputTargetImageKey: masked, kCIInputTimeKey: 0.55
        ])
        if let out = CamModel.ciContext.createCGImage(mixed, from: ext) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }
}
