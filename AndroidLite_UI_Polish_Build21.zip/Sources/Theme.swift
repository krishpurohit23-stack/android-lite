import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Theme.swift - Colors (accent palettes), UserDefaults helpers, small global helpers. Read CLAUDE.md before editing.

// MARK: - Theme (Material 3 Expressive / Pixel look)
enum T {
    static var palette = 0
    static let accents: [Color] = [
        Color(red: 0.72, green: 0.80, blue: 1.00),
        Color(red: 0.72, green: 0.88, blue: 0.72),
        Color(red: 1.00, green: 0.76, blue: 0.84),
        Color(red: 1.00, green: 0.82, blue: 0.64),
        Color(red: 0.84, green: 0.76, blue: 1.00),
        Color(red: 0.66, green: 0.88, blue: 0.88)
    ]
    static let onAccents: [Color] = [
        Color(red: 0.10, green: 0.16, blue: 0.34),
        Color(red: 0.10, green: 0.22, blue: 0.12),
        Color(red: 0.32, green: 0.10, blue: 0.20),
        Color(red: 0.30, green: 0.18, blue: 0.08),
        Color(red: 0.20, green: 0.12, blue: 0.38),
        Color(red: 0.08, green: 0.22, blue: 0.23)
    ]
    static let bg = Color(red: 0.055, green: 0.063, blue: 0.082)
    static let card = Color(red: 0.105, green: 0.118, blue: 0.15)
    static var dynAccent = Color(red: 0.72, green: 0.80, blue: 1.0)
    static var dynOn = Color(red: 0.10, green: 0.16, blue: 0.34)
    static var accent: Color { palette == 6 ? dynAccent : accents[min(max(palette, 0), 5)] }
    static var onAccent: Color { palette == 6 ? dynOn : onAccents[min(max(palette, 0), 5)] }
}

enum UD {
    static func b(_ k: String, _ d: Bool) -> Bool {
        UserDefaults.standard.object(forKey: k) == nil ? d : UserDefaults.standard.bool(forKey: k)
    }
    static func i(_ k: String, _ d: Int) -> Int {
        UserDefaults.standard.object(forKey: k) == nil ? d : UserDefaults.standard.integer(forKey: k)
    }
}

func rgb(_ r: Double, _ g: Double, _ b: Double) -> Color { Color(red: r, green: g, blue: b) }

func fmtDate(_ f: String) -> String {
    let d = DateFormatter()
    d.dateFormat = f
    return d.string(from: Date())
}
