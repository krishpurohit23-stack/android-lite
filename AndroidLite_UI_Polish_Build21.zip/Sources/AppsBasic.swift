import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// AppsBasic.swift - Calculator, Clock (timer/stopwatch/world), Calendar, Notes. Read CLAUDE.md before editing.

// MARK: - Calculator
struct CalcView: View {
    @State var disp = "0"
    @State var acc: Double? = nil
    @State var op: String? = nil
    @State var fresh = true
    let rows: [[String]] = [
        ["C", "±", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "−"],
        ["1", "2", "3", "+"],
        ["0", ".", "⌫", "="]
    ]

    func fmt(_ d: Double) -> String {
        if d == d.rounded() && abs(d) < 1e12 { return String(Int(d)) }
        return String(d)
    }

    func commit() {
        guard let v = Double(disp) else { return }
        if let a = acc, let o = op {
            var r = v
            switch o {
            case "+": r = a + v
            case "−": r = a - v
            case "×": r = a * v
            default: r = v == 0 ? 0 : a / v
            }
            acc = r
            disp = fmt(r)
        } else {
            acc = v
        }
    }

    func tap(_ k: String) {
        switch k {
        case "C": disp = "0"; acc = nil; op = nil; fresh = true
        case "±": if let v = Double(disp) { disp = fmt(-v) }
        case "%": if let v = Double(disp) { disp = fmt(v / 100) }
        case "+", "−", "×", "÷": commit(); op = k; fresh = true
        case "=": commit(); op = nil; fresh = true
        case ".":
            if fresh { disp = "0."; fresh = false }
            else if !disp.contains(".") { disp += "." }
        case "⌫":
            disp = String(disp.dropLast())
            if disp.isEmpty || disp == "-" { disp = "0"; fresh = true }
        default:
            if fresh { disp = k; fresh = false }
            else { disp = disp == "0" ? k : disp + k }
        }
    }

    func isOp(_ k: String) -> Bool { ["÷", "×", "−", "+", "="].contains(k) }

    var body: some View {
        VStack(spacing: 10) {
            Spacer()
            Text(disp)
                .font(.system(size: 68, weight: .light))
                .minimumScaleFactor(0.4)
                .lineLimit(1)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.horizontal, 24)
            ForEach(rows, id: \.self) { row in
                HStack(spacing: 10) {
                    ForEach(row, id: \.self) { k in
                        Button { tap(k) } label: {
                            Text(k)
                                .font(.system(size: 26))
                                .frame(maxWidth: .infinity, minHeight: 66)
                                .foregroundColor(isOp(k) ? T.onAccent : .white)
                                .background(RoundedRectangle(cornerRadius: 33, style: .continuous)
                                    .fill(isOp(k) ? T.accent : T.card))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
            }
        }
    }
}

// MARK: - Clock (clock / timer / stopwatch)
struct ClockApp: View {
    @State var tab = 0
    let names = ["Clock", "Timer", "Stopwatch", "World", "Alarm"]

    var body: some View {
        VStack(spacing: 16) {
            Title(text: "Clock")
            HStack(spacing: 8) {
                ForEach(0..<5) { i in
                    Button { tab = i } label: {
                        Text(names[i])
                            .font(.system(size: 14, weight: .medium))
                            .padding(.horizontal, 10).padding(.vertical, 9)
                            .foregroundColor(tab == i ? T.onAccent : .white)
                            .background(Capsule().fill(tab == i ? T.accent : T.card))
                    }
                }
            }
            if tab == 0 {
                VStack(spacing: 8) {
                    Text(Date(), style: .time).font(.system(size: 64, weight: .light)).foregroundColor(.white)
                    Text(TimeZone.current.identifier).foregroundColor(.white.opacity(0.6))
                }
                .padding(.top, 30)
            } else if tab == 1 {
                TimerView()
            } else if tab == 2 {
                StopwatchView()
            } else if tab == 3 {
                WorldClock()
            } else {
                AlarmTab()
            }
            Spacer()
        }
    }
}

struct WorldClock: View {
    let cities: [(String, String)] = [
        ("New York", "America/New_York"),
        ("London", "Europe/London"),
        ("Dubai", "Asia/Dubai"),
        ("Delhi", "Asia/Kolkata"),
        ("Tokyo", "Asia/Tokyo"),
        ("Sydney", "Australia/Sydney")
    ]

    func time(_ id: String) -> String {
        let f = DateFormatter()
        f.timeZone = TimeZone(identifier: id)
        f.dateFormat = "h:mm a"
        return f.string(from: Date())
    }

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            VStack(spacing: 0) {
                ForEach(0..<cities.count, id: \.self) { i in
                    HStack {
                        Text(cities[i].0).foregroundColor(.white)
                        Spacer()
                        Text(time(cities[i].1))
                            .font(.system(size: 22, weight: .light))
                            .foregroundColor(T.accent)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                }
            }
        }
    }
}

struct AlarmTab: View {
    @EnvironmentObject var os: OS
    @State var newTime = Date()

    func fmt(_ a: AlarmRec) -> String {
        String(format: "%d:%02d", ((a.hour + 11) % 12) + 1, a.minute) + (a.hour < 12 ? " AM" : " PM")
    }

    func row(_ a: AlarmRec) -> some View {
        HStack(spacing: 12) {
            Text(fmt(a)).font(.system(size: 30, weight: .light)).foregroundColor(.white)
            Spacer()
            Toggle("", isOn: Binding(get: { a.on }, set: { os.setAlarm(a.id, on: $0) }))
                .labelsHidden()
                .toggleStyle(SwitchToggleStyle(tint: T.accent))
            Button { os.removeAlarm(a.id) } label: {
                Image(systemName: "trash").foregroundColor(Color.red.opacity(0.9))
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(T.card))
        .padding(.horizontal, 16)
    }

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                DatePicker("", selection: $newTime, displayedComponents: .hourAndMinute)
                    .labelsHidden()
                    .colorScheme(.dark)
                Spacer()
                Button {
                    let c = Calendar.current.dateComponents([.hour, .minute], from: newTime)
                    os.addAlarm(hour: c.hour ?? 7, minute: c.minute ?? 0, label: "")
                } label: {
                    Text("Add alarm")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(T.onAccent)
                        .padding(.horizontal, 18).padding(.vertical, 10)
                        .background(Capsule().fill(T.accent))
                }
            }
            .padding(.horizontal, 20)
            if os.alarms.isEmpty {
                Text("No alarms yet")
                    .foregroundColor(.white.opacity(0.6))
                    .padding(.top, 30)
            } else {
                StretchScroll {
                    VStack(spacing: 8) {
                        ForEach(os.alarms) { a in row(a) }
                    }
                }
            }
        }
        .padding(.top, 10)
        .onAppear { os.requestNotifPermission() }
    }
}

struct TimerView: View {
    @EnvironmentObject var os: OS
    @State var minutes = 1
    @State var remaining = 0
    @State var running = false
    let tick = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    func fmt(_ s: Int) -> String { String(format: "%02d:%02d", s / 60, s % 60) }

    var body: some View {
        VStack(spacing: 22) {
            Text(fmt(remaining > 0 ? remaining : minutes * 60))
                .font(.system(size: 72, weight: .light).monospacedDigit())
                .foregroundColor(.white)
            if !running && remaining == 0 {
                HStack(spacing: 20) {
                    Button { minutes = max(1, minutes - 1) } label: {
                        Image(systemName: "minus").foregroundColor(.white)
                            .frame(width: 48, height: 48).background(Circle().fill(T.card))
                    }
                    Text("\(minutes) min").foregroundColor(.white)
                    Button { minutes = min(180, minutes + 1) } label: {
                        Image(systemName: "plus").foregroundColor(.white)
                            .frame(width: 48, height: 48).background(Circle().fill(T.card))
                    }
                }
            }
            HStack(spacing: 14) {
                Button {
                    if remaining == 0 { remaining = minutes * 60 }
                    running.toggle()
                } label: {
                    Text(running ? "Pause" : (remaining > 0 ? "Resume" : "Start"))
                        .foregroundColor(T.onAccent)
                        .frame(width: 110, height: 52)
                        .background(Capsule().fill(T.accent))
                }
                if remaining > 0 {
                    Button { running = false; remaining = 0 } label: {
                        Text("Reset").foregroundColor(.white)
                            .frame(width: 110, height: 52)
                            .background(Capsule().fill(T.card))
                    }
                }
            }
        }
        .padding(.top, 24)
        .onReceive(tick) { _ in
            guard running else { return }
            remaining -= 1
            if remaining <= 0 {
                running = false
                remaining = 0
                os.post("clock", "Timer", "Time's up!")
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

struct StopwatchView: View {
    @State var running = false
    @State var base: TimeInterval = 0
    @State var started: Date? = nil

    func fmt(_ t: TimeInterval) -> String {
        let m = Int(t) / 60
        let s = Int(t) % 60
        let c = Int((t - floor(t)) * 100)
        return String(format: "%02d:%02d.%02d", m, s, c)
    }

    var body: some View {
        VStack(spacing: 24) {
            TimelineView(.periodic(from: .now, by: 0.05)) { ctx in
                let el = base + (started.map { ctx.date.timeIntervalSince($0) } ?? 0)
                Text(fmt(el))
                    .font(.system(size: 56, weight: .light).monospacedDigit())
                    .foregroundColor(T.accent)
            }
            HStack(spacing: 14) {
                Button {
                    if running {
                        if let s = started { base += Date().timeIntervalSince(s) }
                        started = nil
                    } else {
                        started = Date()
                    }
                    running.toggle()
                } label: {
                    Text(running ? "Pause" : "Start")
                        .foregroundColor(T.onAccent)
                        .frame(width: 110, height: 52)
                        .background(Capsule().fill(T.accent))
                }
                Button {
                    running = false; started = nil; base = 0
                } label: {
                    Text("Reset").foregroundColor(.white)
                        .frame(width: 110, height: 52)
                        .background(Capsule().fill(T.card))
                }
            }
        }
        .padding(.top, 30)
    }
}

// MARK: - Calendar (months + events)
struct CalendarApp: View {
    @EnvironmentObject var os: OS
    @State var monthOffset = 0
    @State var selected = Date()
    @State var newEvent = ""
    let cal = Calendar.current
    let cols = Array(repeating: GridItem(.flexible()), count: 7)

    func key(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: d)
    }

    var monthDate: Date { cal.date(byAdding: .month, value: monthOffset, to: Date()) ?? Date() }

    var body: some View {
        let first = cal.date(from: cal.dateComponents([.year, .month], from: monthDate)) ?? monthDate
        let days = cal.range(of: .day, in: .month, for: first)?.count ?? 30
        let off = cal.component(.weekday, from: first) - 1
        let letters = ["S", "M", "T", "W", "T", "F", "S"]
        VStack(spacing: 10) {
            HStack {
                Text({ () -> String in
                    let f = DateFormatter()
                    f.dateFormat = "MMMM yyyy"
                    return f.string(from: monthDate)
                }())
                    .font(.system(size: 26)).foregroundColor(.white)
                Spacer()
                Button { monthOffset -= 1 } label: {
                    Image(systemName: "chevron.left").foregroundColor(.white).frame(width: 40, height: 40)
                }
                Button { monthOffset += 1 } label: {
                    Image(systemName: "chevron.right").foregroundColor(.white).frame(width: 40, height: 40)
                }
            }
            .padding(.horizontal, 22)
            HStack {
                ForEach(0..<7) { i in
                    Text(letters[i])
                        .font(.system(size: 13))
                        .foregroundColor(.white.opacity(0.6))
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 12)
            LazyVGrid(columns: cols, spacing: 6) {
                ForEach(0..<(off + days), id: \.self) { i in
                    if i < off {
                        Color.clear.frame(height: 42)
                    } else {
                        let date = cal.date(byAdding: .day, value: i - off, to: first) ?? first
                        let isToday = cal.isDateInToday(date)
                        let isSel = cal.isDate(date, inSameDayAs: selected)
                        Button { selected = date } label: {
                            VStack(spacing: 2) {
                                Text("\(i - off + 1)")
                                    .foregroundColor(isToday ? T.onAccent : .white)
                                Circle()
                                    .fill((os.events[key(date)]?.isEmpty ?? true) ? Color.clear : (isToday ? T.onAccent : T.accent))
                                    .frame(width: 4, height: 4)
                            }
                            .frame(width: 42, height: 42)
                            .background(Circle().fill(isToday ? T.accent : Color.clear))
                            .overlay(Circle().stroke(isSel && !isToday ? T.accent : Color.clear, lineWidth: 1.5))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 12)
            Divider().background(Color.white.opacity(0.2))
            VStack(alignment: .leading, spacing: 8) {
                Text({ () -> String in
                    let f = DateFormatter()
                    f.dateFormat = "EEEE, MMM d"
                    return f.string(from: selected)
                }())
                    .font(.system(size: 16, weight: .medium)).foregroundColor(.white)
                ScrollView {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(Array((os.events[key(selected)] ?? []).enumerated()), id: \.offset) { pair in
                            Text(pair.element)
                                .foregroundColor(T.onAccent)
                                .padding(.horizontal, 14).padding(.vertical, 8)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(T.accent))
                        }
                    }
                }
                HStack {
                    TextField("Add event", text: $newEvent)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .frame(height: 46)
                        .background(Capsule().fill(T.card))
                    Button {
                        let t = newEvent.trimmingCharacters(in: .whitespaces)
                        if !t.isEmpty {
                            os.events[key(selected), default: []].append(t)
                            newEvent = ""
                        }
                    } label: {
                        Image(systemName: "plus").foregroundColor(T.onAccent)
                            .frame(width: 46, height: 46).background(Circle().fill(T.accent))
                    }
                }
            }
            .padding(.horizontal, 20)
        }
    }
}

// MARK: - Notes
struct NotesApp: View {
    @AppStorage("androidlite_note") private var note = ""
    var body: some View {
        VStack(spacing: 0) {
            Title(text: "Keep Notes")
            TextEditor(text: $note)
                .foregroundColor(.white)
                .padding(14)
                .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(T.card))
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
        }
    }
}
