import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreImage
import CoreMotion

// Camera.swift - Camera app: lenses (ultra wide / main / telephoto), zoom to 800x, video, timer, grid,
// steady shot (best of N frames), Real-ESRGAN enhance (EN) and Moon mode. Read CLAUDE.md before editing.
// The gallery (Photos app) lives in Photos.swift, the upscaler in Upscaler.swift.

final class CamModel: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate, AVCaptureFileOutputRecordingDelegate {
    let session = AVCaptureSession()
    let output = AVCapturePhotoOutput()
    let movie = AVCaptureMovieFileOutput()
    let hasUltra: Bool
    let hasTele: Bool
    @Published var authorized = false
    @Published var back = true
    @Published var flashOn = false
    @Published var last: UIImage? = nil
    @Published var zoom: CGFloat = 1
    @Published var extraZoom: CGFloat = 1
    @Published var videoMode = false
    @Published var moon = false
    @Published var recording = false
    @Published var recSeconds = 0
    @Published var lens = 1            // 0 ultra wide, 1 main, 2 telephoto
    @Published var pending = 0
    @Published var burstText = ""
    @Published var night = false
    @Published var nightSec = 5
    @Published var nightActive = false
    static let maxZoom: CGFloat = 800
    static let ciContext = CIContext()
    var enhanceOn = true
    var factor: CGFloat = 4
    var steadyN = 3
    var minZoom: CGFloat = 3
    private var configured = false
    private var device: AVCaptureDevice?
    private var audioInput: AVCaptureDeviceInput?
    private var recTimer: Timer?
    private let motion = CMMotionManager()
    private let enhanceQueue = DispatchQueue(label: "androidlite.enhance", qos: .utility)
    private var frames: [UIImage] = []
    private var target = 1
    private var capturing = false
    private var shotZoom: CGFloat = 1
    private var shotEx: CGFloat = 1
    private var shotMoon = false
    private var shotSensor: CGFloat = 0
    private var nightAcc: [Float] = []
    private var nightW = 0
    private var nightH = 0
    private var nightCount = 0
    private var nightEnd = Date()
    private var nightOrient: UIImage.Orientation = .right
    private var nightTimer: Timer?

    override init() {
        hasUltra = AVCaptureDevice.default(.builtInUltraWideCamera, for: .video, position: .back) != nil
        hasTele = AVCaptureDevice.default(.builtInTelephotoCamera, for: .video, position: .back) != nil
        super.init()
    }

    func deviceType(_ l: Int) -> AVCaptureDevice.DeviceType {
        l == 0 ? .builtInUltraWideCamera : (l == 2 ? .builtInTelephotoCamera : .builtInWideAngleCamera)
    }

    func start() {
        if motion.isGyroAvailable {
            motion.gyroUpdateInterval = 0.05
            motion.startGyroUpdates()
        }
        AVCaptureDevice.requestAccess(for: .video) { ok in
            DispatchQueue.main.async { self.authorized = ok }
            guard ok else { return }
            DispatchQueue.global(qos: .userInitiated).async {
                self.configure()
                if !self.session.isRunning { self.session.startRunning() }
            }
        }
        if let u = Gallery.list().first {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }

    private func configure() {
        if configured { return }
        session.beginConfiguration()
        session.sessionPreset = .photo
        if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
           let inp = try? AVCaptureDeviceInput(device: dev), session.canAddInput(inp) {
            session.addInput(inp)
            device = dev
        }
        if session.canAddOutput(output) { session.addOutput(output) }
        output.maxPhotoQualityPrioritization = .quality
        session.commitConfiguration()
        configured = true
    }

    func stop() {
        motion.stopGyroUpdates()
        if recording { movie.stopRecording() }
        DispatchQueue.global().async {
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    /// Hardware zoom of the current lens first, then digital zoom (crop) up to 800x.
    func setZoom(_ z: CGFloat) {
        let zz = min(max(z, 1), CamModel.maxZoom)
        zoom = zz
        guard let d = device else {
            extraZoom = zz
            return
        }
        let hw = max(1, min(zz, d.activeFormat.videoMaxZoomFactor))
        do {
            try d.lockForConfiguration()
            d.videoZoomFactor = hw
            d.unlockForConfiguration()
        } catch {}
        extraZoom = zz / hw
    }

    /// 0 = ultra wide, 1 = main, 2 = telephoto. Works for photo and video.
    func setLens(_ l: Int) {
        if recording || !back || l == lens { return }
        let type = deviceType(l)
        guard AVCaptureDevice.default(type, for: .video, position: .back) != nil else { return }
        lens = l
        zoom = 1
        extraZoom = 1
        DispatchQueue.global().async {
            guard let dev = AVCaptureDevice.default(type, for: .video, position: .back),
                  let inp = try? AVCaptureDeviceInput(device: dev) else { return }
            self.session.beginConfiguration()
            let current = self.session.inputs
            for i in current {
                if let di = i as? AVCaptureDeviceInput, di.device.hasMediaType(.video) {
                    self.session.removeInput(di)
                }
            }
            if self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
            if self.moon { DispatchQueue.main.async { self.applyMoonSettings() } }
        }
    }

    func flip() {
        if recording { return }
        back.toggle()
        let pos: AVCaptureDevice.Position = back ? .back : .front
        zoom = 1
        extraZoom = 1
        lens = 1
        moon = false
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            for i in self.session.inputs { self.session.removeInput(i) }
            self.audioInput = nil
            if let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: pos),
               let inp = try? AVCaptureDeviceInput(device: dev), self.session.canAddInput(inp) {
                self.session.addInput(inp)
                self.device = dev
            }
            self.session.commitConfiguration()
        }
    }

    func setMode(video: Bool) {
        if recording { return }
        videoMode = video
        DispatchQueue.global().async {
            self.session.beginConfiguration()
            if video {
                self.session.sessionPreset = .high
                if !self.session.outputs.contains(self.movie) && self.session.canAddOutput(self.movie) {
                    self.session.addOutput(self.movie)
                }
                if let c = self.movie.connection(with: .video), c.isVideoStabilizationSupported {
                    c.preferredVideoStabilizationMode = .cinematicExtended
                }
            } else {
                if self.session.outputs.contains(self.movie) { self.session.removeOutput(self.movie) }
                self.session.sessionPreset = .photo
            }
            self.session.commitConfiguration()
        }
    }

    // MARK: Moon mode
    func setMoon(_ on: Bool) {
        if recording || !back || nightActive { return }
        moon = on
        night = false
        if on {
            setMode(video: false)
            if lens == 0 { setLens(hasTele ? 2 : 1) }
            applyMoonSettings()
            setZoom(20)
        } else {
            resetMoonSettings()
            setZoom(1)
        }
    }

    func applyMoonSettings() {
        guard let d = device else { return }
        do {
            try d.lockForConfiguration()
            if d.isFocusModeSupported(.locked) { d.setFocusModeLocked(lensPosition: 1.0, completionHandler: nil) }
            d.setExposureTargetBias(max(d.minExposureTargetBias, -2.5), completionHandler: nil)
            d.unlockForConfiguration()
        } catch {}
    }

    func resetMoonSettings() {
        guard let d = device else { return }
        do {
            try d.lockForConfiguration()
            if d.isFocusModeSupported(.continuousAutoFocus) { d.focusMode = .continuousAutoFocus }
            d.setExposureTargetBias(0, completionHandler: nil)
            d.unlockForConfiguration()
        } catch {}
    }

    // MARK: Night mode (manual seconds): many frames for N seconds, averaged, then brightened
    func setNight(_ on: Bool) {
        if recording || nightActive { return }
        night = on
        if on { moon = false }
        if on { setMode(video: false) }
        guard let d = device else { return }
        do {
            try d.lockForConfiguration()
            d.setExposureTargetBias(on ? min(d.maxExposureTargetBias, 1.5) : 0, completionHandler: nil)
            d.unlockForConfiguration()
        } catch {}
    }

    func toggleNight() {
        if nightActive {
            finishNight()
            return
        }
        nightActive = true
        nightAcc = []
        nightCount = 0
        nightEnd = Date().addingTimeInterval(Double(nightSec))
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        nightTimer?.invalidate()
        nightTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            let left = max(0, Int(self.nightEnd.timeIntervalSinceNow.rounded(.up)))
            self.burstText = "Night: \(left)s left - keep still"
        }
        burstText = "Night: \(nightSec)s left - keep still"
        capture()
    }

    private func handleNight(_ photo: AVCapturePhoto) {
        if let data = photo.fileDataRepresentation(), let ui = UIImage(data: data), let cg = ui.cgImage {
            nightOrient = ui.imageOrientation
            accumulate(cg)
        }
        if nightActive && Date() < nightEnd {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) {
                if self.nightActive { self.capture() }
            }
        } else {
            finishNight()
        }
    }

    private func accumulate(_ cg: CGImage) {
        let w = max(2, cg.width / 2)
        let h = max(2, cg.height / 2)
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let ok: Bool = px.withUnsafeMutableBytes { raw in
            guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.interpolationQuality = .medium
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        if !ok { return }
        if nightAcc.count != w * h * 4 {
            nightAcc = [Float](repeating: 0, count: w * h * 4)
            nightW = w
            nightH = h
            nightCount = 0
        }
        for i in 0..<(w * h * 4) { nightAcc[i] += Float(px[i]) }
        nightCount += 1
    }

    private func finishNight() {
        if !nightActive { return }
        nightActive = false
        nightTimer?.invalidate()
        nightTimer = nil
        let n = max(1, nightCount)
        let w = nightW
        let h = nightH
        let acc = nightAcc
        let sec = nightSec
        let orient = nightOrient
        nightAcc = []
        burstText = ""
        if w == 0 || h == 0 || acc.isEmpty { return }
        pending += 1
        enhanceQueue.async {
            let k = Float(1.6 * min(4.0, 1.0 + log2(Double(max(1, sec))) * 0.45))
            let norm = 1.0 - exp(-k)
            var out = [UInt8](repeating: 255, count: w * h * 4)
            for i in 0..<(w * h * 4) {
                if i % 4 == 3 { continue }
                let avg = acc[i] / Float(n) / 255.0
                let v = (1.0 - exp(-avg * k)) / norm
                out[i] = UInt8(max(0, min(255, v * 255.0)))
            }
            let cgOut: CGImage? = out.withUnsafeMutableBytes { raw in
                guard let ctx = CGContext(data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                          space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
                return ctx.makeImage()
            }
            guard let cg = cgOut else {
                DispatchQueue.main.async { self.pending = max(0, self.pending - 1) }
                return
            }
            let stacked = UIImage(cgImage: cg, scale: 1, orientation: orient)
            let result = CamModel.ciEnhance(stacked, scale: 2, zoom: 1)
            if let jpg = result.jpegData(compressionQuality: 0.95) { Gallery.save(jpg) }
            UIImageWriteToSavedPhotosAlbum(result, nil, nil, nil)
            DispatchQueue.main.async {
                self.pending = max(0, self.pending - 1)
                self.last = result
            }
        }
    }

    // MARK: Video
    func toggleRecord() {
        if recording {
            movie.stopRecording()
            return
        }
        AVCaptureDevice.requestAccess(for: .audio) { ok in
            DispatchQueue.global().async {
                if ok && self.audioInput == nil,
                   let mic = AVCaptureDevice.default(for: .audio),
                   let inp = try? AVCaptureDeviceInput(device: mic) {
                    self.session.beginConfiguration()
                    if self.session.canAddInput(inp) {
                        self.session.addInput(inp)
                        self.audioInput = inp
                    }
                    self.session.commitConfiguration()
                }
                let url = FileManager.default.temporaryDirectory
                    .appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).mov")
                self.movie.startRecording(to: url, recordingDelegate: self)
            }
        }
    }

    // MARK: Photo (shutter never waits for the upscaler)
    func shoot() {
        if capturing { return }
        capturing = true
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        frames = []
        shotZoom = zoom
        shotEx = extraZoom
        shotMoon = moon
        shotSensor = 0
        let heavy = zoom >= 5 || lens == 2 || moon
        if steadyN == 0 {
            target = 1
        } else if moon {
            target = max(steadyN, 5)
        } else if heavy {
            target = steadyN
        } else {
            target = 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) { self.capturing = false }
        waitSteady(tries: 0) { self.capture() }
    }

    /// Waits a moment for the hand to settle (gyro) so zoomed / telephoto shots are sharper.
    private func waitSteady(tries: Int, then go: @escaping () -> Void) {
        let heavy = zoom >= 5 || lens == 2 || moon
        let limit: Double = moon ? 0.05 : (heavy ? 0.1 : 0.4)
        let maxTries = moon ? 12 : (heavy ? 8 : 5)
        if motion.isGyroAvailable, tries < maxTries, let r = motion.gyroData?.rotationRate {
            let mag = sqrt(r.x * r.x + r.y * r.y + r.z * r.z)
            if mag > limit {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { self.waitSteady(tries: tries + 1, then: go) }
                return
            }
        }
        go()
    }

    private func capture() {
        let s = AVCapturePhotoSettings()
        if flashOn && back && output.supportedFlashModes.contains(.on) { s.flashMode = .on }
        s.photoQualityPrioritization = nightActive ? .speed : (target > 1 ? .balanced : .quality)
        output.capturePhoto(with: s, delegate: self)
    }

    static func sharpness(_ img: UIImage) -> Double {
        guard let cg = img.cgImage else { return 0 }
        let n = 160
        let cs = CGColorSpaceCreateDeviceGray()
        var px = [UInt8](repeating: 0, count: n * n)
        let ok: Bool = px.withUnsafeMutableBytes { raw in
            guard let ctx = CGContext(data: raw.baseAddress, width: n, height: n, bitsPerComponent: 8,
                                      bytesPerRow: n, space: cs, bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            ctx.interpolationQuality = .medium
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: n, height: n))
            return true
        }
        if !ok { return 0 }
        var sum = 0.0
        for y in 1..<(n - 1) {
            for x in 1..<(n - 1) {
                let c = Int(px[y * n + x])
                let l = Int(px[y * n + x - 1]) + Int(px[y * n + x + 1]) + Int(px[(y - 1) * n + x]) + Int(px[(y + 1) * n + x]) - 4 * c
                sum += Double(l * l)
            }
        }
        return sum / Double(n * n)
    }

    /// Basic Core Image enhancer (used when the Real-ESRGAN model is not in the app).
    static func ciEnhance(_ img: UIImage, scale: CGFloat, zoom: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        var ci = CIImage(cgImage: cg)
        if let nr = CIFilter(name: "CINoiseReduction") {
            nr.setValue(ci, forKey: kCIInputImageKey)
            nr.setValue(min(0.06, 0.01 + Double(zoom) / 2500.0), forKey: "inputNoiseLevel")
            nr.setValue(0.4, forKey: "inputSharpness")
            if let o = nr.outputImage { ci = o }
        }
        let maxSide = CGFloat(max(cg.width, cg.height))
        var remaining = min(scale, max(6000.0 / maxSide, 1.0))
        while remaining > 1.001 {
            let step = min(remaining, 2.0)
            if let lz = CIFilter(name: "CILanczosScaleTransform") {
                lz.setValue(ci, forKey: kCIInputImageKey)
                lz.setValue(step, forKey: kCIInputScaleKey)
                lz.setValue(1.0, forKey: kCIInputAspectRatioKey)
                if let o = lz.outputImage { ci = o }
            }
            if let us = CIFilter(name: "CIUnsharpMask") {
                us.setValue(ci, forKey: kCIInputImageKey)
                us.setValue(1.6, forKey: kCIInputRadiusKey)
                us.setValue(0.7, forKey: kCIInputIntensityKey)
                if let o = us.outputImage { ci = o }
            }
            remaining /= step
        }
        if let sh = CIFilter(name: "CISharpenLuminance") {
            sh.setValue(ci, forKey: kCIInputImageKey)
            sh.setValue(0.5 + Double(min(zoom, 100)) / 200.0, forKey: kCIInputSharpnessKey)
            if let o = sh.outputImage { ci = o }
        }
        if let out = CamModel.ciContext.createCGImage(ci, from: ci.extent) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }

    static func moonPost(_ img: UIImage) -> UIImage {
        guard let cg = img.cgImage else { return img }
        var ci = CIImage(cgImage: cg)
        if let cc = CIFilter(name: "CIColorControls") {
            cc.setValue(ci, forKey: kCIInputImageKey)
            cc.setValue(1.3, forKey: kCIInputContrastKey)
            cc.setValue(0.0, forKey: kCIInputBrightnessKey)
            cc.setValue(0.85, forKey: kCIInputSaturationKey)
            if let o = cc.outputImage { ci = o }
        }
        if let us = CIFilter(name: "CIUnsharpMask") {
            us.setValue(ci, forKey: kCIInputImageKey)
            us.setValue(2.5, forKey: kCIInputRadiusKey)
            us.setValue(1.1, forKey: kCIInputIntensityKey)
            if let o = us.outputImage { ci = o }
        }
        if let out = CamModel.ciContext.createCGImage(ci, from: ci.extent) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        return img
    }

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if nightActive {
            handleNight(photo)
            return
        }
        guard let data = photo.fileDataRepresentation(), var img = UIImage(data: data) else {
            capturing = false
            DispatchQueue.main.async { self.burstText = "" }
            return
        }
        if shotSensor == 0 { shotSensor = CGFloat(max(img.cgImage?.width ?? 0, img.cgImage?.height ?? 0)) }
        let ex = shotEx
        if ex > 1.01, let cg = img.cgImage {
            let w = CGFloat(cg.width) / ex
            let h = CGFloat(cg.height) / ex
            let rect = CGRect(x: (CGFloat(cg.width) - w) / 2, y: (CGFloat(cg.height) - h) / 2, width: w, height: h)
            if let c = cg.cropping(to: rect) {
                img = UIImage(cgImage: c, scale: 1, orientation: img.imageOrientation)
            }
        }
        frames.append(img)
        if frames.count < target {
            let n = frames.count
            let t = target
            DispatchQueue.main.async { self.burstText = "Capturing \(n)/\(t)" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { self.capture() }
            return
        }
        let shots = frames
        frames = []
        capturing = false
        DispatchQueue.main.async { self.burstText = "" }
        finish(shots)
    }

    /// Picks the sharpest frame, saves it at once, then (EN on) upscales it in the background and replaces the file.
    private func finish(_ shots: [UIImage]) {
        let z = shotZoom
        let sensor = shotSensor
        let isMoon = shotMoon
        let fct: CGFloat = isMoon ? 16 : factor
        let useEn = enhanceOn && (isMoon || z >= minZoom)
        DispatchQueue.global(qos: .userInitiated).async {
            var best = shots[0]
            if shots.count > 1 {
                var bestScore = -1.0
                for f in shots {
                    let sc = CamModel.sharpness(f)
                    if sc > bestScore {
                        bestScore = sc
                        best = f
                    }
                }
            }
            let url = Gallery.save(best.jpegData(compressionQuality: 0.95) ?? Data())
            if !useEn { UIImageWriteToSavedPhotosAlbum(best, nil, nil, nil) }
            DispatchQueue.main.async {
                self.last = best
                if useEn { self.pending += 1 }
            }
            if useEn {
                self.enhanceQueue.async {
                    let trueSide = sensor / max(z, 1)
                    var out = Enhancer.enhance(best, factor: fct, trueSide: trueSide)
                    if isMoon { out = CamModel.moonPost(out) }
                    if let jpg = out.jpegData(compressionQuality: 0.95), let u = url { try? jpg.write(to: u) }
                    UIImageWriteToSavedPhotosAlbum(out, nil, nil, nil)
                    DispatchQueue.main.async {
                        self.pending = max(0, self.pending - 1)
                        self.last = out
                    }
                }
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async {
            self.recording = true
            self.recSeconds = 0
            self.recTimer?.invalidate()
            self.recTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                self.recSeconds += 1
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async {
            self.recording = false
            self.recTimer?.invalidate()
            self.recTimer = nil
        }
        let saved = Gallery.saveMovie(from: outputFileURL)
        UISaveVideoAtPathToSavedPhotosAlbum(outputFileURL.path, nil, nil, nil)
        if let u = saved {
            DispatchQueue.global().async {
                let t = Gallery.thumb(u, max: 200)
                DispatchQueue.main.async { self.last = t }
            }
        }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var pl: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

struct CamPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.pl.session = session
        v.pl.videoGravity = .resizeAspectFill
        return v
    }
    func updateUIView(_ v: PreviewView, context: Context) {
        if let c = v.pl.connection, c.isVideoStabilizationSupported {
            c.preferredVideoStabilizationMode = .auto
        }
    }
}

struct GridLines: View {
    var body: some View {
        GeometryReader { g in
            Path { p in
                p.move(to: CGPoint(x: g.size.width / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width / 3, y: g.size.height))
                p.move(to: CGPoint(x: g.size.width * 2 / 3, y: 0))
                p.addLine(to: CGPoint(x: g.size.width * 2 / 3, y: g.size.height))
                p.move(to: CGPoint(x: 0, y: g.size.height / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height / 3))
                p.move(to: CGPoint(x: 0, y: g.size.height * 2 / 3))
                p.addLine(to: CGPoint(x: g.size.width, y: g.size.height * 2 / 3))
            }
            .stroke(Color.white.opacity(0.35), lineWidth: 1)
        }
        .allowsHitTesting(false)
    }
}

struct CameraSettingsView: View {
    @EnvironmentObject var os: OS
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Camera settings").font(.system(size: 22, weight: .medium))
                Spacer()
                Button("Done") { dismiss() }
            }
            .padding(18)
            ScrollView {
                VStack(spacing: 14) {
                    SCard("Enhance (EN)") {
                        SToggle(icon: "wand.and.stars", title: "Enhance photos", sub: "Same as the EN button", on: $os.camEnhance)
                        HStack {
                            Text("Enhance by").foregroundColor(.white)
                            Spacer()
                            Text("\(Int(os.camFactor))x").foregroundColor(T.accent)
                        }
                        .padding(.horizontal, 18)
                        Slider(value: $os.camFactor, in: 4...30, step: 1)
                            .accentColor(T.accent)
                            .padding(.horizontal, 18)
                        HStack {
                            Text("Only when zoom is at least").foregroundColor(.white)
                            Spacer()
                            Text("\(Int(os.camMinZoom))x").foregroundColor(T.accent)
                        }
                        .padding(.horizontal, 18)
                        Slider(value: $os.camMinZoom, in: 1...30, step: 1)
                            .accentColor(T.accent)
                            .padding(.horizontal, 18)
                        Text("4x is one Real-ESRGAN pass. Above 6x it runs twice (16x) and is resized to your number. Bigger numbers take longer in the background.")
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.6))
                            .padding(.horizontal, 18)
                            .padding(.bottom, 14)
                    }
                    SCard("Steady shot") {
                        ChipRow(items: ["Off", "3 frames", "5 frames"],
                                selected: os.camSteady == 0 ? 0 : (os.camSteady == 3 ? 1 : 2)) {
                            os.camSteady = [0, 3, 5][$0]
                        }
                        Text("For telephoto, zoom and Moon shots the camera takes several frames and keeps the sharpest one. It also waits for your hand to settle.")
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.6))
                            .padding(.horizontal, 18)
                            .padding(.bottom, 14)
                    }
                    SCard("Model") {
                        SInfo(icon: "cpu", title: "Real-ESRGAN 4x", value: ESRGAN.shared.available ? "Ready" : "Not in this build")
                    }
                }
                .padding(.bottom, 24)
            }
        }
        .foregroundColor(.white)
        .background(T.bg.ignoresSafeArea())
    }
}

struct CameraApp: View {
    @EnvironmentObject var os: OS
    @StateObject var cam = CamModel()
    @State var timerSec = 0
    @State var count = 0
    @State var grid = false
    @State var baseZoom: CGFloat = 1
    @State var showSettings = false
    let zoomSteps: [CGFloat] = [1, 2, 5, 10, 30, 100]
    let moonSteps: [CGFloat] = [10, 20, 50, 100, 400, 800]
    let nightSteps: [Int] = [1, 2, 3, 5, 10, 15, 20, 30]

    var steps: [CGFloat] { cam.moon ? moonSteps : zoomSteps }

    func zoomText(_ z: CGFloat) -> String {
        z < 10 ? String(format: "%.1fx", z) : String(format: "%.0fx", z)
    }

    func zoomLabel() -> String {
        let t = zoomText(cam.zoom)
        if cam.moon { return "Moon " + t }
        if cam.night { return "Night \(cam.nightSec)s" }
        return cam.zoom >= 100 ? "Space " + t : t
    }

    func sync() {
        cam.enhanceOn = os.camEnhance
        cam.factor = CGFloat(os.camFactor)
        cam.steadyN = os.camSteady
        cam.minZoom = CGFloat(os.camMinZoom)
    }

    func goSpace() {
        cam.setZoom(800)
        baseZoom = 800
    }

    func countdown(_ n: Int) {
        if n <= 0 {
            count = 0
            cam.shoot()
            return
        }
        count = n
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { countdown(n - 1) }
    }

    func shutter() {
        sync()
        if cam.night {
            cam.toggleNight()
        } else if cam.videoMode {
            cam.toggleRecord()
        } else if timerSec == 0 {
            cam.shoot()
        } else {
            countdown(timerSec)
        }
    }

    func chip(_ title: String, _ on: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(on ? T.onAccent : .white)
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(Capsule().fill(on ? T.accent : Color.white.opacity(0.12)))
        }
    }

    var topRow: some View {
        HStack {
            Button { cam.flashOn.toggle() } label: {
                Image(systemName: cam.flashOn ? "bolt.fill" : "bolt.slash.fill")
                    .foregroundColor(cam.flashOn ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Button {
                os.camEnhance.toggle()
                cam.enhanceOn = os.camEnhance
            } label: {
                Text("EN")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(os.camEnhance ? T.onAccent : .white)
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(Capsule().fill(os.camEnhance ? T.accent : Color.white.opacity(0.15)))
            }
            Button { grid.toggle() } label: {
                Image(systemName: "grid")
                    .foregroundColor(grid ? T.accent : .white)
                    .frame(width: 40, height: 40)
            }
            Spacer()
            if cam.recording {
                Text(String(format: "%02d:%02d", cam.recSeconds / 60, cam.recSeconds % 60))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Capsule().fill(Color.red))
            } else {
                Text(zoomLabel())
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .background(Capsule().fill(T.accent))
            }
            Spacer()
            Button { timerSec = timerSec == 0 ? 3 : (timerSec == 3 ? 10 : 0) } label: {
                ZStack {
                    Image(systemName: "timer").foregroundColor(timerSec == 0 ? .white : T.accent)
                    if timerSec > 0 {
                        Text("\(timerSec)")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(T.accent)
                            .offset(x: 12, y: -10)
                    }
                }
                .frame(width: 40, height: 40)
            }
            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
                    .foregroundColor(.white)
                    .frame(width: 40, height: 40)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, os.padTop - 8)
    }

    var preview: some View {
        ZStack {
            Color(white: 0.1)
            if cam.authorized {
                CamPreview(session: cam.session).scaleEffect(cam.extraZoom)
            } else {
                Text("Allow camera access in iOS Settings")
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding()
            }
            if grid { GridLines() }
            if count > 0 {
                Text("\(count)").font(.system(size: 90, weight: .bold)).foregroundColor(.white)
            }
            if !cam.burstText.isEmpty || cam.pending > 0 {
                VStack {
                    Spacer()
                    Text(cam.burstText.isEmpty ? "Enhancing \(cam.pending)..." : cam.burstText)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(Capsule().fill(Color.black.opacity(0.55)))
                        .padding(.bottom, 10)
                }
                .allowsHitTesting(false)
            }
        }
        .aspectRatio(3.0 / 4.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 10)
        .padding(.top, 8)
        .gesture(
            MagnificationGesture()
                .onChanged { v in cam.setZoom(baseZoom * v) }
                .onEnded { _ in baseZoom = cam.zoom }
        )
    }

    @ViewBuilder var zoomRow: some View {
        if cam.night { nightRow } else { stdZoomRow }
    }

    var nightRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                Text("Night")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white.opacity(0.7))
                ForEach(0..<nightSteps.count, id: \.self) { i in
                    chip("\(nightSteps[i])s", cam.nightSec == nightSteps[i]) { cam.nightSec = nightSteps[i] }
                }
            }
            .padding(.horizontal, 12)
        }
        .padding(.top, 10)
    }

    var stdZoomRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(0..<steps.count, id: \.self) { i in
                    chip(zoomText(steps[i]), abs(cam.zoom - steps[i]) < 0.05) {
                        cam.setZoom(steps[i])
                        baseZoom = steps[i]
                    }
                }
                if !cam.moon {
                    Button { goSpace() } label: {
                        Text("Space 800x")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(cam.zoom >= 799 ? T.onAccent : .white)
                            .padding(.horizontal, 12).padding(.vertical, 7)
                            .background(Capsule().fill(cam.zoom >= 799 ? T.accent : Color.purple.opacity(0.55)))
                    }
                }
            }
            .padding(.horizontal, 12)
        }
        .padding(.top, 10)
    }

    var modeRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                if !cam.moon && cam.hasUltra { chip("0.5x", cam.lens == 0) { cam.setLens(0) } }
                chip("1x", cam.lens == 1) { cam.setLens(1) }
                if cam.hasTele { chip("2x Tele", cam.lens == 2) { cam.setLens(2) } }
                Rectangle().fill(Color.white.opacity(0.25)).frame(width: 1, height: 20)
                chip("Photo", !cam.videoMode && !cam.moon && !cam.night) {
                    cam.setMoon(false)
                    cam.setNight(false)
                    cam.setMode(video: false)
                }
                chip("Video", cam.videoMode) {
                    cam.setMoon(false)
                    cam.setNight(false)
                    cam.setMode(video: true)
                }
                chip("Moon", cam.moon) {
                    cam.setNight(false)
                    cam.setMoon(true)
                }
                chip("Night", cam.night) {
                    cam.setMoon(false)
                    cam.setNight(true)
                }
            }
            .padding(.horizontal, 10)
        }
        .padding(.bottom, 12)
    }

    var bottomRow: some View {
        HStack {
            Button {
                if let p = appFor("photos") { os.launch(p) }
            } label: {
                if let img = cam.last {
                    Image(uiImage: img).resizable().scaledToFill()
                        .frame(width: 54, height: 54).clipShape(Circle())
                } else {
                    Circle().fill(T.card).frame(width: 54, height: 54)
                }
            }
            Spacer()
            Button { shutter() } label: {
                ZStack {
                    Circle().stroke(Color.white, lineWidth: 4).frame(width: 78, height: 78)
                    if cam.videoMode {
                        RoundedRectangle(cornerRadius: cam.recording ? 10 : 33, style: .continuous)
                            .fill(Color.red)
                            .frame(width: cam.recording ? 34 : 66, height: cam.recording ? 34 : 66)
                    } else {
                        Circle().fill(Color.white).frame(width: 64, height: 64)
                    }
                }
            }
            Spacer()
            Button { cam.flip() } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .foregroundColor(.white)
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(T.card))
            }
        }
        .padding(.horizontal, 36)
        .padding(.bottom, 34)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                topRow
                preview
                zoomRow
                Spacer()
                modeRow
                bottomRow
            }
        }
        .sheet(isPresented: $showSettings) { CameraSettingsView().environmentObject(os) }
        .onAppear {
            sync()
            cam.start()
            DispatchQueue.global(qos: .utility).async { _ = ESRGAN.shared }
        }
        .onDisappear { cam.stop() }
    }
}
