import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreImage

// Photos.swift - Gallery storage + the Photos app: grid with Favorites/Videos tabs, multi select, share, delete,
// import, full screen viewer (pinch + double tap zoom, swipe between photos), editor (adjust, filters, crop, rotate,
// Real-ESRGAN enhance). Read CLAUDE.md before editing.

// MARK: - Gallery storage (shared by Camera + Photos)
enum Gallery {
    static var dir: URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let u = base.appendingPathComponent("Camera", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    @discardableResult
    static func save(_ data: Data) -> URL? {
        let name = "IMG_\(Int(Date().timeIntervalSince1970 * 1000))_\(Int.random(in: 100...999)).jpg"
        let u = dir.appendingPathComponent(name)
        do {
            try data.write(to: u)
            return u
        } catch {
            return nil
        }
    }

    static func saveMovie(from url: URL) -> URL? {
        let name = "VID_\(Int(Date().timeIntervalSince1970 * 1000)).mov"
        let dest = dir.appendingPathComponent(name)
        do {
            try FileManager.default.copyItem(at: url, to: dest)
            return dest
        } catch {
            return nil
        }
    }

    static func delete(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
    }

    static func list() -> [URL] {
        let keys: [URLResourceKey] = [.creationDateKey]
        let all = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys)) ?? []
        let media = all.filter { ["jpg", "mov"].contains($0.pathExtension.lowercased()) }
        return media.sorted { a, b in
            let da = (try? a.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            let db = (try? b.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? Date.distantPast
            return da > db
        }
    }

    static func thumb(_ url: URL, max: CGFloat) -> UIImage? {
        if url.pathExtension.lowercased() == "mov" {
            let gen = AVAssetImageGenerator(asset: AVAsset(url: url))
            gen.appliesPreferredTrackTransform = true
            gen.maximumSize = CGSize(width: max, height: max)
            if let cg = try? gen.copyCGImage(at: .zero, actualTime: nil) { return UIImage(cgImage: cg) }
            return nil
        }
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: max
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }

    static func meta(_ url: URL) -> String {
        var lines = [url.lastPathComponent]
        if let a = try? FileManager.default.attributesOfItem(atPath: url.path) {
            if let n = a[.size] as? NSNumber {
                lines.append(String(format: "%.1f MB", n.doubleValue / 1_000_000))
            }
            if let d = a[.creationDate] as? Date {
                let f = DateFormatter()
                f.dateStyle = .medium
                f.timeStyle = .short
                lines.append(f.string(from: d))
            }
        }
        if let src = CGImageSourceCreateWithURL(url as CFURL, nil),
           let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
           let w = props[kCGImagePropertyPixelWidth] as? Int,
           let h = props[kCGImagePropertyPixelHeight] as? Int {
            lines.append("\(w) x \(h)")
        }
        return lines.joined(separator: "\n")
    }
}

// MARK: - Small shared views
struct Thumb: View {
    let url: URL
    let maxSize: CGFloat
    var fill = true
    @State var img: UIImage? = nil

    var body: some View {
        Group {
            if let i = img {
                if fill {
                    Image(uiImage: i).resizable().scaledToFill()
                } else {
                    Image(uiImage: i).resizable().scaledToFit()
                }
            } else {
                T.card
            }
        }
        .onAppear {
            DispatchQueue.global().async {
                let t = Gallery.thumb(url, max: maxSize)
                DispatchQueue.main.async { img = t }
            }
        }
    }
}

struct VideoView: View {
    @State var player: AVPlayer
    init(url: URL) { _player = State(initialValue: AVPlayer(url: url)) }
    var body: some View {
        VideoPlayer(player: player)
            .onAppear { player.play() }
            .onDisappear { player.pause() }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Pick several photos from the iPhone library to import into the app gallery.
struct MultiPicker: UIViewControllerRepresentable {
    let onPick: ([UIImage]) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var cfg = PHPickerConfiguration()
        cfg.filter = .images
        cfg.selectionLimit = 0
        let vc = PHPickerViewController(configuration: cfg)
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onPick) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onPick: ([UIImage]) -> Void
        init(_ f: @escaping ([UIImage]) -> Void) { onPick = f }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            var imgs: [UIImage] = []
            let group = DispatchGroup()
            for r in results where r.itemProvider.canLoadObject(ofClass: UIImage.self) {
                group.enter()
                r.itemProvider.loadObject(ofClass: UIImage.self) { obj, _ in
                    if let i = obj as? UIImage {
                        DispatchQueue.main.async {
                            imgs.append(i)
                            group.leave()
                        }
                    } else {
                        group.leave()
                    }
                }
            }
            group.notify(queue: .main) { self.onPick(imgs) }
        }
    }
}

// MARK: - Pinch / double tap zoom
final class ZoomScroll: UIScrollView {
    var onLayout: (() -> Void)?
    override func layoutSubviews() {
        super.layoutSubviews()
        onLayout?()
    }
}

struct ZoomImage: UIViewRepresentable {
    let image: UIImage

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> ZoomScroll {
        let sv = ZoomScroll()
        sv.delegate = context.coordinator
        sv.minimumZoomScale = 1
        sv.maximumZoomScale = 8
        sv.showsHorizontalScrollIndicator = false
        sv.showsVerticalScrollIndicator = false
        sv.bouncesZoom = true
        let iv = UIImageView(image: image)
        iv.contentMode = .scaleAspectFit
        iv.isUserInteractionEnabled = true
        sv.addSubview(iv)
        context.coordinator.iv = iv
        context.coordinator.sv = sv
        sv.onLayout = { [weak coordinator = context.coordinator] in coordinator?.layout() }
        let dt = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.doubleTap(_:)))
        dt.numberOfTapsRequired = 2
        sv.addGestureRecognizer(dt)
        return sv
    }

    func updateUIView(_ sv: ZoomScroll, context: Context) {
        context.coordinator.iv?.image = image
        context.coordinator.layout()
    }

    final class Coordinator: NSObject, UIScrollViewDelegate {
        weak var iv: UIImageView?
        weak var sv: ZoomScroll?

        func viewForZooming(in scrollView: UIScrollView) -> UIView? { iv }

        func layout() {
            guard let sv = sv, let iv = iv else { return }
            if sv.zoomScale <= 1.0001 && iv.frame != sv.bounds {
                iv.frame = sv.bounds
                sv.contentSize = sv.bounds.size
            }
        }

        @objc func doubleTap(_ g: UITapGestureRecognizer) {
            guard let sv = sv, let iv = iv else { return }
            if sv.zoomScale > 1.01 {
                sv.setZoomScale(1, animated: true)
            } else {
                let p = g.location(in: iv)
                let w = sv.bounds.width / 3
                let h = sv.bounds.height / 3
                sv.zoom(to: CGRect(x: p.x - w / 2, y: p.y - h / 2, width: w, height: h), animated: true)
            }
        }
    }
}

// MARK: - Viewer
struct PhotoPage: View {
    let url: URL
    @State var img: UIImage? = nil

    var body: some View {
        ZStack {
            Color.black
            if url.pathExtension.lowercased() == "mov" {
                VideoView(url: url)
            } else if let i = img {
                ZoomImage(image: i)
            } else {
                ProgressView().tint(.white)
            }
        }
        .onAppear {
            if url.pathExtension.lowercased() != "mov" && img == nil {
                DispatchQueue.global().async {
                    let t = Gallery.thumb(url, max: 3000)
                    DispatchQueue.main.async { img = t }
                }
            }
        }
    }
}

struct PhotoViewer: View {
    @EnvironmentObject var os: OS
    @State var list: [URL]
    @State var index: Int
    let onClose: () -> Void
    @State var showEdit = false
    @State var showShare = false
    @State var showInfo = false
    @State var refreshTick = 0

    init(files: [URL], index: Int, onClose: @escaping () -> Void) {
        _list = State(initialValue: files)
        _index = State(initialValue: index)
        self.onClose = onClose
    }

    var cur: URL? { list.indices.contains(index) ? list[index] : nil }

    func isFav(_ u: URL) -> Bool { os.favs.contains(u.lastPathComponent) }

    func toggleFav(_ u: URL) {
        let n = u.lastPathComponent
        if let i = os.favs.firstIndex(of: n) { os.favs.remove(at: i) } else { os.favs.append(n) }
    }

    func deleteCurrent() {
        guard let u = cur else { return }
        Gallery.delete(u)
        os.favs.removeAll { $0 == u.lastPathComponent }
        list.remove(at: index)
        if list.isEmpty {
            onClose()
        } else {
            index = min(index, list.count - 1)
        }
    }

    func icon(_ name: String, _ color: Color = .white, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: name)
                .font(.system(size: 18))
                .foregroundColor(color)
                .frame(width: 42, height: 42)
                .background(Circle().fill(Color.black.opacity(0.35)))
        }
    }

    var topBar: some View {
        HStack(spacing: 8) {
            icon("chevron.left") { onClose() }
            Spacer()
            if let u = cur {
                icon(isFav(u) ? "heart.fill" : "heart", isFav(u) ? Color.red : Color.white) { toggleFav(u) }
                icon("square.and.arrow.up") { showShare = true }
                if u.pathExtension.lowercased() != "mov" {
                    icon("slider.horizontal.3") { showEdit = true }
                }
                icon("trash") { deleteCurrent() }
                icon("info.circle") { showInfo = true }
            }
        }
        .padding(.horizontal, 12)
        .padding(.top, os.padTop - 24)
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            TabView(selection: $index) {
                ForEach(list.indices, id: \.self) { i in
                    PhotoPage(url: list[i]).id("\(list[i].lastPathComponent)-\(refreshTick)").tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            topBar
        }
        .sheet(isPresented: $showShare) {
            if let u = cur { ShareSheet(items: [u]) }
        }
        .sheet(isPresented: $showEdit) {
            if let u = cur {
                PhotoEditor(url: u) { refreshTick += 1 }.environmentObject(os)
            }
        }
        .alert("Details", isPresented: $showInfo) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(cur.map { Gallery.meta($0) } ?? "")
        }
    }
}

// MARK: - Editor
struct EditParams: Equatable {
    var brightness = 0.0
    var contrast = 1.0
    var saturation = 1.0
    var warmth = 0.0
    var sharpen = 0.0
    var filter = 0
    var turns = 0
    var aspect = 0
    var zoom = 1.0
    var panX = 0.0
    var panY = 0.0
}

enum EditKit {
    static let ctx = CIContext()

    static let filters: [(String, String)] = [
        ("Original", ""), ("Vivid", "CIPhotoEffectChrome"), ("Warm", "CIPhotoEffectInstant"),
        ("Fade", "CIPhotoEffectFade"), ("Noir", "CIPhotoEffectNoir"), ("Mono", "CIPhotoEffectMono"),
        ("Process", "CIPhotoEffectProcess"), ("Tonal", "CIPhotoEffectTonal")
    ]

    static let aspects: [(String, CGFloat)] = [
        ("Original", 0), ("1:1", 1), ("4:3", 4.0 / 3.0), ("3:4", 3.0 / 4.0), ("16:9", 16.0 / 9.0), ("9:16", 9.0 / 16.0)
    ]

    static func render(_ input: CIImage, _ p: EditParams) -> CIImage {
        var ci = input
        let t = ((p.turns % 4) + 4) % 4
        if t != 0 {
            ci = ci.transformed(by: CGAffineTransform(rotationAngle: -CGFloat.pi / 2 * CGFloat(t)))
            ci = ci.transformed(by: CGAffineTransform(translationX: -ci.extent.origin.x, y: -ci.extent.origin.y))
        }
        let ext = ci.extent
        var cw = ext.width
        var ch = ext.height
        let ar = aspects[min(max(p.aspect, 0), aspects.count - 1)].1
        if ar > 0 {
            if cw / ch > ar { cw = ch * ar } else { ch = cw / ar }
        }
        cw /= CGFloat(p.zoom)
        ch /= CGFloat(p.zoom)
        let maxX = (ext.width - cw) / 2
        let maxY = (ext.height - ch) / 2
        let cx = ext.midX + CGFloat(p.panX) * maxX
        let cy = ext.midY + CGFloat(p.panY) * maxY
        let rect = CGRect(x: cx - cw / 2, y: cy - ch / 2, width: cw, height: ch)
        ci = ci.cropped(to: rect)
        ci = ci.transformed(by: CGAffineTransform(translationX: -rect.origin.x, y: -rect.origin.y))
        if let cc = CIFilter(name: "CIColorControls") {
            cc.setValue(ci, forKey: kCIInputImageKey)
            cc.setValue(p.brightness, forKey: kCIInputBrightnessKey)
            cc.setValue(p.contrast, forKey: kCIInputContrastKey)
            cc.setValue(p.saturation, forKey: kCIInputSaturationKey)
            if let o = cc.outputImage { ci = o }
        }
        if p.warmth != 0, let cm = CIFilter(name: "CIColorMatrix") {
            let w = CGFloat(p.warmth)
            cm.setValue(ci, forKey: kCIInputImageKey)
            cm.setValue(CIVector(x: 1 + 0.25 * w, y: 0, z: 0, w: 0), forKey: "inputRVector")
            cm.setValue(CIVector(x: 0, y: 1, z: 0, w: 0), forKey: "inputGVector")
            cm.setValue(CIVector(x: 0, y: 0, z: 1 - 0.25 * w, w: 0), forKey: "inputBVector")
            cm.setValue(CIVector(x: 0, y: 0, z: 0, w: 1), forKey: "inputAVector")
            if let o = cm.outputImage { ci = o }
        }
        if p.filter > 0 && p.filter < filters.count, let f = CIFilter(name: filters[p.filter].1) {
            f.setValue(ci, forKey: kCIInputImageKey)
            if let o = f.outputImage { ci = o }
        }
        if p.sharpen > 0, let sh = CIFilter(name: "CISharpenLuminance") {
            sh.setValue(ci, forKey: kCIInputImageKey)
            sh.setValue(p.sharpen, forKey: kCIInputSharpnessKey)
            if let o = sh.outputImage { ci = o }
        }
        return ci
    }
}

struct PhotoEditor: View {
    @EnvironmentObject var os: OS
    @Environment(\.dismiss) var dismiss
    let url: URL
    let onSaved: () -> Void
    @State var base: CIImage? = nil
    @State var p = EditParams()
    @State var preview: UIImage? = nil
    @State var tab = 0
    @State var factor: Double = 4
    @State var busy = ""

    func load() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let t = Gallery.thumb(url, max: 1400), let cg = t.cgImage else { return }
            let ci = CIImage(cgImage: cg)
            DispatchQueue.main.async {
                base = ci
                refresh()
            }
        }
    }

    func refresh() {
        guard let b = base else { return }
        let out = EditKit.render(b, p)
        if let cg = EditKit.ctx.createCGImage(out, from: out.extent) { preview = UIImage(cgImage: cg) }
    }

    func save(replace: Bool) {
        busy = "Saving..."
        let params = p
        DispatchQueue.global(qos: .userInitiated).async {
            guard let full = CIImage(contentsOf: url, options: [.applyOrientationProperty: true]) else {
                DispatchQueue.main.async { busy = "" }
                return
            }
            let out = EditKit.render(full, params)
            guard let cg = EditKit.ctx.createCGImage(out, from: out.extent),
                  let jpg = UIImage(cgImage: cg).jpegData(compressionQuality: 0.95) else {
                DispatchQueue.main.async { busy = "" }
                return
            }
            if replace { try? jpg.write(to: url) } else { Gallery.save(jpg) }
            DispatchQueue.main.async {
                busy = ""
                onSaved()
                dismiss()
            }
        }
    }

    func enhanceNow() {
        let f = CGFloat(factor)
        busy = "Enhancing in the background..."
        DispatchQueue.global(qos: .utility).async {
            guard let ui = UIImage(contentsOfFile: url.path) else {
                DispatchQueue.main.async { busy = "" }
                return
            }
            let long = CGFloat(max(ui.size.width, ui.size.height))
            let out = Enhancer.enhance(ui, factor: f, trueSide: long)
            if let jpg = out.jpegData(compressionQuality: 0.95) { Gallery.save(jpg) }
            DispatchQueue.main.async {
                busy = ""
                onSaved()
            }
        }
    }

    func slider(_ title: String, _ v: Binding<Double>, _ r: ClosedRange<Double>) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.8))
                .frame(width: 84, alignment: .leading)
            Slider(value: v, in: r).accentColor(T.accent)
        }
        .padding(.horizontal, 16)
    }

    var topBar: some View {
        HStack {
            Button("Cancel") { dismiss() }
            Spacer()
            Button("Reset") { p = EditParams() }
            Menu {
                Button("Save as copy") { save(replace: false) }
                Button("Replace original") { save(replace: true) }
            } label: {
                Text("Save")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(T.onAccent)
                    .padding(.horizontal, 16).padding(.vertical, 7)
                    .background(Capsule().fill(T.accent))
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    @ViewBuilder var panel: some View {
        ScrollView {
            VStack(spacing: 8) {
                switch tab {
                case 0:
                    slider("Brightness", $p.brightness, -0.4...0.4)
                    slider("Contrast", $p.contrast, 0.6...1.8)
                    slider("Saturation", $p.saturation, 0...2)
                    slider("Warmth", $p.warmth, -1...1)
                    slider("Sharpen", $p.sharpen, 0...2)
                case 1:
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(0..<EditKit.filters.count, id: \.self) { i in
                                Button { p.filter = i } label: {
                                    Text(EditKit.filters[i].0)
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundColor(p.filter == i ? T.onAccent : .white)
                                        .padding(.horizontal, 14).padding(.vertical, 9)
                                        .background(Capsule().fill(p.filter == i ? T.accent : Color.white.opacity(0.12)))
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                case 2:
                    ScrollView(.horizontal, showsIndicators: false) {
                        ChipRow(items: EditKit.aspects.map { $0.0 }, selected: p.aspect) { p.aspect = $0 }
                    }
                    slider("Zoom", $p.zoom, 1...4)
                    slider("Move X", $p.panX, -1...1)
                    slider("Move Y", $p.panY, -1...1)
                    HStack(spacing: 14) {
                        Button { p.turns -= 1 } label: {
                            Image(systemName: "rotate.left").frame(width: 56, height: 40).background(Capsule().fill(Color.white.opacity(0.12)))
                        }
                        Button { p.turns += 1 } label: {
                            Image(systemName: "rotate.right").frame(width: 56, height: 40).background(Capsule().fill(Color.white.opacity(0.12)))
                        }
                    }
                default:
                    HStack {
                        Text("Enhance by").foregroundColor(.white)
                        Spacer()
                        Text("\(Int(factor))x").foregroundColor(T.accent)
                    }
                    .padding(.horizontal, 16)
                    Slider(value: $factor, in: 4...30, step: 1)
                        .accentColor(T.accent)
                        .padding(.horizontal, 16)
                    Button { enhanceNow() } label: {
                        Text("Enhance and save a copy")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(T.onAccent)
                            .padding(.horizontal, 20).padding(.vertical, 10)
                            .background(Capsule().fill(T.accent))
                    }
                    Text(ESRGAN.shared.available ? "Uses Real-ESRGAN. Big values take a while." : "Real-ESRGAN is not in this build, so the basic enhancer is used.")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.6))
                        .padding(.horizontal, 16)
                }
            }
            .padding(.top, 8)
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            topBar
            ZStack {
                Color.black
                if let pv = preview {
                    Image(uiImage: pv).resizable().scaledToFit()
                } else {
                    ProgressView().tint(.white)
                }
                if !busy.isEmpty {
                    Text(busy)
                        .font(.system(size: 13, weight: .medium))
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Capsule().fill(Color.black.opacity(0.7)))
                }
            }
            .frame(maxHeight: .infinity)
            ChipRow(items: ["Adjust", "Filters", "Crop", "Enhance"], selected: tab) { tab = $0 }
            panel.frame(height: 200)
        }
        .foregroundColor(.white)
        .background(Color.black.ignoresSafeArea())
        .onAppear { load() }
        .onChange(of: p) { _ in refresh() }
    }
}

// MARK: - Photos app
struct PhotosApp: View {
    @EnvironmentObject var os: OS
    @State var files: [URL] = []
    @State var tab = 0
    @State var viewing: Int? = nil
    @State var selecting = false
    @State var picked: Set<URL> = []
    @State var showImport = false
    @State var showShare = false
    let cols = Array(repeating: GridItem(.flexible(), spacing: 3), count: 3)

    func isVideo(_ u: URL) -> Bool { u.pathExtension.lowercased() == "mov" }

    var shown: [URL] {
        switch tab {
        case 1: return files.filter { os.favs.contains($0.lastPathComponent) }
        case 2: return files.filter { isVideo($0) }
        default: return files
        }
    }

    func refresh() { files = Gallery.list() }

    func toggle(_ u: URL) {
        if picked.contains(u) { picked.remove(u) } else { picked.insert(u) }
    }

    func deletePicked() {
        for u in picked {
            Gallery.delete(u)
            os.favs.removeAll { $0 == u.lastPathComponent }
        }
        picked = []
        selecting = false
        refresh()
    }

    @ViewBuilder func badges(_ u: URL) -> some View {
        ZStack {
            if isVideo(u) {
                Image(systemName: "play.circle.fill").font(.system(size: 26)).foregroundColor(.white)
            }
            if os.favs.contains(u.lastPathComponent) {
                VStack {
                    Spacer()
                    HStack {
                        Image(systemName: "heart.fill").font(.system(size: 12)).foregroundColor(.white).padding(5)
                        Spacer()
                    }
                }
            }
            if selecting {
                VStack {
                    HStack {
                        Spacer()
                        Image(systemName: picked.contains(u) ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 20))
                            .foregroundColor(picked.contains(u) ? T.accent : Color.white)
                            .padding(6)
                    }
                    Spacer()
                }
            }
        }
    }

    var header: some View {
        HStack {
            Text("Photos")
                .font(.system(size: 30, weight: .regular))
                .foregroundColor(.white)
            Spacer()
            Button { showImport = true } label: {
                Image(systemName: "plus")
                    .foregroundColor(.white)
                    .frame(width: 40, height: 40)
                    .background(Circle().fill(T.card))
            }
            Button {
                selecting.toggle()
                picked = []
            } label: {
                Text(selecting ? "Cancel" : "Select")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(selecting ? T.onAccent : .white)
                    .padding(.horizontal, 14).padding(.vertical, 9)
                    .background(Capsule().fill(selecting ? T.accent : T.card))
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 10)
    }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                header
                ChipRow(items: ["All", "Favorites", "Videos"], selected: tab) { tab = $0 }
                if shown.isEmpty {
                    Spacer()
                    Text(tab == 1 ? "No favorites yet" : "Nothing here yet")
                        .foregroundColor(.white.opacity(0.6))
                    Spacer()
                } else {
                    ScrollView {
                        LazyVGrid(columns: cols, spacing: 3) {
                            ForEach(shown, id: \.self) { u in
                                Button {
                                    if selecting {
                                        toggle(u)
                                    } else if let i = shown.firstIndex(of: u) {
                                        viewing = i
                                    }
                                } label: {
                                    Color.clear
                                        .aspectRatio(1, contentMode: .fit)
                                        .overlay(Thumb(url: u, maxSize: 300))
                                        .overlay(badges(u))
                                        .clipped()
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                if selecting && !picked.isEmpty {
                    HStack(spacing: 14) {
                        Button { showShare = true } label: {
                            Label("Share", systemImage: "square.and.arrow.up")
                                .foregroundColor(.white)
                                .padding(.horizontal, 20).padding(.vertical, 10)
                                .background(Capsule().fill(T.card))
                        }
                        Button { deletePicked() } label: {
                            Label("Delete \(picked.count)", systemImage: "trash")
                                .foregroundColor(.white)
                                .padding(.horizontal, 20).padding(.vertical, 10)
                                .background(Capsule().fill(Color.red.opacity(0.75)))
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            if let i = viewing {
                PhotoViewer(files: shown, index: i) {
                    viewing = nil
                    refresh()
                }
                .transition(.opacity)
            }
        }
        .sheet(isPresented: $showImport) {
            MultiPicker { imgs in
                for i in imgs {
                    if let d = i.jpegData(compressionQuality: 0.95) { Gallery.save(d) }
                }
                refresh()
            }
        }
        .sheet(isPresented: $showShare) { ShareSheet(items: Array(picked)) }
        .onAppear {
            refresh()
            os.backHandlers["photos"] = {
                if viewing != nil {
                    viewing = nil
                    return true
                }
                if selecting {
                    selecting = false
                    picked = []
                    return true
                }
                return false
            }
        }
    }
}
