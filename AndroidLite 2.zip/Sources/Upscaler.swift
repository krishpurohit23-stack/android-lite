import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI
import CoreML
import Vision
import CoreImage

// Upscaler.swift - Real-ESRGAN 4x (Core ML) tile upscaler used by the Camera "EN" button. Read CLAUDE.md before editing.
// The model file RealESRGAN.mlmodelc is created and added to the app by the GitHub workflow.
// If it is missing, `available` is false and the camera falls back to the Core Image enhancer.

final class ESRGAN {
    static let shared = ESRGAN()
    private var model: VNCoreMLModel?
    private let ctx = CIContext()
    private let tile = 128
    private let pad = 8

    var available: Bool { model != nil }

    init() {
        guard let url = Bundle.main.url(forResource: "RealESRGAN", withExtension: "mlmodelc") else { return }
        let cfg = MLModelConfiguration()
        cfg.computeUnits = .all
        if let ml = try? MLModel(contentsOf: url, configuration: cfg),
           let vm = try? VNCoreMLModel(for: ml) {
            model = vm
        }
    }

    static func resize(_ cg: CGImage, _ w: Int, _ h: Int) -> CGImage? {
        guard let c = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        c.interpolationQuality = .high
        c.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        return c.makeImage()
    }

    /// 4x upscale. Keep the input small (about 640 px or less); the work is done in 128x128 tiles.
    func upscale4x(_ img: CGImage) -> CGImage? {
        guard let vm = model else { return nil }
        let W = img.width
        let H = img.height
        let outW = W * 4
        let outH = H * 4
        guard let canvas = CGContext(data: nil, width: outW, height: outH, bitsPerComponent: 8, bytesPerRow: 0,
                                     space: CGColorSpaceCreateDeviceRGB(),
                                     bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        let clamped = CIImage(cgImage: img).clampedToExtent()
        let step = tile - 2 * pad
        let cols = (W + step - 1) / step
        let rows = (H + step - 1) / step
        for r in 0..<rows {
            for c in 0..<cols {
                let x0 = c * step
                let y0 = r * step
                let x1 = min(x0 + step, W)
                let y1 = min(y0 + step, H)
                let sx = x0 - pad
                let sy = y0 - pad
                let rect = CGRect(x: sx, y: H - (sy + tile), width: tile, height: tile)
                guard let tcg = ctx.createCGImage(clamped.cropped(to: rect), from: rect) else { continue }
                let req = VNCoreMLRequest(model: vm)
                req.imageCropAndScaleOption = .scaleFill
                let handler = VNImageRequestHandler(cgImage: tcg, options: [:])
                do { try handler.perform([req]) } catch { continue }
                guard let obs = req.results?.first as? VNPixelBufferObservation else { continue }
                let oci = CIImage(cvPixelBuffer: obs.pixelBuffer)
                guard let ocg = ctx.createCGImage(oci, from: oci.extent) else { continue }
                let crop = CGRect(x: pad * 4, y: pad * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4)
                guard let inner = ocg.cropping(to: crop) else { continue }
                canvas.draw(inner, in: CGRect(x: x0 * 4, y: outH - y1 * 4, width: (x1 - x0) * 4, height: (y1 - y0) * 4))
            }
        }
        return canvas.makeImage()
    }
}

/// One place that decides how a picture is enhanced: Real-ESRGAN when the model is in the app, Core Image otherwise.
enum Enhancer {
    /// factor 4...30 (4 = one ESRGAN pass, above 6 = two passes (16x) resized to the asked factor).
    /// trueSide = the real detail size (long side in pixels) of the picture; big photos are shrunk to it first.
    static func enhance(_ img: UIImage, factor: CGFloat, trueSide: CGFloat) -> UIImage {
        guard let cg = img.cgImage else { return img }
        let f = min(max(factor, 4), 30)
        if ESRGAN.shared.available, let out = esrgan(cg, factor: f, trueSide: trueSide) {
            return UIImage(cgImage: out, scale: 1, orientation: img.imageOrientation)
        }
        let zoomHint = max(1, 4032 / max(trueSide, 1))
        return CamModel.ciEnhance(img, scale: f >= 8 ? 3 : 2, zoom: zoomHint)
    }

    static func esrgan(_ cg: CGImage, factor f: CGFloat, trueSide: CGFloat) -> CGImage? {
        let maxSide = CGFloat(max(cg.width, cg.height))
        let passes = f <= 6 ? 1 : 2
        let limit: CGFloat = passes == 1 ? min(640, 4000 / f) : 200
        let target = max(24, min(trueSide, limit, maxSide))
        var cur = cg
        if target < maxSide - 1 {
            let k = target / maxSide
            let w = max(8, Int(CGFloat(cg.width) * k))
            let h = max(8, Int(CGFloat(cg.height) * k))
            if let r = ESRGAN.resize(cg, w, h) { cur = r }
        }
        let inW = CGFloat(cur.width)
        let inH = CGFloat(cur.height)
        guard var out = ESRGAN.shared.upscale4x(cur) else { return nil }
        if passes == 2, let second = ESRGAN.shared.upscale4x(out) { out = second }
        let have = CGFloat(out.width) / inW
        if abs(have - f) > 0.01 {
            let tw = max(8, Int((inW * f).rounded()))
            let th = max(8, Int((inH * f).rounded()))
            if let r = ESRGAN.resize(out, tw, th) { out = r }
        }
        return out
    }
}
