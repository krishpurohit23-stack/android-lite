import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Settings.swift - Pixel-style Settings app (categories + sub pages) and its reusable row views. Read CLAUDE.md before editing.

// MARK: - Settings
func openIOSSettings() {
    if let u = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(u) }
}

struct PhotoPicker: UIViewControllerRepresentable {
    let onPick: (UIImage) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var cfg = PHPickerConfiguration()
        cfg.filter = .images
        cfg.selectionLimit = 1
        let vc = PHPickerViewController(configuration: cfg)
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onPick) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onPick: (UIImage) -> Void
        init(_ f: @escaping (UIImage) -> Void) { onPick = f }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let prov = results.first?.itemProvider, prov.canLoadObject(ofClass: UIImage.self) else { return }
            prov.loadObject(ofClass: UIImage.self) { obj, _ in
                if let img = obj as? UIImage {
                    DispatchQueue.main.async { self.onPick(img) }
                }
            }
        }
    }
}

struct SToggle: View {
    let icon: String
    let title: String
    let sub: String
    @Binding var on: Bool
    var body: some View {
        Toggle(isOn: $on) {
            HStack(spacing: 14) {
                Image(systemName: icon).foregroundColor(T.accent).frame(width: 26)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).foregroundColor(.white)
                    if !sub.isEmpty {
                        Text(sub).font(.system(size: 12)).foregroundColor(.white.opacity(0.6))
                    }
                }
            }
        }
        .toggleStyle(SwitchToggleStyle(tint: T.accent))
        .padding(.horizontal, 18)
        .padding(.vertical, 10)
    }
}

struct SInfo: View {
    let icon: String
    let title: String
    let value: String
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon).foregroundColor(T.accent).frame(width: 26)
            Text(title).foregroundColor(.white)
            Spacer()
            Text(value).foregroundColor(.white.opacity(0.65)).multilineTextAlignment(.trailing)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
    }
}

struct SAction: View {
    let icon: String
    let title: String
    let sub: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).foregroundColor(T.accent).frame(width: 26)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).foregroundColor(.white)
                    if !sub.isEmpty {
                        Text(sub).font(.system(size: 12)).foregroundColor(.white.opacity(0.6))
                    }
                }
                Spacer()
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
        }
        .buttonStyle(.plain)
    }
}

struct SCard<Content: View>: View {
    let title: String
    let content: Content
    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if !title.isEmpty {
                Text(title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(T.accent)
                    .padding(.horizontal, 18)
                    .padding(.top, 14)
                    .padding(.bottom, 4)
            }
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(T.card))
        .padding(.horizontal, 16)
    }
}

struct ChipRow: View {
    let items: [String]
    let selected: Int
    let pick: (Int) -> Void
    var body: some View {
        HStack(spacing: 8) {
            ForEach(0..<items.count, id: \.self) { i in
                Button { pick(i) } label: {
                    Text(items[i])
                        .font(.system(size: 14, weight: .medium))
                        .padding(.horizontal, 14).padding(.vertical, 9)
                        .foregroundColor(selected == i ? T.onAccent : .white)
                        .background(Capsule().fill(selected == i ? T.accent : Color.white.opacity(0.08)))
                }
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 8)
    }
}

struct SettingsApp: View {
    @EnvironmentObject var os: OS
    @State var query = ""
    @State var showPicker = false

    var cats: [SCat] {
        if query.isEmpty { return settingsCats }
        let q = query.lowercased()
        return settingsCats.filter { $0.title.lowercased().contains(q) || $0.sub.lowercased().contains(q) }
    }

    var body: some View {
        VStack(spacing: 0) {
            if os.settingsPage.isEmpty { mainList } else { subPage }
        }
        .sheet(isPresented: $showPicker) {
            PhotoPicker { img in
                os.setWallpaperPhoto(img)
                showPicker = false
            }
        }
        .onAppear {
            os.backHandlers["settings"] = {
                if !os.settingsPage.isEmpty {
                    os.settingsPage = ""
                    return true
                }
                return false
            }
        }
    }

    var mainList: some View {
        VStack(spacing: 0) {
            Title(text: "Settings")
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundColor(.white.opacity(0.7))
                TextField("Search settings", text: $query)
                    .foregroundColor(.white)
                    .disableAutocorrection(true)
            }
            .padding(.horizontal, 18)
            .frame(height: 48)
            .background(Capsule().fill(T.card))
            .padding(.horizontal, 16)
            .padding(.bottom, 8)
            StretchScroll {
                VStack(spacing: 2) {
                    ForEach(cats) { c in
                        Button { os.settingsPage = c.id } label: {
                            HStack(spacing: 16) {
                                Image(systemName: c.icon)
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundColor(c.tint)
                                    .frame(width: 46, height: 46)
                                    .background(Circle().fill(c.tint.opacity(0.22)))
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(c.title).font(.system(size: 16, weight: .medium)).foregroundColor(.white)
                                    Text(c.sub).font(.system(size: 13)).foregroundColor(.white.opacity(0.6))
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 9)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.bottom, 24)
            }
        }
    }

    var subPage: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Button { os.settingsPage = "" } label: {
                    Image(systemName: "chevron.left").foregroundColor(.white).frame(width: 40, height: 40)
                }
                Text(settingsCats.first(where: { $0.id == os.settingsPage })?.title ?? "")
                    .font(.system(size: 24))
                    .foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            StretchScroll {
                VStack(spacing: 14) {
                    page(os.settingsPage)
                }
                .padding(.bottom, 24)
            }
        }
    }

    @ViewBuilder func page(_ id: String) -> some View {
        switch id {
        case "network": pageNetwork
        case "devices": pageDevices
        case "apps": pageApps
        case "notifs": pageNotifs
        case "battery": pageBattery
        case "storage": pageStorage
        case "sound": pageSound
        case "display": pageDisplay
        case "wallpaper": pageWallpaper
        case "home": pageHome
        case "anim": pageAnim
        case "access": pageAccess
        case "security": pageSecurity
        case "location": pageLocation
        case "wellbeing": pageWellbeing
        case "system": pageSystem
        case "about": pageAbout
        default: EmptyView()
        }
    }

    func wBinding(_ k: String) -> Binding<Bool> {
        Binding(
            get: { os.widgets.contains(k) },
            set: { on in
                if on {
                    if !os.widgets.contains(k) { os.widgets.append(k) }
                } else {
                    os.widgets.removeAll { $0 == k }
                }
            }
        )
    }

    func batteryState() -> String {
        switch UIDevice.current.batteryState {
        case .charging: return "Charging"
        case .full: return "Full"
        case .unplugged: return "On battery"
        default: return "Unknown"
        }
    }

    func preview() {
        os.home()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            if let a = appFor("settings") { os.launch(a) }
        }
    }

    @ViewBuilder var pageNetwork: some View {
        SCard("Internet") {
            SToggle(icon: "wifi", title: "Wi-Fi", sub: "Visual only. iOS controls the real Wi-Fi", on: $os.wifi)
            SToggle(icon: "airplane", title: "Airplane mode", sub: "Visual only", on: $os.airplane)
            SAction(icon: "gearshape", title: "Open iOS Settings", sub: "Change real network settings") { openIOSSettings() }
        }
    }

    @ViewBuilder var pageDevices: some View {
        SCard("Bluetooth") {
            SToggle(icon: "dot.radiowaves.left.and.right", title: "Bluetooth", sub: "Visual only", on: $os.bt)
            SInfo(icon: "plus.circle", title: "Pair new device", value: "Use iOS")
        }
    }

    @ViewBuilder var pageApps: some View {
        SCard("Installed apps (\(sortedApps.count))") {
            ForEach(sortedApps) { a in
                HStack(spacing: 12) {
                    IconGlyph(app: a).scaleEffect(0.7).frame(width: 42, height: 42)
                    Text(a.name).foregroundColor(.white)
                    Spacer()
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 2)
            }
        }
        SCard("Web apps (\(os.webApps.count))") {
            if os.webApps.isEmpty {
                Text("Open Chrome, tap the ... menu, then Add as web app")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.6))
                    .padding(.horizontal, 18)
                    .padding(.bottom, 14)
            } else {
                ForEach($os.webApps) { $rec in
                    HStack(spacing: 10) {
                        TextField("Name", text: $rec.name).foregroundColor(.white)
                        Button { os.removeWebApp(rec.id) } label: {
                            Image(systemName: "trash").foregroundColor(Color.red.opacity(0.9))
                        }
                    }
                    .padding(.horizontal, 18)
                    .frame(height: 44)
                }
            }
        }
    }

    @ViewBuilder var pageNotifs: some View {
        SCard("Notifications") {
            SToggle(icon: "moon.fill", title: "Do Not Disturb", sub: "No heads-up banners", on: $os.dnd)
            SToggle(icon: "rectangle.topthird.inset.filled", title: "Heads-up banners", sub: "", on: $os.banners)
            SToggle(icon: "eye.slash", title: "Hide sensitive content", sub: "", on: $os.hideNotif)
            SAction(icon: "trash", title: "Clear all notifications", sub: "\(os.notifs.count) right now") {
                withAnimation { os.notifs = [] }
            }
        }
    }

    @ViewBuilder var pageBattery: some View {
        SCard("Battery") {
            SInfo(icon: "battery.100", title: "Level",
                  value: UIDevice.current.batteryLevel < 0 ? "Unknown" : "\(Int(UIDevice.current.batteryLevel * 100))%")
            SInfo(icon: "bolt.fill", title: "State", value: batteryState())
            SToggle(icon: "battery.25", title: "Battery Saver", sub: "Visual only", on: $os.saver)
        }
    }

    @ViewBuilder var pageStorage: some View {
        let s = storageInfo()
        let used: Int64 = max(0, s.total - s.free)
        SCard("Device storage") {
            SInfo(icon: "internaldrive", title: "Free", value: gb(s.free))
            SInfo(icon: "chart.pie", title: "Used", value: gb(used))
            ProgressView(value: s.total > 0 ? Double(used) / Double(s.total) : 0)
                .tint(T.accent)
                .padding(.horizontal, 18)
                .padding(.bottom, 14)
            SInfo(icon: "photo", title: "Camera photos", value: "\(Gallery.list().count) files")
        }
    }

    @ViewBuilder var pageSound: some View {
        SCard("Sound & vibration") {
            SToggle(icon: "hand.tap", title: "Touch vibration", sub: "Haptic tap when opening apps", on: $os.haptics)
            SToggle(icon: "play.circle", title: "Background play", sub: "Keep browser audio playing when you leave", on: $os.bgPlay)
            SInfo(icon: "speaker.wave.2", title: "Volume", value: "Use iPhone buttons")
        }
    }

    @ViewBuilder var pageDisplay: some View {
        SCard("Brightness") {
            BrightBar(v: $os.brightness).padding(.horizontal, 14).padding(.vertical, 12)
        }
        SCard("Screen") {
            SToggle(icon: "display", title: "Keep screen on", sub: "Stops the iPhone from sleeping", on: $os.keepAwake)
            SToggle(icon: "moon", title: "Night Light", sub: "Warm screen tint", on: $os.nightLight)
            Slider(value: $os.nightLevel, in: 0.1...1.0)
                .accentColor(T.accent)
                .padding(.horizontal, 18)
                .padding(.bottom, 10)
            SToggle(icon: "screenrotation", title: "Auto-rotate", sub: "Visual only", on: $os.rotate)
            SToggle(icon: "figure.walk.motion", title: "Reduce motion", sub: "Very quick animations", on: $os.reduceMotion)
        }
    }

    @ViewBuilder var pageWallpaper: some View {
        SCard("Wallpaper") {
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(0..<wallpapers.count, id: \.self) { i in
                    Button { os.wallpaper = i } label: {
                        LinearGradient(colors: [wallpapers[i].a, wallpapers[i].c, wallpapers[i].d],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                            .frame(height: 84)
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .stroke(os.wallpaper == i ? Color.white : Color.clear, lineWidth: 3)
                            )
                            .overlay(
                                Text(wallpapers[i].name)
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundColor(.white)
                                    .padding(6),
                                alignment: .bottomLeading
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            SAction(icon: "photo", title: "Pick a photo", sub: "From your iPhone Photos") { showPicker = true }
        }
        SCard("Colors") {
            HStack(spacing: 14) {
                ForEach(0..<7, id: \.self) { i in
                    Button { os.theme = i } label: {
                        Circle()
                            .fill(i < 6 ? T.accents[i] : T.dynAccent)
                            .frame(width: 40, height: 40)
                            .overlay(Circle().stroke(Color.white, lineWidth: os.theme == i ? 3 : 0))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
        }
        SCard("Icon shape") {
            ChipRow(items: ["Circle", "Squircle", "Rounded"], selected: os.iconShape) { os.iconShape = $0 }
        }
    }

    @ViewBuilder var pageHome: some View {
        SCard("Clock") {
            SToggle(icon: "clock", title: "Show clock", sub: "", on: $os.showClock)
            ChipRow(items: ["Stacked", "Digital"], selected: os.clockStyle) { os.clockStyle = $0 }
        }
        SCard("Widgets (first two show on home)") {
            SToggle(icon: "battery.100", title: "Battery", sub: "", on: wBinding("battery"))
            SToggle(icon: "calendar", title: "Calendar", sub: "", on: wBinding("calendar"))
            SToggle(icon: "note.text", title: "Keep Notes", sub: "", on: wBinding("notes"))
            SToggle(icon: "internaldrive", title: "Storage", sub: "", on: wBinding("storage"))
            SToggle(icon: "bell", title: "Notifications", sub: "", on: wBinding("notifs"))
        }
        SCard("At a glance weather") {
            HStack {
                TextField("City, for the weather line", text: $os.weatherCity)
                    .foregroundColor(.white)
                    .submitLabel(.done)
                    .onSubmit { os.refreshWeather() }
            }
            .padding(.horizontal, 18)
            .frame(height: 44)
            Text("Shows the temperature on the home and lock screen. Last color dot in Wallpaper & style = colors taken from your wallpaper.")
                .font(.system(size: 12))
                .foregroundColor(.white.opacity(0.6))
                .padding(.horizontal, 18)
                .padding(.bottom, 14)
        }
        SCard("Layout") {
            SToggle(icon: "hand.tap", title: "Double tap to lock", sub: "Double tap the home screen", on: $os.doubleTapLock)
            SAction(icon: "arrow.counterclockwise", title: "Reset icon layout", sub: "Long press the home screen to move icons") { os.iconPos = [:] }
            SToggle(icon: "magnifyingglass", title: "Show search bar", sub: "", on: $os.showSearch)
            ChipRow(items: ["4 columns", "5 columns"], selected: os.gridCols == 5 ? 1 : 0) {
                os.gridCols = $0 == 1 ? 5 : 4
            }
        }
    }

    @ViewBuilder var pageAnim: some View {
        SCard("Open and close style") {
            ForEach(0..<animNames.count, id: \.self) { i in
                Button { os.animStyle = i } label: {
                    HStack {
                        Text(animNames[i]).foregroundColor(.white)
                        Spacer()
                        if os.animStyle == i {
                            Image(systemName: "checkmark.circle.fill").foregroundColor(T.accent)
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
        }
        SCard("Speed") {
            HStack {
                Text("Speed").foregroundColor(.white)
                Spacer()
                Text(String(format: "%.1fx", os.animSpeed)).foregroundColor(T.accent)
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            Slider(value: $os.animSpeed, in: 0.5...2.0, step: 0.1)
                .accentColor(T.accent)
                .padding(.horizontal, 18)
            SAction(icon: "play.circle", title: "Preview", sub: "Closes and reopens Settings") { preview() }
        }
    }

    @ViewBuilder var pageAccess: some View {
        SCard("Accessibility") {
            SToggle(icon: "figure.walk.motion", title: "Reduce motion", sub: "Very quick animations", on: $os.reduceMotion)
            SToggle(icon: "hand.tap", title: "Touch vibration", sub: "", on: $os.haptics)
        }
        SCard("Developer") {
            SToggle(icon: "hammer", title: "Show build info on home", sub: "", on: $os.showBuild)
        }
    }

    @ViewBuilder var pageSecurity: some View {
        SCard("Screen lock") {
            SToggle(icon: "lock.fill", title: "Lock screen at start", sub: "Swipe up to unlock", on: $os.lockOn)
            SAction(icon: "lock", title: "Lock now", sub: "") {
                os.home()
                withAnimation(.easeOut(duration: 0.25)) { os.locked = true }
            }
        }
        SCard("Privacy") {
            SToggle(icon: "eye.slash", title: "Hide sensitive notification content", sub: "", on: $os.hideNotif)
        }
    }

    @ViewBuilder var pageLocation: some View {
        SCard("Location") {
            SInfo(icon: "location", title: "Permissions", value: "Managed by iOS")
            SAction(icon: "gearshape", title: "Open iOS Settings", sub: "") { openIOSSettings() }
        }
    }

    @ViewBuilder var pageWellbeing: some View {
        let ids = os.usage.keys.sorted { (os.usage[$0] ?? 0) > (os.usage[$1] ?? 0) }
        SCard("App usage") {
            if ids.isEmpty {
                Text("No usage yet")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.6))
                    .padding(.horizontal, 18)
                    .padding(.bottom, 14)
            } else {
                ForEach(ids, id: \.self) { id in
                    SInfo(icon: "app", title: os.appName(id),
                          value: durText(os.usage[id] ?? 0) + " · " + "\(os.launches[id] ?? 0) opens")
                }
            }
            SAction(icon: "arrow.counterclockwise", title: "Reset usage", sub: "") {
                os.usage = [:]
                os.launches = [:]
            }
        }
    }

    @ViewBuilder var pageSystem: some View {
        SCard("Gestures") {
            SInfo(icon: "arrow.left", title: "Back", value: "Swipe from a side edge")
            SInfo(icon: "arrow.up", title: "Home", value: "Swipe up from the bottom")
            SInfo(icon: "square.stack", title: "Recents", value: "Swipe up and hold")
            SInfo(icon: "bell", title: "Notifications", value: "Swipe down")
        }
        SCard("Reset") {
            SAction(icon: "arrow.counterclockwise", title: "Reset all settings", sub: "Wallpaper, colors, animations") {
                os.resetSettings()
            }
        }
    }

    @ViewBuilder var pageAbout: some View {
        SCard("Device") {
            SInfo(icon: "iphone", title: "Device name", value: UIDevice.current.name)
            SInfo(icon: "cpu", title: "Model", value: UIDevice.current.model)
            SInfo(icon: "number", title: "iOS version", value: UIDevice.current.systemVersion)
        }
        SCard("Android Lite") {
            SInfo(icon: "number", title: "Android version", value: "16 (Lite)")
            SInfo(icon: "hammer", title: "Build number", value: "\(Build.number)")
            SInfo(icon: "globe", title: "Web apps", value: "\(os.webApps.count)")
            SInfo(icon: "wand.and.stars", title: "Real-ESRGAN 4x", value: ESRGAN.shared.available ? "Ready" : "Not in this build")
        }
    }
}
