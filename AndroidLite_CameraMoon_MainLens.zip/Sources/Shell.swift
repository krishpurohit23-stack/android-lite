import SwiftUI
import UIKit
import AVFoundation
import AVKit
import WebKit
import ImageIO
import PhotosUI

// Shell.swift - PhoneView (root ZStack), wallpaper, status bar, banner, nav pill. Read CLAUDE.md before editing.

// MARK: - Root
struct PhoneView: View {
    @ObservedObject var os: OS

    func anchor() -> UnitPoint {
        let s = UIScreen.main.bounds.size
        guard let o = os.origin, s.width > 0, s.height > 0 else { return .center }
        return UnitPoint(x: o.x / s.width, y: o.y / s.height)
    }

    var body: some View {
        GeometryReader { g in
            ZStack {
                Wallpaper().ignoresSafeArea()
                WindowAnchor().frame(width: 1, height: 1).allowsHitTesting(false)
                Home()
                    .scaleEffect(1 - 0.06 * (os.animStyle == 0 ? 0 : os.prog))
                    .opacity(1 - 0.4 * Double(os.animStyle == 0 ? 0 : os.prog))
                    .animation(.spring(response: 0.5, dampingFraction: 0.86), value: os.appShown)
                if let a = os.open {
                    AppHost(app: a, anchor: anchor())
                        .id(a.id)
                        .transition(.identity)
                        .zIndex(1)
                }
                if os.drawer && os.open == nil {
                    Drawer().transition(.move(edge: .bottom)).zIndex(2)
                }
                if os.showRecents {
                    Recents().transition(.opacity).zIndex(3)
                }
                VStack(spacing: 0) {
                    StatusBar()
                    if let b = os.banner {
                        Banner(n: b).transition(.move(edge: .top).combined(with: .opacity))
                    }
                    Spacer()
                }
                .zIndex(4)
                VStack {
                    Spacer()
                    NavZone()
                }
                .zIndex(4)
                HStack(spacing: 0) {
                    EdgeStrip(left: true)
                    Spacer()
                    EdgeStrip(left: false)
                }
                .padding(.top, 70)
                .padding(.bottom, 50)
                .zIndex(7)
                if os.backDrag > 4 {
                    HStack {
                        if !os.backLeft { Spacer() }
                        Image(systemName: os.backLeft ? "chevron.left" : "chevron.right")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(T.onAccent)
                            .frame(width: 44, height: 44)
                            .background(Circle().fill(T.accent.opacity(min(1, Double(os.backDrag) / 70))))
                            .offset(x: (os.backLeft ? 1 : -1) * min(os.backDrag, 90) * 0.45)
                        if os.backLeft { Spacer() }
                    }
                    .padding(.horizontal, 6)
                    .allowsHitTesting(false)
                    .zIndex(6)
                }
                if os.locked {
                    LockScreen().transition(.opacity).zIndex(20)
                }
                if os.nightLight {
                    Color(red: 1.0, green: 0.5, blue: 0.1)
                        .opacity(0.08 + 0.22 * os.nightLevel)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .zIndex(50)
                }
                Shade().zIndex(5)
                if os.showVolume {
                    VolumePill()
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                        .zIndex(9)
                }
                if os.shot != nil {
                    ScreenshotToast()
                        .transition(.move(edge: .leading).combined(with: .opacity))
                        .zIndex(9)
                }
            }
            .id(os.theme * 1000 + os.themeTick)
            .ignoresSafeArea(.container)
            .onAppear {
                os.top = g.safeAreaInsets.top
                os.bottom = g.safeAreaInsets.bottom
                GestureInstaller.install(os: os)
                if os.callWatcher == nil { os.callWatcher = CallWatcher(os: os) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { os.preloadWeb() }
                os.refreshWeather()
            }
        }
        .environmentObject(os)
    }
}

// MARK: - Wallpaper (cheap gradients, no blur)
struct Wallpaper: View {
    @EnvironmentObject var os: OS
    var body: some View {
        let w = wallpapers[min(max(os.wallpaper, 0), wallpapers.count - 1)]
        ZStack {
            if os.wallpaper == 99, let img = os.wallpaperImage {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
                Color.black.opacity(0.25)
            } else {
                LinearGradient(colors: [w.a, w.b], startPoint: .top, endPoint: .bottom)
                RadialGradient(colors: [w.c.opacity(0.55), .clear],
                               center: .topLeading, startRadius: 10, endRadius: 440)
                RadialGradient(colors: [w.d.opacity(0.4), .clear],
                               center: .bottomTrailing, startRadius: 10, endRadius: 500)
            }
        }
        .clipped()
    }
}

// MARK: - Status bar (left half = notifications, right half = quick settings)
struct Zone: View {
    let tap: () -> Void
    let drag: () -> Void
    var body: some View {
        Color.clear
            .contentShape(Rectangle())
            .onTapGesture { tap() }
            .gesture(DragGesture(minimumDistance: 8).onEnded { v in
                if v.translation.height > 12 { drag() }
            })
    }
}

struct EdgeStrip: View {
    @EnvironmentObject var os: OS
    let left: Bool
    var body: some View {
        Color.clear
            .frame(width: 22)
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 6)
                .onChanged { v in
                    os.backLeft = left
                    os.backDrag = max(0, left ? v.translation.width : -v.translation.width)
                }
                .onEnded { v in
                    os.backEnded(left ? v.translation.width : -v.translation.width)
                })
    }
}

struct StatusBar: View {
    @EnvironmentObject var os: OS

    func show(_ p: Panel) {
        withAnimation(.easeOut(duration: 0.25)) { os.panel = p }
    }

    var body: some View {
        HStack(spacing: 6) {
            Text(Date(), style: .time).font(.system(size: 14, weight: .semibold))
            ForEach(os.notifs.prefix(3)) { n in
                Image(systemName: iconFor(n.appId)).font(.system(size: 11))
            }
            Spacer()
            if os.dnd { Image(systemName: "moon.fill") }
            if os.airplane {
                Image(systemName: "airplane")
            } else {
                Image(systemName: os.wifi ? "wifi" : "wifi.slash")
                Image(systemName: "antenna.radiowaves.left.and.right")
            }
            if UIDevice.current.batteryLevel >= 0 {
                Text("\(Int(UIDevice.current.batteryLevel * 100))%").font(.system(size: 12, weight: .medium))
            }
            Image(systemName: os.saver ? "battery.25" : "battery.100")
        }
        .font(.system(size: 13))
        .foregroundColor(.white)
        .padding(.horizontal, 26)
        .frame(height: max(os.top, 30))
        .overlay(
            HStack(spacing: 0) {
                Zone(tap: { show(.notif) }, drag: { os.topOpen(left: true) })
                Zone(tap: { show(.qs) }, drag: { os.topOpen(left: false) })
            }
        )
    }
}

struct Banner: View {
    @EnvironmentObject var os: OS
    let n: Notif
    @State var dy: CGFloat = 0
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: iconFor(n.appId))
                .foregroundColor(tintFor(n.appId))
                .frame(width: 34, height: 34)
                .background(Circle().fill(tintFor(n.appId).opacity(0.2)))
            VStack(alignment: .leading, spacing: 2) {
                Text(n.title).font(.system(size: 14, weight: .semibold))
                Text(os.hideNotif ? "Content hidden" : n.body).font(.system(size: 13)).opacity(0.8).lineLimit(1)
            }
            Spacer()
        }
        .foregroundColor(.white)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(T.card))
        .padding(.horizontal, 12)
        .padding(.top, 4)
        .offset(y: dy)
        .gesture(
            DragGesture(minimumDistance: 8)
                .onChanged { v in dy = min(0, v.translation.height) }
                .onEnded { v in
                    if v.translation.height < -30 {
                        withAnimation { os.banner = nil }
                    } else {
                        withAnimation { dy = 0 }
                    }
                }
        )
        .onTapGesture {
            withAnimation { os.banner = nil }
            if let a = appFor(n.appId) { os.launch(a) }
        }
    }
}

// MARK: - Gesture nav pill (swipe up: close app / drawer, swipe up + hold: recents)
struct NavZone: View {
    @EnvironmentObject var os: OS
    var body: some View {
        Capsule()
            .fill(Color.white.opacity(0.85))
            .frame(width: 118, height: 5)
            .shadow(color: .black.opacity(0.4), radius: 2)
            .frame(maxWidth: .infinity, minHeight: 44, alignment: .center)
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 6)
                .onChanged { v in
                    if os.open != nil && os.appShown {
                        os.dragApp(v.translation.height)
                    }
                }
                .onEnded { v in
                    if abs(v.translation.width) > 60 && abs(v.translation.width) > abs(v.translation.height) {
                        os.quickSwitch(v.translation.width > 0 ? 1 : -1)
                        return
                    }
                    let slow = abs(v.predictedEndTranslation.height - v.translation.height) < 100
                    os.bottomEnded(v.translation.height, slow: slow)
                })
    }
}
